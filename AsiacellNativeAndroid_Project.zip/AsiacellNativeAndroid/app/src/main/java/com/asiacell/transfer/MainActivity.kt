package com.asiacell.transfer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var simSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var checkButton: Button
    private lateinit var transferButton: Button
    private var sims: List<SubscriptionInfo> = emptyList()
    private var subId: Int? = null
    private var balance: Double? = null
    private var amount: Int? = null
    private var sending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        box.addView(TextView(this).apply {
            text = "تحويل رصيد آسياسيل"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        })
        box.addView(TextView(this).apply {
            text = "اختر شريحة آسياسيل، ثم افحص الرصيد. ستراجع المبلغ وكود التحويل قبل الإرسال."
            textSize = 16f
        })
        box.addView(TextView(this).apply { text = "الشريحة المستخدمة:"; textSize = 17f })
        simSpinner = Spinner(this)
        box.addView(simSpinner)
        checkButton = Button(this).apply {
            text = "فحص الرصيد (*133#)"
            setOnClickListener { checkBalance() }
        }
        box.addView(checkButton)
        status = TextView(this).apply {
            text = "لم يتم فحص الرصيد بعد."
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }
        box.addView(status)
        transferButton = Button(this).apply {
            text = "مراجعة كود التحويل"
            isEnabled = false
            setOnClickListener { confirmTransfer() }
        }
        box.addView(transferButton)
        box.addView(TextView(this).apply {
            text = "لن يتم إرسال التحويل إلا بعد تأكيدك. تحقق من المبلغ والمستلم. دعم USSD يختلف حسب الهاتف والشبكة."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(box) })
        askPermissions()
    }

    private fun askPermissions() {
        val p = listOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.CALL_PHONE)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (p.isNotEmpty()) requestPermissions(p.toTypedArray(), 10) else loadSims()
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 10 && g.isNotEmpty() && g.all { it == PackageManager.PERMISSION_GRANTED }) loadSims()
        else if (r == 10) status.text = "امنح صلاحيات الهاتف وقراءة حالة الشريحة لتشغيل USSD."
    }

    @Suppress("MissingPermission")
    private fun loadSims() {
        try {
            val sm = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            sims = sm.activeSubscriptionInfoList ?: emptyList()
            if (sims.isEmpty()) {
                simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("لا توجد شريحة نشطة"))
                status.text = "لم يتم العثور على شريحة SIM نشطة."
                return
            }
            val names = sims.mapIndexed { i, s -> "${s.carrierName ?: "SIM"} — الشريحة ${i + 1}" }
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            subId = sims[0].subscriptionId
            simSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    subId = sims.getOrNull(pos)?.subscriptionId
                    balance = null; amount = null; transferButton.isEnabled = false
                    status.text = "تم اختيار الشريحة. اضغط فحص الرصيد."
                }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
            status.text = "تم العثور على ${sims.size} شريحة. اختر آسياسيل."
        } catch (e: Exception) { status.text = "تعذر قراءة الشرائح: ${e.message}" }
    }

    @Suppress("MissingPermission")
    private fun selectedTelephony(): TelephonyManager? {
        val id = subId ?: return null
        val base = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        return if (Build.VERSION.SDK_INT >= 26) base.createForSubscriptionId(id) else null
    }

    @Suppress("MissingPermission")
    private fun checkBalance() {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            askPermissions(); return
        }
        val tm = selectedTelephony()
        if (tm == null) { status.text = "اختر شريحة نشطة. يتطلب USSD نظام Android 8 أو أحدث."; return }
        checkButton.isEnabled = false
        transferButton.isEnabled = false
        status.text = "جارٍ فحص الرصيد على الشريحة المختارة..."
        try {
            tm.sendUssdRequest("*133#", object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(t: TelephonyManager, req: String, response: CharSequence) {
                    runOnUiThread { checkButton.isEnabled = true; parseBalance(response.toString()) }
                }
                override fun onReceiveUssdResponseFailed(t: TelephonyManager, req: String, code: Int) {
                    runOnUiThread { checkButton.isEnabled = true; status.text = "فشل فحص USSD. رمز الخطأ: $code" }
                }
            }, null)
        } catch (e: Exception) {
            checkButton.isEnabled = true
            status.text = "تعذر إرسال كود USSD: ${e.message}"
        }
    }

    private fun parseBalance(raw: String) {
        val normalized = raw.map { c ->
            when (c) {
                in '٠'..'٩' -> ('0'.code + c.code - '٠'.code).toChar()
                in '۰'..'۹' -> ('0'.code + c.code - '۰'.code).toChar()
                else -> c
            }
        }.joinToString("").replace(',', '.')
        val matches = Regex("""(?<!\d)(\d+)(?:\.(\d+))?""").findAll(normalized).toList()
        val m = matches.firstOrNull { it.groupValues.getOrNull(2).orEmpty().isNotEmpty() } ?: matches.firstOrNull()
        if (m == null) {
            balance = null; amount = null; transferButton.isEnabled = false
            status.text = "رد الشبكة:\n$raw\n\nلم أستطع استخراج الرصيد تلقائياً."
            return
        }
        val whole = m.groupValues[1]
        val value = (whole + if (m.groupValues[2].isNotEmpty()) ".${m.groupValues[2]}" else "").toDoubleOrNull()
        if (value == null || whole.isEmpty()) {
            status.text = "تعذر فهم الرصيد. رد الشبكة:\n$raw"; return
        }
        val calculated = (whole.first().digitToIntOrNull() ?: 0) * 1000
        balance = value; amount = calculated
        val tooHigh = calculated.toDouble() > value
        status.text = "رد الشبكة:\n$raw\n\nالرصيد المستخرج: $value\nالمبلغ المحسوب: $calculated" +
            if (tooHigh) "\n\nتحذير: المبلغ أكبر من الرصيد؛ تم إيقاف التحويل." else "\n\nراجع المبلغ قبل المتابعة."
        transferButton.isEnabled = calculated > 0 && !tooHigh
    }

    private fun confirmTransfer() {
        val a = amount ?: return
        val b = balance ?: return
        if (a.toDouble() > b) { status.text = "المبلغ أكبر من الرصيد؛ أوقف التحويل."; return }
        val code = "*123*${a}*7779575401*1#"
        AlertDialog.Builder(this)
            .setTitle("تأكيد تحويل الرصيد")
            .setMessage("الشريحة: ${simSpinner.selectedItem}\nالرصيد: $b\nالمبلغ: $a\nالمستلم: 7779575401\n\nالكود:\n$code\n\nهل تريد إرساله؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("تأكيد وإرسال") { _, _ -> sendTransfer(code) }
            .show()
    }

    @Suppress("MissingPermission")
    private fun sendTransfer(code: String) {
        if (sending) return
        val tm = selectedTelephony() ?: run { status.text = "تعذر تحديد الشريحة."; return }
        sending = true
        transferButton.isEnabled = false
        status.text = "تم إرسال طلب USSD. انتظر رد الشبكة..."
        try {
            tm.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(t: TelephonyManager, req: String, response: CharSequence) {
                    runOnUiThread {
                        sending = false
                        status.text = "رد الشبكة على طلب التحويل:\n$response"
                        checkButton.isEnabled = true
                    }
                }
                override fun onReceiveUssdResponseFailed(t: TelephonyManager, req: String, code: Int) {
                    runOnUiThread {
                        sending = false
                        status.text = "فشل طلب التحويل. رمز الخطأ: $code"
                        checkButton.isEnabled = true
                    }
                }
            }, null)
        } catch (e: Exception) {
            sending = false; checkButton.isEnabled = true
            status.text = "خطأ أثناء إرسال التحويل: ${e.message}"
        }
    }
}
