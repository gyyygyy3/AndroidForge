package com.asiaphone.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Network client for the real, server-side rewards service. */
object RewardApi {
    // Change this only if the Netlify site has a different site name/domain.
    const val NETLIFY_SITE_URL = "https://asiaphone.netlify.app"

    // Set these two values after creating the Supabase project.
    // The anon key is intended to be public in mobile clients; never put the service-role key here.
    const val SUPABASE_URL = "https://YOUR_PROJECT_REF.supabase.co"
    const val SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY"

    fun isConfigured(): Boolean =
        !SUPABASE_URL.contains("YOUR_PROJECT_REF") &&
        !SUPABASE_ANON_KEY.contains("YOUR_SUPABASE_ANON_KEY") &&
        NETLIFY_SITE_URL.startsWith("https://")

    fun requestPhoneOtp(phone: String) {
        val body = JSONObject().put("phone", phone).put("create_user", true)
        requestJson("${SUPABASE_URL.trimEnd('/')}/auth/v1/otp", "POST", body, null, true)
    }

    fun verifyPhoneOtp(phone: String, otp: String): JSONObject {
        val body = JSONObject().put("phone", phone).put("token", otp).put("type", "sms")
        return requestJson("${SUPABASE_URL.trimEnd('/')}/auth/v1/verify", "POST", body, null, true)
    }

    fun getProfile(accessToken: String): JSONObject =
        requestFunction("GET", "profile", null, accessToken)

    fun redeemCode(accessToken: String, code: String): JSONObject =
        requestFunction("POST", "redeem", JSONObject().put("code", code), accessToken)

    fun requestWithdrawal(
        accessToken: String,
        amount: Long,
        cardholder: String,
        cardNumber: String
    ): JSONObject = requestFunction(
        "POST", "withdraw", JSONObject()
            .put("amount", amount)
            .put("cardholder", cardholder)
            .put("cardNumber", cardNumber), accessToken
    )

    fun refreshSession(refreshToken: String): JSONObject {
        val body = JSONObject().put("refresh_token", refreshToken)
        return requestJson(
            "${SUPABASE_URL.trimEnd('/')}/auth/v1/token?grant_type=refresh_token",
            "POST", body, null, true
        )
    }

    private fun requestFunction(
        method: String,
        action: String,
        body: JSONObject?,
        accessToken: String
    ): JSONObject {
        val url = "${NETLIFY_SITE_URL.trimEnd('/')}/.netlify/functions/rewards?action=$action"
        return requestJson(url, method, body, accessToken, false)
    }

    private fun requestJson(
        address: String,
        method: String,
        body: JSONObject?,
        bearer: String?,
        useSupabaseKey: Boolean
    ): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (useSupabaseKey) setRequestProperty("apikey", SUPABASE_ANON_KEY)
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) doOutput = true
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val result = try { if (raw.isBlank()) JSONObject() else JSONObject(raw) }
            catch (_: Exception) { JSONObject().put("message", raw) }
            if (status !in 200..299) {
                throw IllegalStateException(result.optString("error", result.optString("message", "فشل الاتصال بالخادم ($status)")))
            }
            return result
        } finally {
            connection.disconnect()
        }
    }
}
