const json = (statusCode, body) => new Response(JSON.stringify(body), {
  status: statusCode,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});

export default async (request) => {
  if (request.method !== "POST") return json(405, { error: "Method not allowed" });

  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return json(503, { error: "لم يتم إعداد REPLICATE_API_TOKEN في إعدادات Netlify." });
  const clientToken = process.env.VIDEO_CLIENT_TOKEN;
  if (clientToken && request.headers.get("x-video-client-token") !== clientToken) {
    return json(401, { error: "هذا التطبيق غير مخوّل لإلغاء عملية التوليد." });
  }

  const id = new URL(request.url).searchParams.get("id") || "";
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(id)) {
    return json(400, { error: "رقم عملية التوليد غير صحيح." });
  }

  try {
    const upstream = await fetch(
      `https://api.replicate.com/v1/predictions/${encodeURIComponent(id)}/cancel`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/json",
        },
      },
    );

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = result.detail || result.error || `Provider error (${upstream.status})`;
      return json(upstream.status === 429 ? 429 : 502, { error: String(detail).slice(0, 500) });
    }

    return json(200, {
      id: result.id || id,
      status: result.status || "canceled",
    });
  } catch (error) {
    return json(502, { error: error?.message || "تعذر إرسال طلب إلغاء التوليد." });
  }
};
