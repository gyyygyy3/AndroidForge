# تعديل الصور AI – مشروع Android

تطبيق Android أصلي بلغة Kotlin وGradle Kotlin DSL. يحتوي المشروع على شاشة افتتاحية وشاشة أدوات، وأضيفت إليه الآن ميزة تحويل صورة واحدة إلى فيديو بواسطة نموذج Wan 2.2 Fast.

## ميزة الفيديو

- اختيار صورة من الهاتف.
- كتابة وصف للحركة.
- إرسال طلب واحد لتوليد فيديو واحد.
- متابعة التوليد، مشاهدة النتيجة، وحفظ ملف MP4.
- يمر الاتصال عبر Netlify Functions لإبقاء مفتاح مزود التوليد خارج التطبيق.

**خطوات إعداد Netlify وReplicate وبناء APK موجودة بالتفصيل في `VIDEO_SETUP_AR.md`.**

## إعدادات Android

| البند | القيمة |
|---|---|
| اللغة | Kotlin |
| نوع التطبيق | Native Android |
| Android Gradle Plugin | 8.7.3 |
| Kotlin Plugin | 2.0.21 |
| Gradle المقترح | 8.9 |
| JDK | 17 |
| compileSdk / targetSdk | 34 |
| minSdk | 26 |
| applicationId | `com.aiphotoeditor.app` |

رابط Netlify يوضع في `app/build.gradle.kts` أو يمرر بخاصية `NETLIFY_BASE_URL` وقت البناء. لا تضع `REPLICATE_API_TOKEN` داخل التطبيق.

## ملفات الخادم

- `netlify/functions/create-video.mjs`: إنشاء طلب Wan 2.2 Fast.
- `netlify/functions/video-status.mjs`: متابعة نتيجة الطلب.
- `netlify.toml`: إعداد نشر Netlify Functions ومسارات `/api`.
- `public/index.html`: صفحة تعريف خدمة التطبيق.

## ملاحظة

النموذج مفتوح المصدر، لكن تشغيله عبر GPU سحابي ليس مجانياً بالضرورة. هذه النسخة تستخدم Replicate لسهولة الربط، وتكلفته الحالية المنشورة تقارب 0.05 دولار للفيديو 480p. راجع صفحة النموذج قبل الاستخدام: https://replicate.com/wan-video/wan-2.2-i2v-fast
