plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val netlifyBaseUrl = (project.findProperty("NETLIFY_BASE_URL") as String?)
    ?: "https://YOUR-SITE.netlify.app"
val videoClientToken = (project.findProperty("VIDEO_CLIENT_TOKEN") as String?) ?: ""

android {
    namespace = "com.asiaphone.app"
    buildFeatures {
        buildConfig = true
    }
    // Pin to API 34, which is preinstalled in AndroidForge's build image.
    compileSdk = 34
    buildToolsVersion = "34.0.0"

    defaultConfig {
        applicationId = "com.aiphotoeditor.app"
        buildConfigField("String", "NETLIFY_BASE_URL", "\"$netlifyBaseUrl\"")
        buildConfigField("String", "VIDEO_CLIENT_TOKEN", "\"$videoClientToken\"")
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
