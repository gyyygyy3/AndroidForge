# مصادر ميزة تحويل الصورة إلى فيديو

تستخدم النسخة الحالية نموذج Wan 2.2 Fast عبر واجهة Replicate، وتستخدم Netlify Functions كوسيط بين تطبيق Android ومزود التوليد.

- Wan 2.2 Fast Image-to-Video والنموذج والسعر المنشور: https://replicate.com/wan-video/wan-2.2-i2v-fast
- مخطط مدخلات النموذج: https://replicate.com/wan-video/wan-2.2-i2v-fast/api/schema
- إنشاء التنبؤات ومتابعتها (Async / Polling): https://replicate.com/docs/topics/predictions/create-a-prediction
- دعم ملفات الإدخال وروابط Data URI: https://replicate.com/docs/topics/predictions/input-files
- إعدادات Netlify Functions وحدود التنفيذ والطلب: https://docs.netlify.com/build/functions/configuration/
- متغيرات البيئة السرية لوظائف Netlify: https://docs.netlify.com/build/functions/environment-variables/

ملاحظة: التكاليف والحصص وحدود الخدمات قابلة للتغيير؛ راجع صفحات المزود الرسمية قبل الاستخدام الفعلي أو النشر التجاري.
