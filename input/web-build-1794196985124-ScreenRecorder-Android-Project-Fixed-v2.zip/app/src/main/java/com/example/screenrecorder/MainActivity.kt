package com.example.screenrecorder

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var status: TextView

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenRecordService::class.java).apply {
                    action = ScreenRecordService.ACTION_START
                    putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenRecordService.EXTRA_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
                status.text = "التسجيل يعمل. أوقفه من زر إيقاف التسجيل أو الإشعار."
            } else {
                status.text = "لم تمنح إذن مشاركة الشاشة."
                Toast.makeText(this, "تم إلغاء تسجيل الشاشة", Toast.LENGTH_SHORT).show()
            }
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "مسجل الشاشة"
            textSize = 26f
        }
        status = TextView(this).apply {
            text = "يسجل فيديو للشاشة بعد موافقتك من نافذة أندرويد."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "بدء تسجيل الشاشة"
            setOnClickListener {
                captureLauncher.launch(projectionManager.createScreenCaptureIntent())
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف التسجيل"
            setOnClickListener {
                startService(Intent(this@MainActivity, ScreenRecordService::class.java).apply {
                    action = ScreenRecordService.ACTION_STOP
                })
                status.text = "تم إرسال أمر إيقاف التسجيل. تحقق من مجلد Movies/ScreenRecorder."
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
