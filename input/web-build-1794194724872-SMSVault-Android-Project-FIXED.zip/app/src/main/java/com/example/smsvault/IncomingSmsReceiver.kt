package com.example.smsvault

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class IncomingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val pending = goAsync()
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val rows = messages.map { sms ->
            SmsMessage(
                address = sms.originatingAddress ?: "Unknown",
                body = sms.messageBody ?: "",
                date = sms.timestampMillis,
                type = 0
            )
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (rows.isNotEmpty()) {
                    SmsDatabase.get(context).smsDao().insertAll(rows)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
