package com.example.smsvault

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Telephony
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val db by lazy { SmsDatabase.get(this) }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.READ_SMS] == true) {
            importExistingMessages()
        } else {
            Toast.makeText(this, "يلزم إذن قراءة الرسائل لاستيراد الأرشيف", Toast.LENGTH_LONG).show()
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val messages by db.smsDao().observeAll().collectAsState(initial = emptyList())
            val count by db.smsDao().observeCount().collectAsState(initial = 0)

            MaterialTheme {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("SMS Vault") },
                            actions = { Text("$count رسالة  ", modifier = Modifier.padding(12.dp)) }
                        )
                    }
                ) { padding ->
                    Column(Modifier.padding(padding).padding(12.dp)) {
                        Text(
                            "أرشيف الرسائل النصية محفوظ محلياً على هذا الهاتف.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { requestSmsPermissions() },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("استيراد الرسائل الموجودة") }
                        Spacer(Modifier.height(12.dp))
                        LazyColumn {
                            items(messages, key = { it.id }) { message ->
                                ElevatedCard(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(message.address, style = MaterialTheme.typography.titleMedium)
                                        Text(message.body)
                                        Text(
                                            DateFormat.getDateTimeInstance().format(Date(message.date)),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
            == PackageManager.PERMISSION_GRANTED) {
            // Existing permission: receiver continues to save incoming messages.
        }
    }

    private fun requestSmsPermissions() {
        permissionLauncher.launch(arrayOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS
        ))
    }

    private fun importExistingMessages() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
            != PackageManager.PERMISSION_GRANTED) return

        lifecycleScope.launch {
            val imported = withContext(Dispatchers.IO) {
                val rows = mutableListOf<SmsMessage>()
                contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    arrayOf(
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE,
                        Telephony.Sms.TYPE
                    ),
                    null, null,
                    "${Telephony.Sms.DATE} DESC"
                )?.use { cursor ->
                    val addressCol = cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
                    val bodyCol = cursor.getColumnIndexOrThrow(Telephony.Sms.BODY)
                    val dateCol = cursor.getColumnIndexOrThrow(Telephony.Sms.DATE)
                    val typeCol = cursor.getColumnIndexOrThrow(Telephony.Sms.TYPE)

                    while (cursor.moveToNext()) {
                        rows.add(
                            SmsMessage(
                                address = cursor.getString(addressCol) ?: "Unknown",
                                body = cursor.getString(bodyCol) ?: "",
                                date = cursor.getLong(dateCol),
                                type = cursor.getInt(typeCol)
                            )
                        )
                    }
                }
                db.smsDao().insertAll(rows)
                rows.size
            }
            Toast.makeText(this@MainActivity, "تمت قراءة $imported رسالة (المكرر يُتجاهل)", Toast.LENGTH_LONG).show()
        }
    }
}
