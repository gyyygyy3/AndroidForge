package com.example.smsvault

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SmsDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: SmsMessage)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(messages: List<SmsMessage>)

    @Query("SELECT * FROM sms_messages ORDER BY date DESC")
    fun observeAll(): Flow<List<SmsMessage>>

    @Query("SELECT COUNT(*) FROM sms_messages")
    fun observeCount(): Flow<Int>
}
