import crypto from 'node:crypto';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-admin-key',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

const json = (statusCode, payload) => ({
  statusCode,
  headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  body: JSON.stringify(payload),
});

function requiredEnv(name) {
  const value = process.env[name];
  if (!value) throw new Error(`إعداد الخادم المفقود: ${name}`);
  return value.replace(/\/$/, '');
}

async function supabaseFetch(path, options = {}) {
  const base = requiredEnv('SUPABASE_URL');
  const serviceKey = requiredEnv('SUPABASE_SERVICE_ROLE_KEY');
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!response.ok) {
    const message = data.message || data.error_description || data.error || 'تعذر تنفيذ العملية على قاعدة البيانات';
    throw new Error(message);
  }
  return data;
}

async function authenticatedUser(event) {
  const auth = event.headers.authorization || event.headers.Authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) throw new Error('جلسة المكافآت غير موجودة. أعد فتح التطبيق.');
  const base = requiredEnv('SUPABASE_URL');
  const anonKey = requiredEnv('SUPABASE_ANON_KEY');
  const response = await fetch(`${base}/auth/v1/user`, {
    headers: { apikey: anonKey, Authorization: `Bearer ${token}` },
  });
  const user = await response.json().catch(() => ({}));
  if (!response.ok || !user.id) throw new Error('جلسة المكافآت غير صالحة. أعد فتح التطبيق.');
  return user;
}

function encryptCardNumber(cardNumber) {
  const keyHex = process.env.CARD_ENCRYPTION_KEY || '';
  if (!/^[0-9a-fA-F]{64}$/.test(keyHex)) throw new Error('لم يتم إعداد مفتاح تشفير بيانات البطاقة على الخادم');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(keyHex, 'hex'), iv);
  const encrypted = Buffer.concat([cipher.update(cardNumber, 'utf8'), cipher.final()]);
  return {
    ciphertext: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    last4: cardNumber.slice(-4),
  };
}

function decryptCardNumber(row) {
  const keyHex = requiredEnv('CARD_ENCRYPTION_KEY');
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    Buffer.from(keyHex, 'hex'),
    Buffer.from(row.card_iv, 'base64')
  );
  decipher.setAuthTag(Buffer.from(row.card_tag, 'base64'));
  return Buffer.concat([
    decipher.update(Buffer.from(row.card_ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8');
}

function validMastercard(value) {
  if (value.length !== 16) return false;
  const prefix2 = Number(value.slice(0, 2));
  const prefix4 = Number(value.slice(0, 4));
  if (!((prefix2 >= 51 && prefix2 <= 55) || (prefix4 >= 2221 && prefix4 <= 2720))) return false;
  return validLuhn(value);
}

function validLuhn(value) {
  let sum = 0;
  let doubleDigit = false;
  for (let i = value.length - 1; i >= 0; i--) {
    let n = Number(value[i]);
    if (doubleDigit) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    doubleDigit = !doubleDigit;
  }
  return sum % 10 === 0;
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  try {
    const action = event.queryStringParameters?.action || '';
    const body = event.body ? JSON.parse(event.body) : {};

    if (action === 'admin_withdrawals' || action === 'admin_update') {
      const adminKey = process.env.WITHDRAWAL_ADMIN_KEY;
      if (!adminKey || event.headers['x-admin-key'] !== adminKey) return json(403, { error: 'غير مصرح' });
      if (action === 'admin_withdrawals') {
        const rows = await supabaseFetch('/rest/v1/withdrawal_requests?select=id,user_id,amount_iqd,cardholder,card_last4,card_ciphertext,card_iv,card_tag,status,created_at&status=eq.pending&order=created_at.asc');
        const items = rows.map((row) => ({
          id: row.id,
          userId: row.user_id,
          amount: row.amount_iqd,
          cardholder: row.cardholder,
          cardLast4: row.card_last4,
          cardNumber: decryptCardNumber(row),
          createdAt: row.created_at,
          status: row.status,
        }));
        return json(200, { ok: true, withdrawals: items });
      }
      const id = String(body.id || '');
      const status = String(body.status || '');
      if (!id || !['paid', 'rejected'].includes(status)) return json(400, { error: 'بيانات تحديث الطلب غير صحيحة' });
      const result = await supabaseFetch('/rest/v1/rpc/admin_update_withdrawal', {
        method: 'POST', body: JSON.stringify({ p_withdrawal_id: id, p_new_status: status }),
      });
      return json(200, { ok: true, result });
    }

    const user = await authenticatedUser(event);
    if (event.httpMethod === 'GET' && action === 'profile') {
      const profile = await supabaseFetch('/rest/v1/rpc/ensure_reward_profile', {
        method: 'POST', body: JSON.stringify({ p_user_id: user.id }),
      });
      return json(200, { ok: true, ...profile });
    }

    if (event.httpMethod === 'POST' && action === 'redeem') {
      const code = String(body.code || '').trim().toUpperCase();
      if (!/^[A-Z0-9]{4,16}$/.test(code)) return json(400, { error: 'صيغة الكود غير صحيحة' });
      const result = await supabaseFetch('/rest/v1/rpc/redeem_reward_code', {
        method: 'POST', body: JSON.stringify({ p_user_id: user.id, p_code: code }),
      });
      return json(200, { ok: true, ...result });
    }

    if (event.httpMethod === 'POST' && action === 'withdraw') {
      const amount = Number(body.amount);
      const cardholder = String(body.cardholder || '').trim();
      const cardNumber = String(body.cardNumber || '').replace(/\D/g, '');
      if (!Number.isSafeInteger(amount) || amount < 10000) return json(400, { error: 'الحد الأدنى للسحب 10,000 دينار' });
      if (cardholder.length < 3 || cardholder.length > 80) return json(400, { error: 'اسم صاحب البطاقة غير صحيح' });
      if (!validMastercard(cardNumber)) return json(400, { error: 'أدخل رقم Mastercard صحيحاً مكوّناً من 16 رقماً' });
      const encrypted = encryptCardNumber(cardNumber);
      const result = await supabaseFetch('/rest/v1/rpc/create_withdrawal_request', {
        method: 'POST', body: JSON.stringify({
          p_user_id: user.id,
          p_amount_iqd: amount,
          p_cardholder: cardholder,
          p_card_last4: encrypted.last4,
          p_card_ciphertext: encrypted.ciphertext,
          p_card_iv: encrypted.iv,
          p_card_tag: encrypted.tag,
        }),
      });
      return json(200, { ok: true, message: 'تم تسجيل طلب السحب وإضافته إلى قائمة المراجعة', ...result });
    }

    return json(404, { error: 'العملية المطلوبة غير موجودة' });
  } catch (error) {
    return json(400, { error: error?.message || 'حدث خطأ غير متوقع' });
  }
};
