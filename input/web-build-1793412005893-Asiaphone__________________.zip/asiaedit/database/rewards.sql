-- Asiaphone rewards database (Supabase PostgreSQL)
-- Run the complete file once in Supabase Dashboard -> SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.reward_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  referral_code text not null unique,
  balance_iqd bigint not null default 0 check (balance_iqd >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.reward_code_redemptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  code text not null,
  reward_iqd bigint not null,
  created_at timestamptz not null default now()
);

create table if not exists public.reward_referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_user_id uuid not null references auth.users(id) on delete cascade,
  referred_user_id uuid not null unique references auth.users(id) on delete cascade,
  referral_code text not null,
  reward_iqd bigint not null default 8000,
  created_at timestamptz not null default now(),
  constraint reward_referrals_no_self check (referrer_user_id <> referred_user_id)
);

create table if not exists public.reward_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_iqd bigint not null check (amount_iqd <> 0),
  reason text not null,
  reference_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_iqd bigint not null check (amount_iqd >= 10000),
  cardholder text not null,
  card_last4 text not null check (card_last4 ~ '^[0-9]{4}$'),
  card_ciphertext text not null,
  card_iv text not null,
  card_tag text not null,
  status text not null default 'pending' check (status in ('pending', 'paid', 'rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists reward_ledger_user_created_idx
  on public.reward_ledger(user_id, created_at desc);
create index if not exists reward_referrals_owner_idx
  on public.reward_referrals(referrer_user_id, created_at desc);
create index if not exists withdrawal_requests_status_created_idx
  on public.withdrawal_requests(status, created_at asc);

-- No direct client access. Netlify functions use the Supabase service-role key server-side.
alter table public.reward_profiles enable row level security;
alter table public.reward_code_redemptions enable row level security;
alter table public.reward_referrals enable row level security;
alter table public.reward_ledger enable row level security;
alter table public.withdrawal_requests enable row level security;

create or replace function public.ensure_reward_profile(p_user_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  v_profile public.reward_profiles%rowtype;
  v_code text;
  v_inserted integer;
  v_count integer;
begin
  select * into v_profile from public.reward_profiles where user_id = p_user_id;
  if not found then
    loop
      v_code := 'AP' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8));
      insert into public.reward_profiles(user_id, referral_code)
      values (p_user_id, v_code)
      on conflict do nothing;
      get diagnostics v_inserted = row_count;
      exit when v_inserted = 1;
      select * into v_profile from public.reward_profiles where user_id = p_user_id;
      if found then exit; end if;
    end loop;
    select * into v_profile from public.reward_profiles where user_id = p_user_id;
  end if;

  select count(*)::integer into v_count
  from public.reward_referrals where referrer_user_id = p_user_id;

  return jsonb_build_object(
    'referralCode', v_profile.referral_code,
    'balance', v_profile.balance_iqd,
    'referralsCount', v_count
  );
end;
$$;

create or replace function public.redeem_reward_code(p_user_id uuid, p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  v_code text := upper(trim(p_code));
  v_referrer uuid;
  v_redemption_id uuid;
  v_new_balance bigint;
begin
  perform 1 from public.reward_profiles where user_id = p_user_id for update;
  if not found then
    raise exception 'تعذر العثور على حساب المكافآت';
  end if;

  if exists (select 1 from public.reward_code_redemptions where user_id = p_user_id) then
    raise exception 'استخدمت كوداً من قبل؛ يسمح لكل رقم هاتف بكود واحد فقط';
  end if;

  if v_code = 'XXX1' then
    insert into public.reward_code_redemptions(user_id, code, reward_iqd)
    values (p_user_id, v_code, 8000);
    update public.reward_profiles set balance_iqd = balance_iqd + 8000
      where user_id = p_user_id returning balance_iqd into v_new_balance;
    insert into public.reward_ledger(user_id, amount_iqd, reason)
      values (p_user_id, 8000, 'promo_xxx1');
    return jsonb_build_object(
      'message', 'تم قبول الكود XXX1 وإضافة 8,000 دينار إلى رصيدك',
      'credited', 8000,
      'balance', v_new_balance
    );
  end if;

  select user_id into v_referrer
  from public.reward_profiles
  where upper(referral_code) = v_code;

  if v_referrer is null then
    raise exception 'الكود غير موجود';
  end if;
  if v_referrer = p_user_id then
    raise exception 'لا يمكنك استخدام كود الدعوة الخاص بك';
  end if;

  insert into public.reward_code_redemptions(user_id, code, reward_iqd)
  values (p_user_id, v_code, 8000);

  insert into public.reward_referrals(referrer_user_id, referred_user_id, referral_code, reward_iqd)
  values (v_referrer, p_user_id, v_code, 8000)
  returning id into v_redemption_id;

  update public.reward_profiles set balance_iqd = balance_iqd + 8000
    where user_id = p_user_id returning balance_iqd into v_new_balance;
  insert into public.reward_ledger(user_id, amount_iqd, reason, reference_id)
    values (p_user_id, 8000, 'referral_joiner', v_redemption_id);

  update public.reward_profiles set balance_iqd = balance_iqd + 8000
    where user_id = v_referrer;
  insert into public.reward_ledger(user_id, amount_iqd, reason, reference_id)
    values (v_referrer, 8000, 'referral_owner', v_redemption_id);

  return jsonb_build_object(
    'message', 'تم تسجيل الإحالة وإضافة 8,000 دينار لك ولصاحب الكود',
    'credited', 8000,
    'balance', v_new_balance
  );
end;
$$;

create or replace function public.create_withdrawal_request(
  p_user_id uuid,
  p_amount_iqd bigint,
  p_cardholder text,
  p_card_last4 text,
  p_card_ciphertext text,
  p_card_iv text,
  p_card_tag text
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  v_balance bigint;
  v_request_id uuid;
begin
  if p_amount_iqd < 10000 then raise exception 'الحد الأدنى للسحب 10,000 دينار'; end if;
  select balance_iqd into v_balance
  from public.reward_profiles where user_id = p_user_id for update;
  if not found then raise exception 'حساب المكافآت غير موجود'; end if;
  if v_balance < p_amount_iqd then raise exception 'رصيدك لا يكفي لهذا السحب'; end if;

  insert into public.withdrawal_requests(
    user_id, amount_iqd, cardholder, card_last4,
    card_ciphertext, card_iv, card_tag
  ) values (
    p_user_id, p_amount_iqd, p_cardholder, p_card_last4,
    p_card_ciphertext, p_card_iv, p_card_tag
  ) returning id into v_request_id;

  update public.reward_profiles set balance_iqd = balance_iqd - p_amount_iqd
    where user_id = p_user_id;
  insert into public.reward_ledger(user_id, amount_iqd, reason, reference_id)
    values (p_user_id, -p_amount_iqd, 'withdrawal_pending', v_request_id);

  return jsonb_build_object('requestId', v_request_id, 'status', 'pending');
end;
$$;

create or replace function public.admin_update_withdrawal(
  p_withdrawal_id uuid,
  p_new_status text
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  v_request public.withdrawal_requests%rowtype;
begin
  if p_new_status not in ('paid', 'rejected') then raise exception 'حالة الطلب غير صحيحة'; end if;
  select * into v_request from public.withdrawal_requests
  where id = p_withdrawal_id for update;
  if not found then raise exception 'طلب السحب غير موجود'; end if;
  if v_request.status <> 'pending' then raise exception 'تمت معالجة هذا الطلب مسبقاً'; end if;

  update public.withdrawal_requests
  set status = p_new_status,
      card_ciphertext = '', card_iv = '', card_tag = '',
      updated_at = now()
  where id = p_withdrawal_id;

  if p_new_status = 'rejected' then
    update public.reward_profiles
    set balance_iqd = balance_iqd + v_request.amount_iqd
    where user_id = v_request.user_id;
    insert into public.reward_ledger(user_id, amount_iqd, reason, reference_id)
    values (v_request.user_id, v_request.amount_iqd, 'withdrawal_refund', p_withdrawal_id);
  end if;

  return jsonb_build_object('status', p_new_status);
end;
$$;

revoke all on function public.ensure_reward_profile(uuid) from public, anon, authenticated;
revoke all on function public.redeem_reward_code(uuid, text) from public, anon, authenticated;
revoke all on function public.create_withdrawal_request(uuid, bigint, text, text, text, text, text) from public, anon, authenticated;
revoke all on function public.admin_update_withdrawal(uuid, text) from public, anon, authenticated;

grant execute on function public.ensure_reward_profile(uuid) to service_role;
grant execute on function public.redeem_reward_code(uuid, text) to service_role;
grant execute on function public.create_withdrawal_request(uuid, bigint, text, text, text, text, text) to service_role;
grant execute on function public.admin_update_withdrawal(uuid, text) to service_role;
