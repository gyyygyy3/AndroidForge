plugins {
    id("com.android.application")
}

android {
    namespace = "com.marhaba.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.marhaba.app"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
