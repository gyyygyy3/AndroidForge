# تطبيق مرحبا

مشروع Android بسيط باللغة Java. تعرض الشاشة كلمة **مرحبا** فقط في منتصف الشاشة.

## بيانات التطبيق
- اسم التطبيق: مرحبا
- اسم المشروع: `MarhabaApp`
- اسم الحزمة: `com.marhaba.app`
- Namespace: `com.marhaba.app`
- Version Name: `1.0`
- Version Code: `1`
- Min SDK: 23
- Compile/Target SDK: 34

## البناء
افتح المجلد `MarhabaApp` في Android Studio، ثم نفّذ Sync Project with Gradle Files، وبعدها اختر Build > Build APK(s).

لا يتضمن المشروع مفتاح توقيع Release. سيستخدم بناء Debug توقيع Android Debug التلقائي. أنشئ مفتاح Release خاصاً بك عند الحاجة إلى إصدار نسخة نهائية.
