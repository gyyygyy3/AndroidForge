# دمج Iris Keyboard في مشروع زين

- تم استبدال خدمة لوحة المفاتيح القديمة `ZainKeyboardService` بخدمة Iris `nabu.iris.keyboard.latin.LatinIME`.
- بقيت حزمة التطبيق `com.zainiraq.offers` وواجهة زين الرئيسية `MainActivity` كما هي.
- تم نقل مصادر Java وموارد واجهة Iris إلى وحدة التطبيق الحالية.
- تم الإبقاء على ترخيص Iris Apache-2.0 وملف NOTICE ضمن المشروع.
- اسم لوحة الإدخال الظاهر للمستخدم أصبح Zain Keyboard.
- إعدادات لوحة المفاتيح متاحة من إعدادات نظام لوحة الإدخال.

## ملاحظات البناء
يتطلب البناء Android SDK Platform 36 وJDK 17. تم الاحتفاظ بإعدادات Gradle الأساسية لمشروع زين وتحديث namespace لموارد Iris.
لم يتم ادعاء نجاح بناء APK؛ يلزم تنفيذ Gradle build في بيئة Android SDK للتحقق النهائي.
\n- تم تحويل معرف موفر GIF إلى `com.zainiraq.offers.gifprovider` ليتوافق مع معرف تطبيق زين.\n- تم إبقاء واجهة زين الرئيسية ومزود الملفات الأصلي وصلاحيات الكاميرا.\n