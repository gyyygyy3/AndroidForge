package com.zainiraq.offers

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout

/**
 * Local-only Arabic keyboard. It inserts text directly into the focused field
 * and does not collect, store, or transmit typed content.
 */
class ZainKeyboardService : InputMethodService() {
    private var numbersMode = false
    private var keyboardRoot: LinearLayout? = null

    override fun onCreateInputView(): View {
        return buildKeyboard().also { keyboardRoot = it }
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        refreshKeyboard()
    }

    private fun buildKeyboard(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(8), dp(7), dp(8))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(247, 242, 250), Color.rgb(236, 226, 244))
            ).apply { cornerRadius = dp(17).toFloat() }
        }
        val brand = Button(this).apply {
            text = "✦  ZAIN  ·  العربية"
            isAllCaps = false
            textSize = 11f
            setTextColor(Color.rgb(100, 48, 145))
            typeface = Typeface.DEFAULT_BOLD
            background = transparentBackground()
            isClickable = false
            isFocusable = false
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(27)))

        val letterRows = if (numbersMode) {
            listOf(
                listOf("١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "٠"),
                listOf("@", "#", "٪", "&", "-", "+", "(", ")", "/"),
                listOf("*", "\"", "'", ":", ";", "!", "؟", "،", ".")
            )
        } else {
            listOf(
                listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح"),
                listOf("ج", "د", "ش", "س", "ي", "ب", "ل", "ا", "ت", "ن"),
                listOf("م", "ك", "ط", "ئ", "ء", "ؤ", "ر", "لا", "ى")
            )
        }
        letterRows.forEach { row ->
            val rowView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                rowView.addView(keyButton(key, special = false) {
                    currentInputConnection?.commitText(key, 1)
                }, LinearLayout.LayoutParams(0, dp(47), 1f).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                })
            }
            root.addView(rowView, LinearLayout.LayoutParams(-1, dp(53)))
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(keyButton(if (numbersMode) "أبج" else "١٢٣", true) {
            numbersMode = !numbersMode
            refreshKeyboard()
        }, weighted(0.95f))
        actions.addView(keyButton("،", false) { currentInputConnection?.commitText("،", 1) }, weighted(0.7f))
        actions.addView(keyButton("مسافة", true) { currentInputConnection?.commitText(" ", 1) }, weighted(2.5f))
        actions.addView(keyButton("⌫", true) {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }, weighted(0.9f))
        actions.addView(keyButton("↵", true) {
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }, weighted(0.9f))
        root.addView(actions, LinearLayout.LayoutParams(-1, dp(51)))
        return root
    }

    private fun refreshKeyboard() {
        keyboardRoot?.let { old ->
            val parent = old.parent as? ViewGroup ?: return
            val index = parent.indexOfChild(old)
            parent.removeView(old)
            val replacement = buildKeyboard().also { keyboardRoot = it }
            parent.addView(replacement, index)
        }
    }

    private fun keyButton(label: String, special: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = if (label.length > 3) 11f else 17f
        setTextColor(if (special) Color.WHITE else Color.rgb(65, 43, 78))
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setPadding(0, 0, 0, 0)
        background = GradientDrawable().apply {
            cornerRadius = dp(9).toFloat()
            setColor(if (special) Color.rgb(113, 62, 151) else Color.WHITE)
            setStroke(dp(1), if (special) Color.rgb(113, 62, 151) else Color.rgb(231, 222, 237))
        }
        setOnClickListener { action() }
    }

    private fun transparentBackground() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
    }

    private fun weighted(weight: Float) = LinearLayout.LayoutParams(0, dp(46), weight).apply {
        setMargins(dp(2), dp(2), dp(2), dp(2))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
