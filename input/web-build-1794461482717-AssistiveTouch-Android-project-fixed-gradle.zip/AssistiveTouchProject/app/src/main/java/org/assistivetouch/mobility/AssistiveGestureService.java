package org.assistivetouch.mobility;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AssistiveGestureService extends AccessibilityService {
    private WindowManager windowManager;
    private Handler mainHandler;
    private View markerView;
    private LinearLayout panelView;
    private WindowManager.LayoutParams markerParams;
    private boolean gestureInProgress;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler = new Handler(Looper.getMainLooper());
        showMarker();
        showPanel();
    }

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {
        // Deliberately do not inspect event text, window content, or node trees.
    }

    @Override
    public void onInterrupt() {
        // No ongoing feedback or automated sequence is running.
    }

    @Override
    public void onDestroy() {
        removeOverlays();
        super.onDestroy();
    }

    private void showPanel() {
        if (windowManager == null || panelView != null) return;
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        outer.setPadding(dp(10), dp(8), dp(10), dp(8));
        outer.setBackground(roundRect(Color.rgb(247, 249, 252), dp(20), Color.rgb(190, 202, 220), dp(1)));
        outer.setElevation(dp(10));

        TextView hint = new TextView(this);
        hint.setText("حرّك الهدف ثم اختر الإجراء");
        hint.setTextSize(15);
        hint.setTextColor(Color.rgb(16, 24, 40));
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(4), dp(2), dp(4), dp(6));
        hint.setContentDescription("لوحة المساعدة: حرّك علامة الهدف إلى المكان المطلوب ثم اختر نقرة أو ضغطاً مطوّلاً");
        outer.addView(hint, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout directions = new LinearLayout(this);
        directions.setOrientation(LinearLayout.HORIZONTAL);
        directions.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        addPanelButton(directions, "←", "تحريك الهدف إلى اليسار", () -> moveTarget(-1, 0), 1f);
        addPanelButton(directions, "↑", "تحريك الهدف إلى الأعلى", () -> moveTarget(0, -1), 1f);
        addPanelButton(directions, "↓", "تحريك الهدف إلى الأسفل", () -> moveTarget(0, 1), 1f);
        addPanelButton(directions, "→", "تحريك الهدف إلى اليمين", () -> moveTarget(1, 0), 1f);
        outer.addView(directions, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        actionsLp.topMargin = dp(6);
        addPanelButton(actions, "نقرة واحدة", "تنفيذ نقرة واحدة في موضع الهدف", () -> performGesture(false), 1.2f);
        addPanelButton(actions, "ضغط مطوّل", "تنفيذ ضغط مطوّل واحد في موضع الهدف", () -> performGesture(true), 1.2f);
        addPanelButton(actions, "إيقاف", "إيقاف لوحة المساعدة وتعطيل الخدمة", this::stopAssistiveService, 0.8f);
        outer.addView(actions, actionsLp);

        panelView = outer;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.y = dp(10);
        try {
            windowManager.addView(panelView, params);
        } catch (RuntimeException e) {
            panelView = null;
        }
    }

    private void addPanelButton(LinearLayout row, String label, String description,
                                Runnable action, float weight) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setPadding(dp(4), dp(4), dp(4), dp(4));
        button.setMinHeight(dp(48));
        button.setContentDescription(description);
        button.setBackground(roundRect(Color.rgb(21, 94, 239), dp(14),
                Color.rgb(21, 94, 239), dp(1)));
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(button, lp);
    }

    private void showMarker() {
        if (windowManager == null || markerView != null) return;
        TextView marker = new TextView(this);
        marker.setText("◎");
        marker.setTextSize(34);
        marker.setTextColor(Color.WHITE);
        marker.setGravity(Gravity.CENTER);
        marker.setContentDescription("علامة الهدف. اسحبها أو استخدم أزرار الاتجاه لتحريك موضع النقرة.");
        marker.setBackground(roundRect(Color.rgb(10, 84, 180), dp(34), Color.WHITE, dp(3)));
        marker.setElevation(dp(8));
        marker.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX;
            private float downRawY;
            private int startX;
            private int startY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (markerParams == null || gestureInProgress) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = markerParams.x;
                        startY = markerParams.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        markerParams.x = clamp(startX + Math.round(event.getRawX() - downRawX),
                                0, getResources().getDisplayMetrics().widthPixels - dp(68));
                        markerParams.y = clamp(startY + Math.round(event.getRawY() - downRawY),
                                0, getResources().getDisplayMetrics().heightPixels - dp(68));
                        try {
                            windowManager.updateViewLayout(markerView, markerParams);
                        } catch (RuntimeException ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return false;
                }
            }
        });
        markerView = marker;
        if (markerParams == null) {
            int size = dp(68);
            markerParams = new WindowManager.LayoutParams(size, size,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            markerParams.gravity = Gravity.TOP | Gravity.START;
            markerParams.x = Math.max(0, getResources().getDisplayMetrics().widthPixels / 2 - size / 2);
            markerParams.y = Math.max(dp(80), getResources().getDisplayMetrics().heightPixels / 2 - size / 2);
        }
        try {
            windowManager.addView(markerView, markerParams);
        } catch (RuntimeException e) {
            markerView = null;
        }
    }

    private void moveTarget(int horizontal, int vertical) {
        if (markerView == null || markerParams == null || gestureInProgress) return;
        int step = dp(22);
        markerParams.x = clamp(markerParams.x + horizontal * step, 0,
                getResources().getDisplayMetrics().widthPixels - dp(68));
        markerParams.y = clamp(markerParams.y + vertical * step, dp(24),
                getResources().getDisplayMetrics().heightPixels - dp(68));
        try {
            windowManager.updateViewLayout(markerView, markerParams);
        } catch (RuntimeException ignored) { }
    }

    private void performGesture(boolean longPress) {
        if (markerView == null || markerParams == null || gestureInProgress) return;
        int[] screenPosition = new int[2];
        markerView.getLocationOnScreen(screenPosition);
        float centerX = screenPosition[0] + markerView.getWidth() / 2f;
        float centerY = screenPosition[1] + markerView.getHeight() / 2f;

        try {
            windowManager.removeView(markerView);
            markerView = null;
        } catch (RuntimeException e) {
            return;
        }

        Path path = new Path();
        path.moveTo(centerX, centerY);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(
                path, 0, longPress ? 850 : 90);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        gestureInProgress = true;
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription description) {
                gestureInProgress = false;
                mainHandler.postDelayed(AssistiveGestureService.this::showMarker, 180);
            }

            @Override
            public void onCancelled(GestureDescription description) {
                gestureInProgress = false;
                mainHandler.postDelayed(AssistiveGestureService.this::showMarker, 180);
            }
        }, mainHandler);
        if (!accepted) {
            gestureInProgress = false;
            showMarker();
        }
    }

    private void stopAssistiveService() {
        removeOverlays();
        disableSelf();
    }

    private void removeOverlays() {
        if (windowManager == null) return;
        if (markerView != null) {
            try { windowManager.removeViewImmediate(markerView); } catch (RuntimeException ignored) { }
            markerView = null;
        }
        if (panelView != null) {
            try { windowManager.removeViewImmediate(panelView); } catch (RuntimeException ignored) { }
            panelView = null;
        }
    }

    private GradientDrawable roundRect(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(value, Math.max(minimum, maximum)));
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
