# Zain Iraq Native Android App

Native Android application built with Kotlin and Jetpack Compose. The user interface and application behavior are Kotlin-native; offer/service catalogue content is stored as bundled JSON data in `app/src/main/assets/content.json`.

Build with JDK 17, Android SDK 35 and Gradle 8.9+:

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

See `README-AR.md` for Arabic setup and feature notes.


## Purple visual refresh
The UI now uses an independent purple / magenta visual language with aqua accents, a five-second splash on first launch, larger Arabic labels, improved contrast, and a matching launcher icon. After completing the flow, later launches open the offers page directly. The reward flow and catalog data remain in place. The independent-app disclaimer remains visible.

## Face video capture

The face-video screen uses CameraX for a front-camera preview and a short silent recording (up to 8 seconds). The user sees a consent notice before the camera permission is requested. The app does not run facial recognition or liveness checks and does not upload the clip automatically; it stores the file in app-private storage and offers user-initiated sharing or deletion. This is an independent manual-review flow, not an official Zain Cash verification service.
