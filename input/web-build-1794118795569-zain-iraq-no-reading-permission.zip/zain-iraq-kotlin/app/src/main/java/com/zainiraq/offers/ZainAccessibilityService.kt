package com.zainiraq.offers

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Minimal service kept only for the app's explicit activation flow.
 * It does not inspect event text, window content, nodes, or send data.
 */
class ZainAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit
}
