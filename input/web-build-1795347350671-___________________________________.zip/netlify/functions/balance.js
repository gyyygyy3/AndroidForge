exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ ok: false, error: "POST required" }) };
  }

  try {
    if (!event.body || event.body.length > 4096) {
      return { statusCode: 400, headers, body: JSON.stringify({ ok: false, error: "Invalid request body" }) };
    }
    const data = JSON.parse(event.body);
    const balanceText = typeof data.balanceText === "string" ? data.balanceText.trim() : "";
    const carrier = typeof data.carrier === "string" ? data.carrier.trim() : "";
    if (!balanceText || balanceText.length > 512 || carrier !== "Asiacell") {
      return { statusCode: 400, headers, body: JSON.stringify({ ok: false, error: "Invalid balance payload" }) };
    }

    // Return the configured command exactly as entered. No fixed *230# value
    // and no USSD-pattern validation are applied here. A custom site-side
    // offer-selection routine may replace this variable lookup and return a
    // different value for every request.
    const ussdCode = String(
      process.env.ASIACELL_USSD_CODE ?? process.env.ASIACELL_COMPANY_CODE ?? ""
    );

    if (ussdCode.length === 0) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({ ok: false, error: "ASIACELL_USSD_CODE is not configured" })
      };
    }

    // The balance is processed for this request only and is not stored or logged here.
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ok: true,
        received: true,
        ussdCode,
        message: "Balance received; the configured site command is returned verbatim."
      })
    };
  } catch (_error) {
    return { statusCode: 400, headers, body: JSON.stringify({ ok: false, error: "Malformed JSON" }) };
  }
};
