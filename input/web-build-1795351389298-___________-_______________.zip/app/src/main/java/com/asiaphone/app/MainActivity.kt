package com.asiaphone.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.security.SecureRandom
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("asia_phone_prefs", Context.MODE_PRIVATE) }
    private var currentTab = 0
    private var selectedCategory: String? = null
    private var pendingUssdCode = ""
    private var pendingUssdShowDialer = true
    private var pendingUssdIsSiteCommand = false
    private var selectedSubscriptionId = -1
    private var balanceValueView: TextView? = null
    private var autoBalanceStartedThisLaunch = false
    private var asiacellSimResolvedForThisLaunch = false
    private val imageExecutor = Executors.newFixedThreadPool(3)
    private val netlifyExecutor = Executors.newSingleThreadExecutor()

    private val dark: Boolean get() = prefs.getBoolean("dark_mode", false)
    private val pageBg: Int get() = if (dark) Color.rgb(18, 19, 24) else Color.rgb(247, 247, 250)
    private val cardBg: Int get() = if (dark) Color.rgb(32, 34, 42) else Color.WHITE
    private val textMain: Int get() = if (dark) Color.rgb(246, 246, 248) else Color.rgb(33, 35, 42)
    private val textMuted: Int get() = if (dark) Color.rgb(180, 183, 193) else Color.rgb(112, 116, 126)
    private val red: Int get() = Color.rgb(215, 25, 53)
    private val lineColor: Int get() = if (dark) Color.rgb(58, 60, 70) else Color.rgb(235, 236, 240)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(157, 7, 34)
        window.navigationBarColor = if (dark) Color.rgb(18, 19, 24) else Color.WHITE
        if (Build.VERSION.SDK_INT >= 26) window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        render()
        // Request the permissions needed to identify the Asiacell SIM and query its balance.
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) startAutomaticBalanceCheckOnLaunch()
        }, 350L)
        // Keep the existing promotional popup, but show it after the permission prompt starts.
        if (savedInstanceState == null) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!isFinishing) showKikaWelcomePopup()
            }, 1400L)
        }
    }

    private fun showKikaWelcomePopup() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        val poster = ImageView(this).apply {
            setImageResource(R.drawable.reward_kika_popup)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "يرجى تعبئة رصيدك للتمتع بـ3 كيكا مجاناً ورصيد 10,000 دينار للاتصال"
        }
        content.addView(poster, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)))
        val close = Button(this).apply {
            text = "حسناً"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(190, 12, 42), 12)
            setOnClickListener { }
        }
        content.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            topMargin = dp(8)
        })
        val dialog = AlertDialog.Builder(this)
            .setView(content)
            .create()
        close.setOnClickListener { dialog.dismiss() }
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }
    }

    private fun gradient(start: Int, end: Int, radius: Int = 22): GradientDrawable {
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun label(value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            includeFontPadding = true
        }
    }

    private fun bodyColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(14), dp(16), dp(28))
    }

    private fun addGap(parent: LinearLayout, height: Int = 12) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addText(parent: LinearLayout, value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false, top: Int = 0, bottom: Int = 0) {
        val v = label(value, size, color, bold)
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top); bottomMargin = dp(bottom)
        })
    }

    private fun pillButton(text: String, filled: Boolean = true, click: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (filled) Color.WHITE else red)
            background = rounded(if (filled) red else if (dark) Color.rgb(55, 31, 38) else Color.rgb(255, 239, 242), 12)
            setPadding(dp(15), dp(10), dp(15), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
    }

    private fun render() {
        // Avoid updating a detached balance view after the user navigates to another tab.
        balanceValueView = null
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pageBg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        shell.addView(createHeader(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(pageBg)
        }
        val page = bodyColumn()
        scroll.addView(page, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        shell.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        shell.addView(createBottomNav(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))
        setContentView(shell)

        when (currentTab) {
            0 -> renderHome(page)
            1 -> renderPackages(page)
            2 -> renderServices(page)
            3 -> renderFavorites(page)
            4 -> renderMore(page)
            else -> renderRewards(page)
        }
    }

    private fun createHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(7), dp(16), dp(7))
            setBackgroundColor(if (dark) Color.rgb(27, 28, 35) else Color.WHITE)
        }
        val logo = TextView(this).apply {
            text = "A"
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(red, 16)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titles.addView(label("آسيا فون", 19f, textMain, true))
        titles.addView(label("ASIA PHONE  •  خدمات آسياسيل", 9.5f, textMuted, false))
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sourceBtn = TextView(this).apply {
            text = "⋯"
            textSize = 26f
            setTextColor(textMain)
            gravity = Gravity.CENTER
            background = rounded(if (dark) Color.rgb(45, 46, 54) else Color.rgb(246, 246, 248), 14)
            setOnClickListener { currentTab = 4; render() }
        }
        header.addView(sourceBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
        return header
    }

    private fun createBottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cardBg)
            elevation = dp(10).toFloat()
        }
        val entries = listOf("⌂" to "الرئيسية", "▦" to "الباقات", "✦" to "الخدمات", "♡" to "المفضلة", "☰" to "المزيد", "🎁" to "المكافآت")
        entries.forEachIndexed { index, pair ->
            val active = currentTab == index
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, dp(5))
                setOnClickListener {
                    currentTab = index
                    selectedCategory = null
                    render()
                }
            }
            item.addView(TextView(this).apply {
                text = pair.first
                textSize = 21f
                setTextColor(if (active) red else textMuted)
                gravity = Gravity.CENTER
            })
            item.addView(TextView(this).apply {
                text = pair.second
                textSize = 10f
                setTypeface(typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (active) red else textMuted)
                gravity = Gravity.CENTER
            })
            nav.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        return nav
    }

    private fun sectionTitle(parent: LinearLayout, title: String, sub: String = "") {
        addText(parent, title, 19f, textMain, true, 7, 0)
        if (sub.isNotBlank()) addText(parent, sub, 12f, textMuted, false, 3, 8)
    }

    private fun addTextToBalanceCard(parent: LinearLayout, value: String, size: Float, color: Int) {
        val note = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.RIGHT
        }
        parent.addView(note, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
    }

    private fun renderHome(page: LinearLayout) {
        addText(page, "أهلاً بك في آسيا فون", 20f, textMain, true)
        addText(page, "دليلك السريع لعروض وخدمات آسياسيل", 12f, textMuted, false, 2, 12)

        val balanceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = gradient(Color.rgb(222, 26, 55), Color.rgb(131, 0, 35), 24)
            setPadding(dp(18), dp(17), dp(18), dp(17))
        }
        val saved = prefs.getString("balance_response", "") ?: ""
        val savedAmount = extractBalanceAmount(saved) ?: "—"
        balanceValueView = label("رصيدك هو: $savedAmount", 18f, Color.WHITE, true)
        balanceCard.addView(balanceValueView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        page.addView(balanceCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addGap(page, 16)
        val hero = ImageView(this).apply {
            loadCampaignImage(this, "banner_home")
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(cardBg, 20)
            clipToOutline = true
            contentDescription = "آسيا فون"
            setOnClickListener { currentTab = 1; render() }
        }
        page.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(164)))

        addGap(page, 17)
        sectionTitle(page, "الأقسام الرئيسية", "اختر القسم لتظهر جميع الباقات المتاحة ضمنه")
        val cats = listOf(
            "فري سوشيال+" to "banner_free_social", "4G+ بلا حدود" to "banner_unlimited",
            "إلنا وللكل" to "banner_elna", "MAX CARD" to "banner_max",
            "YOOZ" to "banner_yooz", "RED" to "banner_red",
            "TikTok" to "banner_tiktok", "التجوال" to "banner_roaming"
        )
        cats.chunked(2).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            rowItems.forEachIndexed { idx, pair -> val (name, img) = pair; row.addView(categoryCard(name, img) { selectedCategory = name; currentTab = 1; render() }, LinearLayout.LayoutParams(0, dp(148), 1f).apply { if (idx == 0) leftMargin = dp(6) else rightMargin = dp(6) }) }
            if (rowItems.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(148), 1f))
            page.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }

        addGap(page, 8)
        sectionTitle(page, "خدمات سريعة")
        val quick = listOf("شكراً" to "shukran", "عروضي الخاصة" to "special", "اتصل بي" to "callme")
        quick.chunked(2).forEach { items ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            items.forEach { (name, id) ->
                val service = Catalog.services.first { it.id == id }
                row.addView(quickServiceCard(name, service.summary) { openService(service) }, LinearLayout.LayoutParams(0, dp(88), 1f).apply { rightMargin = dp(4); leftMargin = dp(4) })
            }
            page.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        }

        addGap(page, 8)
        sectionTitle(page, "عروض بارزة", "أمثلة من الباقات المنشورة رسمياً")
        val featuredIds = listOf("fs20m", "u4w", "max35", "yooz15_data", "red30", "tt_week")
        val featured = featuredIds.mapNotNull { id -> Catalog.offers.firstOrNull { it.id == id } }
        featured.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
        sourceFooter(page)
    }

    private fun categoryCard(name: String, imageName: String, click: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18, lineColor)
            clipToOutline = true
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        val image = ImageView(this).apply { loadCampaignImage(this, imageName); scaleType = ImageView.ScaleType.CENTER_CROP }
        card.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(94)))
        card.addView(label(name, 13f, textMain, true).apply { setPadding(dp(10), dp(8), dp(10), dp(8)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(43)))
        return card
    }

    private fun quickServiceCard(title: String, sub: String, click: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 15, lineColor)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            isClickable = true
            setOnClickListener { click() }
            addView(label(title, 14f, red, true))
            addView(label(sub, 10f, textMuted, false).apply { maxLines = 2 }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
    }

    private fun renderPackages(page: LinearLayout) {
        sectionTitle(page, "الباقات والعروض", "جميع الباقات ظاهرة حسب الفئات — لا يوجد بحث")
        val horizontal = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val filters = listOf("الكل") + Catalog.categories
        filters.forEach { item ->
            val selected = (item == "الكل" && selectedCategory == null) || item == selectedCategory
            val chip = TextView(this).apply {
                text = item
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (selected) Color.WHITE else textMain)
                background = rounded(if (selected) red else cardBg, 18, if (selected) red else lineColor)
                setPadding(dp(15), dp(9), dp(15), dp(9))
                setOnClickListener { selectedCategory = if (item == "الكل") null else item; render() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6); bottomMargin = dp(10) })
        }
        horizontal.addView(chips)
        page.addView(horizontal)
        val list = if (selectedCategory == null) Catalog.offers else Catalog.offers.filter { it.category == selectedCategory }
        if (list.isEmpty()) {
            emptyState(page, "لا توجد باقات في هذا القسم حالياً", "يمكن فتح صفحة آسياسيل الرسمية للتأكد من آخر تحديث.")
        } else {
            addText(page, "${list.size} باقة ضمن القسم", 12f, textMuted, false, 2, 8)
            list.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(11) }) }
        }
        sourceFooter(page)
    }

    private fun offerCard(offer: Offer): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18, lineColor)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val image = ImageView(this).apply { loadCampaignImage(this, offer.image); scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(cardBg, 13); clipToOutline = true }
        main.addView(image, LinearLayout.LayoutParams(dp(94), dp(94)))
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        details.addView(label(offer.title, 14f, textMain, true))
        val priceText = offer.price?.let { "${formatNumber(it)} دينار" } ?: if (offer.category == "YOOZ") "حسب اختيارك" else "حسب نوع الخط"
        details.addView(label(priceText, 16f, red, true).apply { setPadding(0, dp(5), 0, dp(3)) })
        details.addView(label("⏱ ${offer.validity}", 11f, textMuted))
        val metrics = listOfNotNull(offer.data.takeIf { it.isNotBlank() }?.let { "إنترنت: $it" }, offer.voice.takeIf { it.isNotBlank() }?.let { "مكالمات: $it" }, offer.sms.takeIf { it.isNotBlank() }?.let { "رسائل: $it" }).joinToString("  •  ")
        if (metrics.isNotBlank()) details.addView(label(metrics, 10.5f, textMuted).apply { maxLines = 2 })
        main.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(main)
        if (offer.note.isNotBlank()) card.addView(label("ⓘ ${offer.note}", 10.5f, textMuted).apply { setPadding(dp(4), dp(9), dp(4), dp(2)); maxLines = 4 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(pillButton("تفاصيل", false) { showOfferDetails(offer) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
        actions.addView(pillButton("${offer.activation.label}  ›", true) { confirmOfferAction(offer) }, LinearLayout.LayoutParams(0, dp(40), 1.4f))
        val fav = if (isFavorite(offer.id)) "♥" else "♡"
        actions.addView(pillButton(fav, false) { toggleFavorite(offer.id); render() }, LinearLayout.LayoutParams(dp(48), dp(40)).apply { rightMargin = dp(5) })
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(11) })
        return card
    }

    private fun showOfferDetails(offer: Offer) {
        val msg = buildString {
            append(offer.title).append("\n\n")
            if (offer.price != null) append("السعر: ").append(formatNumber(offer.price)).append(" دينار عراقي\n")
            append("الصلاحية: ").append(offer.validity).append("\n")
            if (offer.data.isNotBlank()) append("الإنترنت: ").append(offer.data).append("\n")
            if (offer.voice.isNotBlank()) append("المكالمات: ").append(offer.voice).append("\n")
            if (offer.sms.isNotBlank()) append("الرسائل: ").append(offer.sms).append("\n")
            append("\n").append(offer.details)
            if (offer.note.isNotBlank()) append("\n\nتنبيه: ").append(offer.note)
            append("\n\nطريقة الاشتراك: ").append(offer.activation.label)
        }
        AlertDialog.Builder(this)
            .setTitle("تفاصيل الباقة")
            .setMessage(msg)
            .setPositiveButton("متابعة الاشتراك") { _, _ -> confirmOfferAction(offer) }
            .setNeutralButton("المصدر الرسمي") { _, _ -> openWeb(offer.source) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun confirmOfferAction(offer: Offer) {
        val price = offer.price?.let { "السعر: ${formatNumber(it)} دينار عراقي.\n" } ?: "السعر/الأهلية: تحقق من شاشة آسياسيل.\n"
        val message = price + "الصلاحية: ${offer.validity}.\n\n" +
            "سيتم فتح طلب الشبكة أو تجهيز رسالة الاشتراك. لن يرسل التطبيق رسالة SMS مدفوعة تلقائياً."
        AlertDialog.Builder(this)
            .setTitle("تأكيد طلب الباقة")
            .setMessage(message)
            .setPositiveButton("متابعة") { _, _ -> runActivation(offer.activation, offer.title) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderServices(page: LinearLayout) {
        sectionTitle(page, "خدمات آسياسيل", "اضغط على الخدمة لقراءة الشروط ثم تنفيذ الإجراء")
        val groups = Catalog.services.groupBy { it.category }
        groups.forEach { (group, items) ->
            addText(page, group, 16f, red, true, 14, 7)
            items.forEach { service ->
                page.addView(serviceCard(service), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(9) })
            }
        }
        sourceFooter(page)
    }

    private fun serviceCard(item: ServiceItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setOnClickListener { openService(item) }
            isClickable = true
            isFocusable = true
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        val icon = TextView(this).apply {
            text = serviceIcon(item.category)
            textSize = 21f
            gravity = Gravity.CENTER
            background = rounded(if (dark) Color.rgb(67, 34, 44) else Color.rgb(255, 239, 242), 13)
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        textBox.addView(label(item.title, 14f, textMain, true))
        textBox.addView(label(item.summary, 11f, textMuted, false).apply { maxLines = 2 })
        row.addView(textBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (isFavorite(item.id)) "♥" else "♡"
            textSize = 22f
            setTextColor(red)
            gravity = Gravity.CENTER
            setOnClickListener { toggleFavorite(item.id); render() }
        }, LinearLayout.LayoutParams(dp(38), dp(44)))
        row.addView(label("›", 23f, red, true))
        card.addView(row)
        card.addView(label("الكلفة: ${item.cost}", 10.5f, textMuted).apply { setPadding(dp(3), dp(8), dp(3), dp(2)); maxLines = 3 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(pillButton("التفاصيل", false) { showServiceDetails(item) }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(5) })
        actions.addView(pillButton(item.actionLabel, true) { activateService(item) }, LinearLayout.LayoutParams(0, dp(38), 1.4f))
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        return card
    }

    private fun openService(item: ServiceItem) {
        showServiceDetails(item)
    }

    private fun showServiceDetails(item: ServiceItem) {
        val fullText = buildString {
            append(item.title).append("\n\n").append(item.details)
            append("\n\nالكلفة: ").append(item.cost)
            if (item.warning.isNotBlank()) append("\n\nتنبيه: ").append(item.warning)
        }
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setMessage(fullText)
            .setPositiveButton(item.actionLabel) { _, _ -> activateService(item) }
            .setNeutralButton("المصدر الرسمي") { _, _ -> openWeb(item.source) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun activateService(item: ServiceItem) {
        when (item.id) {
            "callme" -> { showCallMeDialog(); return }
            "validity" -> { showValidityDialog(); return }
            "call_ect" -> { showCallEctDialog(); return }
            "call_forward" -> { showCallForwardDialog(); return }
            "gift" -> { showGiftDialog(); return }
            "byebye" -> { showByeByeDialog(); return }
        }
        val paidRisk = item.cost.contains("دينار") && !item.cost.contains("مجاني")
        if (paidRisk) confirmServiceAction(item) else runActivation(item.activation, item.title)
    }

    private fun confirmServiceAction(item: ServiceItem) {
        AlertDialog.Builder(this)
            .setTitle("مراجعة الكلفة قبل المتابعة")
            .setMessage("${item.title}\n\n${item.cost}\n\n${item.warning}\n\nلن يرسل التطبيق رسالة مدفوعة أو يؤكد عملية مالية من دون موافقتك.")
            .setPositiveButton("أوافق، متابعة") { _, _ -> runActivation(item.activation, item.title) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderFavorites(page: LinearLayout) {
        sectionTitle(page, "المفضلة", "الباقات والخدمات التي حفظتها")
        val ids = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        val offerList = Catalog.offers.filter { ids.contains(it.id) }
        val serviceList = Catalog.services.filter { ids.contains(it.id) }
        if (offerList.isEmpty() && serviceList.isEmpty()) {
            emptyState(page, "قائمة المفضلة فارغة", "اضغط على رمز القلب في أي باقة لحفظها هنا.")
        } else {
            offerList.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
            serviceList.forEach { page.addView(serviceCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
        }
    }

    private fun renderMore(page: LinearLayout) {
        sectionTitle(page, "المزيد والإعدادات")
        val darkSwitchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        darkSwitchRow.addView(label("الوضع الليلي", 14f, textMain, true), LinearLayout.LayoutParams(0, dp(48), 1f))
        val sw = Switch(this).apply { isChecked = dark; setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("dark_mode", checked).apply(); render() } }
        darkSwitchRow.addView(sw)
        page.addView(darkSwitchRow)
        addGap(page)
        infoPanel(page, "فحص شريحة آسياسيل", "يتعرف التطبيق على شريحة آسياسيل النشطة (41805/41800) ثم يرسل كود فحص الرصيد من الشريحة نفسها فقط، ولا يستخدم زين أو كورك أو الشريحة الافتراضية عند فحص رصيد آسياسيل.")
        infoPanel(page, "مصادر العروض", "البيانات الحالية مجمعة من صفحات آسياسيل الرسمية. بعض العروض تتغير أو تظهر لأرقام محددة فقط؛ افتح المصدر الرسمي قبل الدفع إذا لم يظهر العرض على خطك.")
        page.addView(pillButton("فتح موقع آسياسيل الرسمي", true) { openWeb("https://www.asiacell.com/personal") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(10) })
        page.addView(pillButton("الأسئلة الشائعة والدعم", false) { openWeb("https://www.asiacell.com/personal/support/FAQ") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })
        addGap(page, 18)
        infoPanel(page, "حول آسيا فون", "آسيا فون تطبيق دليل مستقل لخدمات وباقات آسياسيل، وليس تطبيقاً رسمياً أو تابعاً لشركة آسياسيل. العلامات والأسماء التجارية تعود لأصحابها.")
        addText(page, "الإصدار 1.0.0  •  مراجعة بيانات الويب: 30 أكتوبر 2026", 10f, textMuted, false, 12, 0)
        sourceFooter(page)
    }

    private fun renderRewards(page: LinearLayout) {
        sectionTitle(page, "المكافآت والسحب", "تابع أرباحك واختر وسيلة السحب وشارك رمز الدعوة")

        // A display-only code is generated locally. No account, sign-in, or database is used.
        val myCode = localRewardCode()
        val balance = prefs.getLong("reward_display_balance", 0L)

        val earningsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(Color.rgb(222, 26, 55), Color.rgb(131, 0, 35), 20)
            setPadding(dp(17), dp(16), dp(17), dp(16))
        }
        earningsCard.addView(label("أرباحي", 14f, Color.rgb(255, 225, 230), true))
        earningsCard.addView(label("${String.format(java.util.Locale.US, "%,d", balance)} دينار عراقي", 27f, Color.WHITE, true).apply {
            setPadding(0, dp(7), 0, dp(2))
        })
        page.addView(earningsCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Withdrawal method is intentionally placed directly below earnings.
        addGap(page, 12)
        sectionTitle(page, "💳 وسيلة السحب")
        infoPanel(page, "السحب عبر Mastercard", "أدخل بيانات البطاقة ومبلغ السحب المطلوب. لا تدخل الرقم السري أو رمز الأمان CVV.")
        val cardholderInput = EditText(this).apply {
            hint = "اسم صاحب البطاقة كما هو مطبوع"
            textSize = 14f
            setSingleLine(true)
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(cardholderInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)))
        val cardNumberInput = EditText(this).apply {
            hint = "رقم Mastercard"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(cardNumberInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)).apply { topMargin = dp(8) })
        val amountInput = EditText(this).apply {
            hint = "مبلغ السحب بالدينار"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(amountInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)).apply { topMargin = dp(8) })
        page.addView(pillButton("إرسال طلب السحب", true) {
            val amount = amountInput.text.toString().toLongOrNull()
            val holder = cardholderInput.text.toString().trim()
            val cardNumber = normalizeDigits(cardNumberInput.text.toString()).filter { it.isDigit() }
            when {
                amount == null || amount <= 0L -> Toast.makeText(this, "أدخل مبلغ السحب", Toast.LENGTH_SHORT).show()
                holder.length < 3 -> Toast.makeText(this, "اكتب اسم صاحب البطاقة", Toast.LENGTH_SHORT).show()
                !isMastercardNumber(cardNumber) -> Toast.makeText(this, "تحقق من رقم Mastercard", Toast.LENGTH_SHORT).show()
                amount > balance -> Toast.makeText(this, "رصيدك المتاح لا يكفي لهذا السحب", Toast.LENGTH_LONG).show()
                else -> Toast.makeText(this, "خدمة تنفيذ طلبات السحب غير مفعّلة حالياً", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })


        addGap(page, 18)
        sectionTitle(page, "🪪 رمز الدعوة الخاص بي")
        val codePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        codePanel.addView(label("شارك رمز الدعوة الخاص بك مع الآخرين.", 11f, textMuted))
        codePanel.addView(label(myCode, 25f, red, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            textDirection = View.TEXT_DIRECTION_LTR
        })
        codePanel.addView(pillButton("نسخ الرمز", false) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("رمز الدعوة", myCode))
            Toast.makeText(this, "تم نسخ رمز الدعوة", Toast.LENGTH_SHORT).show()
        })
        page.addView(codePanel)

        addGap(page, 14)
        sectionTitle(page, "إدخال رمز الدعوة")
        val redeemInput = EditText(this).apply {
            hint = "أدخل رمز الدعوة"
            textSize = 14f
            setSingleLine(true)
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(redeemInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
        page.addView(pillButton("تأكيد الرمز", true) {
            if (redeemInput.text.toString().trim().isBlank()) {
                Toast.makeText(this, "أدخل رمز الدعوة أولاً", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "يتعذر التحقق من الرمز حالياً", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })

        addGap(page, 14)
        page.addView(pillButton("مشاركة رابط التطبيق", true) { shareAppOnly() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun localRewardCode(): String {
        val existing = prefs.getString("reward_display_code", null)
        if (!existing.isNullOrBlank()) return existing
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        val generated = buildString { repeat(6) { append(alphabet[random.nextInt(alphabet.length)]) } }
        prefs.edit().putString("reward_display_code", generated).apply()
        return generated
    }

    private fun isMastercardNumber(number: String): Boolean {
        if (number.length != 16) return false
        val prefix2 = number.take(2).toIntOrNull() ?: return false
        val prefix4 = number.take(4).toIntOrNull() ?: return false
        val mastercardBin = prefix2 in 51..55 || prefix4 in 2221..2720
        if (!mastercardBin) return false
        var sum = 0
        var doubleDigit = false
        for (index in number.length - 1 downTo 0) {
            var digit = number[index] - '0'
            if (doubleDigit) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
            doubleDigit = !doubleDigit
        }
        return sum % 10 == 0
    }

    private fun shareAppOnly() {
        val myCode = localRewardCode()
        val appLink = "https://asiaphone.netlify.app/"
        val shareText = buildString {
            append("جرّب تطبيق آسيا فون Asiaphone لخدمات آسياسيل:\n$appLink")
            if (myCode.isNotBlank()) append("\nرمز الدعوة: $myCode")
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        try {
            startActivity(Intent.createChooser(intent, "مشاركة تطبيق Asiaphone"))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذرت مشاركة التطبيق على هذا الهاتف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun infoPanel(parent: LinearLayout, title: String, text: String) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(cardBg, 16, lineColor); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        panel.addView(label(title, 14f, textMain, true))
        panel.addView(label(text, 11.5f, textMuted).apply { setPadding(0, dp(6), 0, 0) })
        parent.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(9) })
    }

    private fun emptyState(parent: LinearLayout, title: String, sub: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(cardBg, 20, lineColor); setPadding(dp(20), dp(28), dp(20), dp(28)) }
        box.addView(label("♡", 36f, red, true).apply { gravity = Gravity.CENTER })
        box.addView(label(title, 15f, textMain, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(4)) })
        box.addView(label(sub, 11f, textMuted).apply { gravity = Gravity.CENTER })
        parent.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun sourceFooter(parent: LinearLayout) {
        addGap(parent, 12)
        addText(parent, "ملاحظة: هذا الدليل لا ينفذ شراءً مدفوعاً بصمت. راجع السعر والشروط، وأكمل التأكيد في شاشة الشبكة أو الرسائل.", 10f, textMuted, false)
        addText(parent, "المصدر: صفحات آسياسيل الرسمية — الأسعار والأهلية قابلة للتغيير.", 10f, textMuted, false, 4, 0)
    }

    private fun serviceIcon(category: String): String = when (category) {
        "الرصيد والعروض" -> "💳"
        "التحويل والإهداء" -> "🎁"
        "إدارة الخط" -> "⚙"
        "المكالمات" -> "📞"
        "الحماية والترفيه" -> "🛡"
        "الخدمات الرقمية" -> "🌐"
        else -> "ⓘ"
    }

    private fun loadCampaignImage(view: ImageView, localName: String) {
        val fallback = drawableId(localName)
        if (fallback != 0) view.setImageResource(fallback)
        val remote = when (localName) {
            "banner_home", "banner_red" -> "https://www.asiacell.com/resources/images/asiacell/app-on-phone-new-en-26.png"
            "banner_free_social" -> "https://www.asiacell.com/resources/images/asiacell/crs-main-speed-mobile-ar.jpg"
            "banner_unlimited" -> "https://www.asiacell.com/resources/images/asiacell/crs-4g-news-unli-ar.jpg"
            "banner_max" -> "https://www.asiacell.com/resources/images/asiacell/crs_maxc_new_ar.png"
            "banner_yooz" -> "https://www.asiacell.com/resources/images/asiacell/crsd-omega-mgd-ar.png"
            "banner_roaming" -> "https://www.asiacell.com/resources/images/asiacell/crs_pass_ju_ar.png"
            "banner_elna" -> "https://www.asiacell.com/resources/images/asiacell/crs-gift-elna-en.jpg"
            else -> null
        } ?: return
        view.tag = remote
        val cacheFile = File(cacheDir, "campaign_${remote.hashCode()}.img")
        if (cacheFile.exists() && cacheFile.length() > 1000) {
            val cached = BitmapFactory.decodeFile(cacheFile.absolutePath)
            if (cached != null && view.tag == remote) { view.setImageBitmap(cached); return }
        }
        imageExecutor.execute {
            try {
                val connection = (URL(remote).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000; readTimeout = 7000; requestMethod = "GET";
                    setRequestProperty("User-Agent", "AsiaPhone/1.0 Android")
                }
                connection.inputStream.use { input -> cacheFile.outputStream().use { output -> input.copyTo(output) } }
                connection.disconnect()
                if (cacheFile.exists() && cacheFile.length() > 1000) {
                    val bitmap = BitmapFactory.decodeFile(cacheFile.absolutePath)
                    if (bitmap != null) runOnUiThread { if (view.tag == remote) view.setImageBitmap(bitmap) }
                }
            } catch (_: Exception) { /* local artwork remains as offline fallback */ }
        }
    }

    private fun drawableId(name: String): Int = resources.getIdentifier(name, "drawable", packageName)

    private fun formatNumber(number: Int): String = String.format("%,d", number)

    private fun isFavorite(id: String): Boolean = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).contains(id)

    private fun toggleFavorite(id: String) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (set.contains(id)) set.remove(id) else set.add(id)
        prefs.edit().putStringSet("favorites", set).apply()
        Toast.makeText(this, if (set.contains(id)) "أضيفت إلى المفضلة" else "حذفت من المفضلة", Toast.LENGTH_SHORT).show()
    }


    /** Start the balance query on app launch after obtaining phone and SIM identification permissions. */
    private fun startAutomaticBalanceCheckOnLaunch() {
        if (autoBalanceStartedThisLaunch) return
        autoBalanceStartedThisLaunch = true
        val missing = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.CALL_PHONE)
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (missing.isNotEmpty()) {
            showBalanceOnly()
            requestPermissions(missing.toTypedArray(), REQ_AUTO_BALANCE_PERMISSION)
            return
        }
        queryBalanceUsingAsiacellSim()
    }

    /** Find an active Asiacell SIM by the SIM's MCC/MNC or its carrier label. */
    @Suppress("MissingPermission")
    private fun queryBalanceUsingAsiacellSim() {
        try {
            val subscriptionManager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val asiacell = subscriptionManager.activeSubscriptionInfoList.orEmpty()
                .filter { isAsiacellSim(it) }
                .sortedBy { it.simSlotIndex }
                .firstOrNull()

            if (asiacell == null) {
                selectedSubscriptionId = -1
                asiacellSimResolvedForThisLaunch = false
                showBalanceOnly()
                return
            }

            // Pin the request to the identified Asiacell subscription, never the default SIM.
            selectedSubscriptionId = asiacell.subscriptionId
            asiacellSimResolvedForThisLaunch = true
            prefs.edit().putInt("selected_sim_id", selectedSubscriptionId).apply()
            showBalanceOnly()
            executeUssd("*133#")
        } catch (_: SecurityException) {
            showBalanceOnly()
        } catch (e: Exception) {
            showBalanceOnly()
        }
    }

    /** Identify Asiacell using Iraq PLMN 41805/41800, with the SIM carrier label as fallback. */
    private fun isAsiacellSim(info: SubscriptionInfo): Boolean {
        val operatorCode = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val mcc = info.mccString.orEmpty()
                val mnc = info.mncString.orEmpty()
                if (mcc.isNotBlank() && mnc.isNotBlank()) mcc + mnc.padStart(2, '0') else ""
            } else {
                val mcc = info.mcc
                val mnc = info.mnc
                if (mcc > 0 && mnc >= 0) mcc.toString() + mnc.toString().padStart(2, '0') else ""
            }
        } catch (_: Exception) { "" }

        if (operatorCode == "41805" || operatorCode == "41800") return true
        val carrier = info.carrierName?.toString().orEmpty()
        return carrier.contains("asiacell", ignoreCase = true) ||
            carrier.contains("asia cell", ignoreCase = true) ||
            carrier.contains("آسياسيل") || carrier.contains("اسيا سيل")
    }

    /** Execute a USSD request inside the app, asking for CALL_PHONE when needed. */
    private fun executeUssd(
        code: String,
        showDialerFallback: Boolean = false,
        isSiteCommand: Boolean = false
    ) {
        // A site command is passed through exactly as received. The mobile network
        // decides whether it is a supported USSD command; do not hard-code or
        // pattern-match offer codes in the app.
        if (code.isEmpty()) return
        if (code == "*133#" && !asiacellSimResolvedForThisLaunch) {
            startAutomaticBalanceCheckOnLaunch()
            return
        }
        pendingUssdCode = code
        pendingUssdShowDialer = showDialerFallback
        pendingUssdIsSiteCommand = isSiteCommand
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQ_USSD_PERMISSION)
            return
        }
        pendingUssdCode = ""
        pendingUssdIsSiteCommand = false
        chooseSimAndSend(code, isSiteCommand)
    }

    private fun runActivation(activation: Activation, title: String) {
        when (activation.mode) {
            ActionMode.USSD_BACKGROUND -> executeUssd(activation.code, true)
            // Interactive carrier menus must stay in the dialer; sendUssdRequest only
            // exposes a single response and cannot reliably continue multi-step menus.
            ActionMode.USSD_DIALER -> openDialer(activation.code)
            ActionMode.SMS_DRAFT -> openSmsComposer(activation.destination, activation.message)
            ActionMode.DIAL_NUMBER -> openDialer(activation.code)
            ActionMode.WEB -> openWeb(activation.url.ifBlank { "https://www.asiacell.com/personal/services" })
            ActionMode.SETTINGS -> {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "تعذر فتح إعدادات الهاتف", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun openWeb(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_LONG).show() }
    }

    private fun openDialer(code: String) {
        if (code.isBlank()) return
        try {
            val uri = Uri.fromParts("tel", code, null)
            startActivity(Intent(Intent.ACTION_DIAL, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSmsComposer(destination: String, message: String) {
        if (destination.isBlank()) {
            Toast.makeText(this, "رقم مركز الرسائل غير محدد", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$destination"))
            intent.putExtra("sms_body", message)
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "لا يوجد تطبيق رسائل متاح", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseSimAndSend(code: String, isSiteCommand: Boolean = false) {
        // Commands returned by the website must always use the Asiacell SIM identified this launch.
        if (isSiteCommand && (!asiacellSimResolvedForThisLaunch || selectedSubscriptionId < 0)) {
            showBalanceOnly()
            return
        }
        // A balance request is only valid after positively identifying an Asiacell SIM.
        if (code == "*133#" && (!asiacellSimResolvedForThisLaunch || selectedSubscriptionId < 0)) {
            showBalanceOnly()
            return
        }
        // Other standalone USSD services may use the user's saved/default voice SIM.
        if (selectedSubscriptionId < 0) selectedSubscriptionId = prefs.getInt("selected_sim_id", -1)
        if (selectedSubscriptionId < 0) {
            selectedSubscriptionId = try { SubscriptionManager.getDefaultVoiceSubscriptionId() }
            catch (_: Exception) { -1 }
        }
        sendUssdNow(code, isSiteCommand)
    }

    private fun sendUssdNow(code: String, isSiteCommand: Boolean = false) {
        if (isSiteCommand && (!asiacellSimResolvedForThisLaunch || selectedSubscriptionId < 0)) {
            showBalanceOnly()
            return
        }
        if (code == "*133#" && (!asiacellSimResolvedForThisLaunch || selectedSubscriptionId < 0)) {
            showBalanceOnly()
            return
        }
        val requestSubscriptionId = if (selectedSubscriptionId >= 0) selectedSubscriptionId
            else try { SubscriptionManager.getDefaultVoiceSubscriptionId() } catch (_: Exception) { -1 }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            if (isSiteCommand) showBalanceOnly()
            else showUssdFallback(code, "لم تمنح التطبيق صلاحية الاتصال اللازمة لتنفيذ USSD.")
            return
        }
        try {
            val baseManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val manager = if (requestSubscriptionId >= 0) baseManager.createForSubscriptionId(requestSubscriptionId) else baseManager
            manager.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    val answer = response.toString().trim().ifBlank { "استلم الهاتف رداً فارغاً من الشبكة." }
                    if (isSiteCommand) {
                        prefs.edit().putString("offers_response", answer)
                            .putString("offers_code", request)
                            .putLong("offers_time", System.currentTimeMillis()).apply()
                        showBalanceOnly()
                    } else if (request == "*133#" || request == "*233#") {
                        val receivedAt = System.currentTimeMillis()
                        val amount = extractBalanceAmount(answer)
                        if (amount != null) {
                            prefs.edit().putString("balance_response", amount).putLong("balance_time", receivedAt).apply()
                            showBalanceOnly(amount)
                        } else {
                            showBalanceOnly()
                        }
                        if (request == "*133#") sendBalanceToNetlify(answer)
                    } else if (request == "*230#") {
                        prefs.edit().putString("offers_response", answer).putString("offers_code", request)
                            .putLong("offers_time", System.currentTimeMillis()).apply()
                        showBalanceOnly()
                    } else {
                        showUssdResult(request, answer, pendingUssdShowDialer)
                    }
                }

                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    val reason = when (failureCode) {
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "خدمة USSD غير متاحة من الشبكة حالياً."
                        TelephonyManager.USSD_RETURN_FAILURE -> "رفضت الشبكة الطلب أو لم تستطع تنفيذه."
                        else -> "تعذر استلام نتيجة USSD (رمز الخطأ $failureCode)."
                    }
                    if (isSiteCommand) {
                        showBalanceOnly()
                    } else if (request == "*133#" || request == "*233#") {
                        showBalanceOnly()
                    } else if (request == "*230#") {
                        showBalanceOnly()
                    } else {
                        showUssdFallback(request, reason)
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            if (isSiteCommand) {
                showBalanceOnly()
            } else if (code == "*133#" || code == "*233#") {
                showBalanceOnly()
            } else if (code == "*230#") {
                showBalanceOnly()
            } else showUssdFallback(code, "لا تتوفر صلاحية كافية لتنفيذ الطلب: ${e.message ?: ""}")
        } catch (_: Exception) {
            if (isSiteCommand) {
                showBalanceOnly()
            } else if (code == "*133#" || code == "*233#") {
                showBalanceOnly()
            } else if (code == "*230#") {
                showBalanceOnly()
            } else showUssdFallback(code, "هذا الهاتف أو الخط لا يدعم تنفيذ الطلب بهذه الطريقة.")
        }
    }

    /** Keep the home balance card limited to the numeric balance only. */
    private fun showBalanceOnly(rawBalance: String? = null) {
        val source = rawBalance ?: (prefs.getString("balance_response", "") ?: "")
        val amount = extractBalanceAmount(source) ?: "—"
        balanceValueView?.text = "رصيدك هو: $amount"
    }

    /** Extract the amount associated with the balance label, excluding validity/status text. */
    private fun extractBalanceAmount(response: String): String? {
        if (response.isBlank()) return null
        val normalized = normalizeDigits(response)
        val amountPattern = Regex("""[0-9][0-9,٬.٫]*""")
        val balanceLabel = Regex("""(?i)(?:رصيد|balance)""")
        val labelMatch = balanceLabel.find(normalized)
        val searchText = if (labelMatch != null) normalized.substring(labelMatch.range.last + 1) else normalized
        val amountMatch = amountPattern.find(searchText) ?: return null
        return amountMatch.value.trimEnd(',', '٬', '.', '٫').takeIf { it.any(Char::isDigit) }
    }

    /** Send only the returned Asiacell balance text to the configured Netlify endpoint. */
    private fun sendBalanceToNetlify(balanceText: String) {
        val capturedAt = System.currentTimeMillis()
        showBalanceOnly(balanceText)

        netlifyExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(NETLIFY_BALANCE_ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12_000
                    readTimeout = 12_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("X-AsiaPhone-Key", NETLIFY_API_KEY)
                    setRequestProperty("User-Agent", "AsiaPhone-Android/1.0")
                }
                val payload = JSONObject().apply {
                    put("balanceText", balanceText.take(512))
                    put("carrier", "Asiacell")
                    put("checkedAt", java.time.Instant.ofEpochMilli(capturedAt).toString())
                    put("source", "asia_phone_android")
                }
                connection.outputStream.use { stream ->
                    stream.write(payload.toString().toByteArray(Charsets.UTF_8))
                }

                val status = connection.responseCode
                val responseStream = if (status in 200..299) connection.inputStream else connection.errorStream
                val responseBody = responseStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val serverResponse = if (responseBody.isNotBlank()) JSONObject(responseBody) else JSONObject()
                if (status !in 200..299) {
                    val serverError = serverResponse.optString("error", "HTTP $status")
                    throw IOException("HTTP $status: $serverError")
                }
                if (!serverResponse.optBoolean("ok", false)) {
                    throw IOException("The website did not confirm a successful balance calculation")
                }
                // Pass the site-selected command verbatim: no fixed-code comparison
                // or USSD pattern restriction is applied by the app.
                val returnedCode = serverResponse.optString("ussdCode", "")

                runOnUiThread {
                    if (returnedCode.isEmpty()) {
                        if (!isFinishing && !isDestroyed) {
                            showBalanceOnly(balanceText)
                        }
                        return@runOnUiThread
                    }
                    // Execute the raw command directly through TelephonyManager;
                    // this does not open the dialer or display a confirmation dialog.
                    // Keep execution tied to the Asiacell subscription resolved earlier.
                    if (asiacellSimResolvedForThisLaunch && selectedSubscriptionId >= 0) {
                        executeUssd(returnedCode, showDialerFallback = false, isSiteCommand = true)
                    } else if (!isFinishing && !isDestroyed) {
                        showBalanceOnly(balanceText)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    val detail = e.message.orEmpty()
                    val reason = when {
                        detail.contains("HTTP 401") -> "مفتاح الربط غير مطابق؛ راجع ASIA_PHONE_API_KEY في Netlify."
                        detail.contains("HTTP 503") -> "مفتاح ASIA_PHONE_API_KEY غير مضبوط في Netlify."
                        detail.contains("HTTP 422") -> "وصل الرصيد إلى الموقع لكن تعذر استخراج مبلغ واضح منه."
                        detail.contains("HTTP 400") -> "الموقع رفض بيانات طلب الرصيد."
                        else -> "تعذر الاتصال بموقع Netlify أو لم يؤكد نجاح الحساب."
                    }
                    showBalanceOnly(balanceText)
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun showUssdResult(code: String, response: String, fallback: Boolean) {
        val builder = AlertDialog.Builder(this)
            .setTitle(if (code == "*133#" || code == "*233#") "نتيجة استعلام الرصيد" else "رد شبكة آسياسيل")
            .setMessage(response)
            .setPositiveButton("حسناً", null)
        if (fallback) builder.setNeutralButton("متابعة في شاشة الاتصال") { _, _ -> openDialer(code) }
        builder.show()
    }

    private fun showUssdFallback(code: String, reason: String) {
        AlertDialog.Builder(this)
            .setTitle("تعذر إكمال طلب الشبكة داخل التطبيق")
            .setMessage("$reason\n\nيمكن فتح شاشة الاتصال بالكود نفسه كبديل. سيبقى عليك الضغط على زر الاتصال.")
            .setPositiveButton("فتح شاشة الاتصال") { _, _ -> openDialer(code) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUTO_BALANCE_PERMISSION) {
            val callGranted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val phoneStateGranted = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
            if (callGranted && phoneStateGranted) {
                queryBalanceUsingAsiacellSim()
            } else {
                autoBalanceStartedThisLaunch = false
                showBalanceOnly()
            }
        } else if (requestCode == REQ_USSD_PERMISSION) {
            val callGranted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val requestedCode = pendingUssdCode
            val isSiteCommand = pendingUssdIsSiteCommand
            pendingUssdCode = ""
            pendingUssdIsSiteCommand = false
            if (callGranted) {
                if (requestedCode.isNotBlank()) chooseSimAndSend(requestedCode, isSiteCommand)
            } else if (requestedCode.isNotBlank()) {
                if (isSiteCommand) showBalanceOnly()
                else if (requestedCode == "*133#") showBalanceOnly()
                else showUssdFallback(requestedCode, "صلاحية الاتصال مطلوبة لإرسال طلب USSD.")
            }
        }
    }

    private fun showCallMeDialog() {
        val input = EditText(this).apply { hint = "رقم الشخص الذي تريد منه الاتصال"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("إرسال اتصل بي").setMessage("ستجهز رسالة إلى 250 تحتوي رقم الشخص المطلوب. الخدمة توفر 10 رسائل مجانية للمشتركين المؤهلين.")
            .setView(input).setPositiveButton("إعداد الرسالة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً يبدأ بـ 07", Toast.LENGTH_LONG).show()
                else openSmsComposer("250", number)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showValidityDialog() {
        val options = arrayOf("يوم واحد — 250 دينار", "3 أيام — 500 دينار", "7 أيام — 1,000 دينار", "30 يوماً — 3,500 دينار", "90 يوماً — 7,500 دينار", "365 يوماً — 21,000 دينار")
        val keys = listOf("1", "2", "3", "4", "5", "6")
        AlertDialog.Builder(this).setTitle("شراء صلاحية الخط المعلق").setItems(options) { _, which ->
            AlertDialog.Builder(this).setTitle("إعداد رسالة شراء الصلاحية")
                .setMessage("سيتم تجهيز رسالة بالرمز ${keys[which]} إلى 290. هذه الخدمة مخصصة للخط المعلق بسبب انتهاء الصلاحية مع وجود رصيد متبقٍ.")
                .setPositiveButton("متابعة") { _, _ -> openSmsComposer("290", keys[which]) }
                .setNegativeButton("إلغاء", null).show()
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun showByeByeDialog() {
        val choices = arrayOf("تفعيل خدمة باي باي (رسوم 2,400 دينار)", "الاستعلام عن قائمة الحظر (مجاني)", "حجب رقم (600 دينار لكل رقم)", "إزالة رقم من قائمة الحظر (مجاني)", "الاتصال بالمجيب 266")
        AlertDialog.Builder(this).setTitle("إدارة خدمة باي باي").setItems(choices) { _, which ->
            when (which) {
                0 -> AlertDialog.Builder(this).setTitle("تأكيد التفعيل").setMessage("تفعيل الخدمة يكلف 2,400 دينار. هل تريد فتح رسالة التفعيل؟")
                    .setPositiveButton("متابعة") { _, _ -> openSmsComposer("266", "") }.setNegativeButton("إلغاء", null).show()
                1 -> openSmsComposer("266", "1")
                2 -> askNumberForByeBye(false)
                3 -> askNumberForByeBye(true)
                else -> openDialer("266")
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun askNumberForByeBye(remove: Boolean) {
        val input = EditText(this).apply { hint = "رقم الهاتف 077XXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle(if (remove) "إزالة رقم" else "حجب رقم")
            .setView(input).setPositiveButton("إعداد الرسالة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً صحيحاً", Toast.LENGTH_LONG).show()
                else openSmsComposer("266", if (remove) "* $number" else number)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun normalizeDigits(value: String): String {
        val map = mapOf('٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4', '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9', '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4', '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9')
        return value.map { map[it] ?: it }.joinToString("")
    }

    companion object {
        private const val NETLIFY_BALANCE_ENDPOINT = "https://asianoplus.netlify.app/.netlify/functions/balance"
        // Paste this exact value into Netlify as ASIA_PHONE_API_KEY.
        private const val NETLIFY_API_KEY = "2a42f7bb9c14530e8d9ae0779f3fe89ce8a2f768bb301ea7"
        private const val REQ_USSD_PERMISSION = 701
        private const val REQ_AUTO_BALANCE_PERMISSION = 702
    }


    // Restored unrelated Asiacell services; credit-transfer feature remains removed.
    private fun showGiftDialog() {
        val giftOptions = arrayOf(
            "إلنا الأسبوعي — 3,000 د.ع",
            "للكل لـ4 أسابيع — 15,000 د.ع",
            "إلنا لـ4 أسابيع — 25,000 د.ع",
            "للكل الأسبوعي — 4,000 د.ع",
            "للكل إضافي — 15,000 د.ع",
            "للكل إضافي+ — 20,000 د.ع",
            "MAX 25 — 25,000 د.ع",
            "MAX 35 — 35,000 د.ع",
            "MAX 6 — 6,000 د.ع",
            "MAX 12 — 12,000 د.ع",
            "MAX 55 — 55,000 د.ع",
            "فتح قائمة إهداء كل الباقات (USSD)"
        )
        val keys = listOf("9", "10", "11", "12", "13", "14", "25", "35", "66", "22", "55")
        AlertDialog.Builder(this)
            .setTitle("إهداء باقة لمشترك آخر")
            .setItems(giftOptions) { _, which ->
                if (which == giftOptions.lastIndex) {
                    openDialer("*336#")
                } else {
                    val phoneInput = EditText(this).apply {
                        hint = "رقم المستلم 07XXXXXXXXX"
                        inputType = android.text.InputType.TYPE_CLASS_PHONE
                        textDirection = View.TEXT_DIRECTION_LTR
                    }
                    AlertDialog.Builder(this)
                        .setTitle("رقم المستلم")
                        .setMessage("سيتم تجهيز SMS إلى 336 بالمفتاح ${keys[which]} ورقم المستلم. راجع الرسالة والسعر ثم اضغط إرسال.")
                        .setView(phoneInput)
                        .setPositiveButton("إعداد الرسالة") { _, _ ->
                            val phone = normalizeDigits(phoneInput.text.toString()).filter { it.isDigit() }
                            if (!(phone.startsWith("07") && phone.length in 10..11)) {
                                Toast.makeText(this, "أدخل رقم آسياسيل صحيحاً يبدأ بـ 07", Toast.LENGTH_LONG).show()
                            } else {
                                openSmsComposer("336", keys[which] + phone)
                            }
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showCallEctDialog() {
        val input = EditText(this).apply { hint = "رقم المستلم 077XXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("CALLect").setMessage("المستلم يسمع طلباً ويختار 1 لقبول دفع كلفة المكالمة أو 2 للرفض.")
            .setView(input).setPositiveButton("متابعة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً", Toast.LENGTH_LONG).show()
                else openDialer("#$number")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showCallForwardDialog() {
        val input = EditText(this).apply { hint = "رقم التحويل 07XXXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("تحويل المكالمات").setMessage("تفعيل التحويل مجاني، لكن قد تُحسب عليك تكلفة استقبال المكالمة المحولة. لإلغاء جميع التحويلات استخدم #002##.")
            .setView(input).setPositiveButton("تجهيز الكود") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً", Toast.LENGTH_LONG).show()
                else AlertDialog.Builder(this).setTitle("تأكيد رقم التحويل").setMessage("سيتم تجهيز *21*$number# في شاشة الاتصال. تأكد من الرقم قبل الضغط على اتصال.")
                    .setPositiveButton("فتح الاتصال") { _, _ -> openDialer("*21*$number#") }
                    .setNegativeButton("إلغاء", null).show()
            }.setNegativeButton("إلغاء", null).show()
    }
}
