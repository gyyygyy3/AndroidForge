# ملاحظات إصلاح مشكلة «التطبيق ليس مثبتاً»

## التعديل
تم تعديل `tools/package_installable_apk.py` لاستبدال توقيع `jarsigner` وحده بتوقيع Android SDK `apksigner`، مع تفعيل:
- APK Signature Scheme v1
- APK Signature Scheme v2
- APK Signature Scheme v3

ويتحقق السكربت الآن من التوقيع عبر `apksigner verify --verbose --print-certs` ثم يتحقق من محاذاة APK.

## متطلبات البناء
يلزم تثبيت Android SDK Build-Tools وإتاحة `apksigner` عبر PATH أو متغير `ANDROID_SDK_ROOT` أو `ANDROID_HOME`.

## ملاحظات مهمة
- لا يجوز تعديل أو إعادة ضغط ملف APK بعد توقيع v2/v3.
- يُستخدم مفتاح Debug محلي؛ إذا كانت نسخة موقعة بمفتاح مختلف مثبتة مسبقاً، احذفها قبل تثبيت النسخة الجديدة (بعد حفظ بياناتها).
- لم يتم تغيير منطق التطبيق أو ملفات DEX أو الموارد.
- هذا تعديل للمشروع، وليس APK مبنياً ومختبراً على جهاز فعلي.
