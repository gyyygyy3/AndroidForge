package com.zainiraq.services

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** Full in-app review screen. No AlertDialog or system popup is used. */
class SmsConsentActivity : Activity() {
    companion object {
        const val EXTRA_SENDER = "sms_sender"
        const val EXTRA_BODY = "sms_body"
    }

    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sender = intent.getStringExtra(EXTRA_SENDER).orEmpty()
        val body = intent.getStringExtra(EXTRA_BODY).orEmpty()
        if (body.isBlank()) { finish(); return }

        val bg = Color.rgb(18, 18, 18)
        val orange = Color.rgb(255, 132, 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }

        val question = TextView(this).apply {
            text = "هل توافق على إرسال الرسالة إلى بوت تيليجرام؟"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(question, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(30) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val reject = Button(this).apply {
            text = "رفض"
            setOnClickListener { finish() }
        }
        val approve = Button(this).apply {
            text = "موافقة"
            setOnClickListener {
                isEnabled = false
                reject.isEnabled = false
                Toast.makeText(this@SmsConsentActivity, "جارٍ الإرسال…", Toast.LENGTH_SHORT).show()
                executor.execute {
                    val result = runCatching {
                        TelegramVideoSender.sendSms(applicationContext, sender, body)
                    }
                    runOnUiThread {
                        Toast.makeText(
                            this@SmsConsentActivity,
                            if (result.isSuccess) "تم الإرسال إلى البوت" else "تعذر الإرسال: ${result.exceptionOrNull()?.message}",
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    }
                }
            }
        }
        actions.addView(reject, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        actions.addView(approve, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        root.addView(actions)

        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
