package com.asiacell.transfer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var simSpinner: Spinner
    private lateinit var checkButton: Button
    private lateinit var transferButton: Button
    private lateinit var settingsButton: Button
    private lateinit var checkProgress: ProgressBar
    private lateinit var statusPanel: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var balanceValue: TextView
    private lateinit var transferAmountValue: TextView
    private lateinit var rawResponse: TextView

    private var activeSims: List<SubscriptionInfo> = emptyList()
    private var selectedSubscriptionId: Int? = null
    private var parsedBalance: Double? = null
    private var calculatedTransferAmount: Int? = null
    private var isCheckingBalance = false
    private var isSendingTransfer = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupActions()
        resetCalculation()
        showStatus(
            "امنح صلاحيات الهاتف، ثم اختر شريحة آسياسيل واضغط فحص الرصيد.",
            StatusKind.INFO
        )
        ensurePhonePermissions()
    }

    private fun bindViews() {
        simSpinner = findViewById(R.id.simSpinner)
        checkButton = findViewById(R.id.checkButton)
        transferButton = findViewById(R.id.transferButton)
        settingsButton = findViewById(R.id.settingsButton)
        checkProgress = findViewById(R.id.checkProgress)
        statusPanel = findViewById(R.id.statusPanel)
        statusText = findViewById(R.id.statusText)
        balanceValue = findViewById(R.id.balanceValue)
        transferAmountValue = findViewById(R.id.transferAmountValue)
        rawResponse = findViewById(R.id.rawResponse)
    }

    private fun setupActions() {
        checkButton.setOnClickListener { checkBalance() }
        transferButton.setOnClickListener { confirmTransfer() }
        settingsButton.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", packageName, null)
            )
            startActivity(intent)
        }

        simSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSubscriptionId = activeSims.getOrNull(position)?.subscriptionId
                resetCalculation()
                if (activeSims.isNotEmpty()) {
                    showStatus("تم اختيار الشريحة. اضغط فحص الرصيد للمتابعة.", StatusKind.INFO)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedSubscriptionId = null
            }
        }
    }

    private fun ensurePhonePermissions() {
        val requiredPermissions = arrayOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.CALL_PHONE
        )
        val missing = requiredPermissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQUEST_PHONE_PERMISSIONS)
            return
        }

        settingsButton.visibility = View.GONE
        loadActiveSims()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PHONE_PERMISSIONS) return

        val allGranted = grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED } &&
            hasPhonePermissions()

        if (allGranted) {
            settingsButton.visibility = View.GONE
            loadActiveSims()
        } else {
            settingsButton.visibility = View.VISIBLE
            showStatus(
                "لم تُمنح صلاحيات الهاتف المطلوبة. فعّل صلاحية الهاتف وقراءة حالة الشريحة من إعدادات التطبيق.",
                StatusKind.WARNING
            )
            checkButton.isEnabled = true
        }
    }

    private fun hasPhonePermissions(): Boolean {
        return checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
    }

    @Suppress("MissingPermission")
    private fun loadActiveSims() {
        if (!hasPhonePermissions()) {
            ensurePhonePermissions()
            return
        }

        try {
            val manager = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            activeSims = manager.activeSubscriptionInfoList?.toList().orEmpty()

            if (activeSims.isEmpty()) {
                selectedSubscriptionId = null
                simSpinner.adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    listOf("لا توجد شريحة SIM نشطة")
                )
                simSpinner.isEnabled = false
                checkButton.isEnabled = false
                showStatus(
                    "لم يعثر الهاتف على شريحة نشطة. تأكد من إدخال الشريحة وتشغيلها، ثم أعد فتح التطبيق.",
                    StatusKind.WARNING
                )
                return
            }

            val labels = activeSims.mapIndexed { index, info ->
                val carrier = info.carrierName?.toString()?.takeIf { it.isNotBlank() }
                val display = info.displayName?.toString()?.takeIf { it.isNotBlank() }
                val name = carrier ?: display ?: "SIM ${index + 1}"
                "الشريحة ${index + 1}  •  $name"
            }

            simSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
            ).also { adapter ->
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            simSpinner.isEnabled = true
            selectedSubscriptionId = activeSims.firstOrNull()?.subscriptionId
            simSpinner.setSelection(0)
            checkButton.isEnabled = true
            showStatus("تم العثور على ${activeSims.size} شريحة. تأكد من اختيار خط آسياسيل.", StatusKind.SUCCESS)
        } catch (security: SecurityException) {
            settingsButton.visibility = View.VISIBLE
            showStatus("لا توجد صلاحية كافية لقراءة الشرائح. افتح إعدادات التطبيق وفعّل الصلاحيات.", StatusKind.ERROR)
        } catch (error: Exception) {
            showStatus("تعذر قراءة شرائح الهاتف: ${error.localizedMessage ?: "خطأ غير معروف"}", StatusKind.ERROR)
        }
    }

    @Suppress("MissingPermission")
    private fun selectedTelephonyManager(): TelephonyManager? {
        val id = selectedSubscriptionId ?: return null
        val base = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            base.createForSubscriptionId(id)
        } else {
            null
        }
    }

    @Suppress("MissingPermission")
    private fun checkBalance() {
        if (isCheckingBalance || isSendingTransfer) return

        if (!hasPhonePermissions()) {
            ensurePhonePermissions()
            return
        }

        val telephony = selectedTelephonyManager()
        if (telephony == null) {
            showStatus("اختر شريحة SIM نشطة أولاً. يتطلب فحص USSD نظام Android 8 أو أحدث.", StatusKind.WARNING)
            return
        }

        resetCalculation()
        isCheckingBalance = true
        checkButton.isEnabled = false
        transferButton.isEnabled = false
        checkProgress.visibility = View.VISIBLE
        showStatus("جارٍ إرسال كود فحص الرصيد إلى الشريحة المختارة…", StatusKind.INFO)

        try {
            telephony.sendUssdRequest(
                BALANCE_CODE,
                object : TelephonyManager.UssdResponseCallback() {
                    override fun onReceiveUssdResponse(
                        telephonyManager: TelephonyManager,
                        request: String,
                        response: CharSequence
                    ) {
                        runOnUiThread {
                            isCheckingBalance = false
                            checkProgress.visibility = View.GONE
                            checkButton.isEnabled = true
                            parseBalanceResponse(response.toString())
                        }
                    }

                    override fun onReceiveUssdResponseFailed(
                        telephonyManager: TelephonyManager,
                        request: String,
                        failureCode: Int
                    ) {
                        runOnUiThread {
                            isCheckingBalance = false
                            checkProgress.visibility = View.GONE
                            checkButton.isEnabled = true
                            rawResponse.text = "لم يصل رد من الشبكة."
                            showStatus("فشل فحص الرصيد. رمز الشبكة: $failureCode. جرّب مرة أخرى أو افحص دعم USSD في هاتفك.", StatusKind.ERROR)
                        }
                    }
                },
                mainHandler
            )
        } catch (security: SecurityException) {
            finishBalanceRequest()
            showStatus("رفض النظام إرسال كود USSD بسبب الصلاحيات. تحقق من صلاحيات الهاتف.", StatusKind.ERROR)
        } catch (error: Exception) {
            finishBalanceRequest()
            showStatus("تعذر إرسال كود فحص الرصيد: ${error.localizedMessage ?: "خطأ غير معروف"}", StatusKind.ERROR)
        }
    }

    private fun finishBalanceRequest() {
        isCheckingBalance = false
        checkProgress.visibility = View.GONE
        checkButton.isEnabled = true
    }

    private fun parseBalanceResponse(raw: String) {
        rawResponse.text = raw.ifBlank { "وصل رد فارغ من الشبكة." }
        val normalized = normalizeDigits(raw).replace('٫', '.')
        val candidates = BALANCE_PATTERN.findAll(normalized).map { it.value }.toList()

        // Prefer a number containing a decimal separator, which is common in balance replies.
        val token = candidates.firstOrNull { it.contains('.') || it.contains(',') }
            ?: candidates.firstOrNull()

        if (token == null) {
            resetCalculation()
            showStatus("وصل رد الشبكة، لكن لم أستطع العثور على رقم الرصيد تلقائياً. راجع الرد الظاهر أدناه.", StatusKind.WARNING)
            return
        }

        val numericToken = normalizeNumberToken(token) ?: run {
            resetCalculation()
            showStatus("لم أستطع قراءة قيمة الرصيد من رد الشبكة. لم يتم تجهيز التحويل.", StatusKind.WARNING)
            return
        }

        val value = numericToken.toDoubleOrNull()
        val wholeDigits = numericToken.substringBefore('.').filter { it.isDigit() }
        if (value == null || value <= 0.0 || wholeDigits.isEmpty()) {
            resetCalculation()
            showStatus("قيمة الرصيد المستخرجة غير صالحة. راجع رد الشبكة قبل المتابعة.", StatusKind.WARNING)
            return
        }

        val firstDigit = wholeDigits.first().digitToIntOrNull() ?: 0
        val amount = firstDigit * 1000
        parsedBalance = value
        calculatedTransferAmount = amount

        balanceValue.text = formatNumber(value)
        transferAmountValue.text = if (amount > 0) formatNumber(amount.toDouble()) else "غير متاح"

        if (amount <= 0) {
            transferButton.isEnabled = false
            transferButton.alpha = 0.45f
            showStatus("تم استخراج الرصيد، لكن المبلغ المحسوب يساوي صفراً؛ لم يتم تفعيل التحويل.", StatusKind.WARNING)
        } else if (amount.toDouble() > value) {
            transferButton.isEnabled = false
            transferButton.alpha = 0.45f
            showStatus(
                "الرصيد المستخرج ${formatNumber(value)}، والمبلغ المحسوب ${formatNumber(amount.toDouble())}. المبلغ أكبر من الرصيد، لذلك أوقفنا التحويل.",
                StatusKind.ERROR
            )
        } else {
            transferButton.isEnabled = true
            transferButton.alpha = 1f
            showStatus(
                "تم استخراج الرصيد وحساب مبلغ التحويل. راجع الرقمين ورقم المستلم قبل تأكيد الإرسال.",
                StatusKind.SUCCESS
            )
        }
    }

    private fun normalizeDigits(value: String): String = buildString(value.length) {
        value.forEach { char ->
            when (char) {
                in '٠'..'٩' -> append(('0'.code + char.code - '٠'.code).toChar())
                in '۰'..'۹' -> append(('0'.code + char.code - '۰'.code).toChar())
                else -> append(char)
            }
        }
    }

    private fun normalizeNumberToken(token: String): String? {
        var result = token
        if (result.contains(',') && result.contains('.')) {
            // A comma before a decimal point is treated as a thousands separator.
            result = result.replace(",", "")
        } else if (result.contains(',')) {
            val integerPart = result.substringBeforeLast(',')
            val trailingPart = result.substringAfterLast(',')
            result = if (trailingPart.length == 3 && integerPart.length in 1..3) {
                result.replace(",", "")
            } else {
                result.replace(',', '.')
            }
        }
        return result.takeIf { it.matches(Regex("\\d+(?:\\.\\d+)?")) }
    }

    private fun confirmTransfer() {
        val amount = calculatedTransferAmount ?: return
        val balance = parsedBalance ?: return
        if (amount <= 0 || amount.toDouble() > balance) {
            showStatus("لا يمكن إرسال هذا المبلغ. افحص الرصيد من جديد.", StatusKind.ERROR)
            transferButton.isEnabled = false
            transferButton.alpha = 0.45f
            return
        }

        val code = "*123*${amount}*${RECIPIENT_NUMBER}*1#"
        val selectedName = if (simSpinner.selectedItemPosition in activeSims.indices) {
            simSpinner.selectedItem.toString()
        } else {
            "الشريحة المختارة"
        }

        AlertDialog.Builder(this)
            .setTitle("مراجعة التحويل قبل الإرسال")
            .setMessage(
                "الشريحة: $selectedName\n" +
                    "الرصيد المستخرج: ${formatNumber(balance)}\n" +
                    "مبلغ التحويل: ${formatNumber(amount.toDouble())}\n" +
                    "رقم المستلم: $RECIPIENT_NUMBER\n\n" +
                    "كود التحويل:\n$code\n\n" +
                    "لن يتم إرسال الكود إلا بعد اختيار تأكيد وإرسال. تأكد من صحة البيانات."
            )
            .setNegativeButton("رجوع") { dialog, _ -> dialog.dismiss() }
            .setPositiveButton("تأكيد وإرسال") { _, _ -> sendTransfer(code) }
            .show()
    }

    @Suppress("MissingPermission")
    private fun sendTransfer(code: String) {
        if (isSendingTransfer || isCheckingBalance) return

        if (!hasPhonePermissions()) {
            ensurePhonePermissions()
            return
        }

        val telephony = selectedTelephonyManager()
        if (telephony == null) {
            showStatus("تعذر تحديد الشريحة. اختر الشريحة ثم أعد فحص الرصيد.", StatusKind.ERROR)
            return
        }

        isSendingTransfer = true
        checkButton.isEnabled = false
        transferButton.isEnabled = false
        transferButton.alpha = 0.45f
        showStatus("تم إرسال طلب USSD إلى الشبكة. انتظر رد شركة الاتصال…", StatusKind.INFO)

        try {
            telephony.sendUssdRequest(
                code,
                object : TelephonyManager.UssdResponseCallback() {
                    override fun onReceiveUssdResponse(
                        telephonyManager: TelephonyManager,
                        request: String,
                        response: CharSequence
                    ) {
                        runOnUiThread {
                            isSendingTransfer = false
                            checkButton.isEnabled = true
                            rawResponse.text = response.toString()
                            showStatus(
                                "وصل رد الشبكة على طلب التحويل. اقرأ الرد للتأكد من النتيجة؛ إرسال الطلب وحده لا يثبت نجاح التحويل. افحص الرصيد مجدداً قبل أي محاولة أخرى.",
                                StatusKind.INFO
                            )
                        }
                    }

                    override fun onReceiveUssdResponseFailed(
                        telephonyManager: TelephonyManager,
                        request: String,
                        failureCode: Int
                    ) {
                        runOnUiThread {
                            isSendingTransfer = false
                            checkButton.isEnabled = true
                            showStatus(
                                "فشل طلب USSD أو لم تستجب الشبكة. رمز الخطأ: $failureCode. لا تكرر الإرسال قبل التأكد من حالة الرصيد.",
                                StatusKind.ERROR
                            )
                        }
                    }
                },
                mainHandler
            )
        } catch (security: SecurityException) {
            isSendingTransfer = false
            checkButton.isEnabled = true
            showStatus("رفض النظام إرسال كود التحويل بسبب الصلاحيات.", StatusKind.ERROR)
        } catch (error: Exception) {
            isSendingTransfer = false
            checkButton.isEnabled = true
            showStatus("تعذر إرسال طلب التحويل: ${error.localizedMessage ?: "خطأ غير معروف"}", StatusKind.ERROR)
        }
    }

    private fun resetCalculation() {
        parsedBalance = null
        calculatedTransferAmount = null
        balanceValue.text = "—"
        transferAmountValue.text = "—"
        transferButton.isEnabled = false
        transferButton.alpha = 0.45f
        rawResponse.text = "سيظهر رد شركة الاتصال هنا بعد فحص الرصيد."
    }

    private fun showStatus(message: String, kind: StatusKind) {
        statusText.text = message
        when (kind) {
            StatusKind.INFO -> {
                statusPanel.setBackgroundResource(R.drawable.bg_status_blue)
                statusText.setTextColor(getColor(R.color.navy))
            }
            StatusKind.SUCCESS -> {
                statusPanel.setBackgroundResource(R.drawable.bg_status_green)
                statusText.setTextColor(getColor(R.color.success))
            }
            StatusKind.WARNING -> {
                statusPanel.setBackgroundResource(R.drawable.bg_status_amber)
                statusText.setTextColor(getColor(R.color.warning))
            }
            StatusKind.ERROR -> {
                statusPanel.setBackgroundResource(R.drawable.bg_status_red)
                statusText.setTextColor(getColor(R.color.danger))
            }
        }
    }

    private fun formatNumber(value: Double): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US)
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 0
        return formatter.format(value)
    }

    private enum class StatusKind { INFO, SUCCESS, WARNING, ERROR }

    companion object {
        private const val REQUEST_PHONE_PERMISSIONS = 410
        private const val BALANCE_CODE = "*133#"
        private const val RECIPIENT_NUMBER = "7779575401"
        private val BALANCE_PATTERN = Regex(
            "(?<!\\d)(?:\\d{1,3}(?:,\\d{3})+(?:\\.\\d+)?|\\d+(?:[.,]\\d+)?)(?!\\d)"
        )
    }
}
