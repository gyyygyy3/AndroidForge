import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.zainiraq.offers',
  appName: 'عروض وخدمات زين العراق',
  webDir: 'out',
  backgroundColor: '#ffffff',
  server: {
    androidScheme: 'https',
  },
};

export default config;
