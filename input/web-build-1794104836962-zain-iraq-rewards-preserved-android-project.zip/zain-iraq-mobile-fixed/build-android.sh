#!/usr/bin/env bash
set -euo pipefail

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if (( NODE_MAJOR < 22 )); then
  echo "Node.js 22 أو أحدث مطلوب." >&2
  exit 1
fi

if [[ ! -d node_modules ]]; then
  npm install
fi

npm run build:web

if [[ ! -d android ]]; then
  npm run android:setup
fi

npx cap sync android
cd android
chmod +x ./gradlew
./gradlew assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "لم يتم العثور على APK بعد انتهاء Gradle." >&2
  exit 1
fi
echo "تم إنشاء APK بنجاح: $(pwd)/$APK"
