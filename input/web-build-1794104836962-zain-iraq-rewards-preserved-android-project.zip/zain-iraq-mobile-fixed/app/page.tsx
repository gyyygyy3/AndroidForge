"use client";

import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

type Screen = "welcome" | "method" | "phone" | "verify" | "pending" | "home";
type ServiceItem = {
  id: string;
  title: string;
  description: string;
  icon: string;
  tone: string;
  group: string;
  sourceUrl: string;
  label?: string;
  image?: string;
};

type Offer = {
  id: string;
  title: string;
  description: string;
  image: string;
  tag: string;
  category: string;
  source: string;
  sourceUrl: string;
  price?: number;
  internet?: string;
  minutes?: string;
  sms?: string;
  validity?: string;
  includes?: string[];
  note?: string;
  featured?: boolean;
  code?: string;
}

const officialAssets = {
  kafoo: "https://web-api.iq.zain.com/storage/app/uploads/public/69f/9e3/78c/69f9e378c3a84917156135.png",
  kafooCampaign: "https://d27ne1peune2h7.cloudfront.net/media/images/Kafoo.original.webp",
  app: "https://web-api.iq.zain.com/storage/app/uploads/public/676/d4f/5ed/676d4f5ed05a8146694765.png",
  freeSocial: "https://web-api.iq.zain.com/storage/app/uploads/public/66e/fe1/717/66efe1717d609843989258.jpg",
  freeSocialAlt: "https://web-api.iq.zain.com/storage/app/uploads/public/639/ecc/c4a/639eccc4aaa7d292587603.jpg",
  superCard: "https://web-api.iq.zain.com/storage/app/uploads/public/67b/1d3/ec0/67b1d3ec071f1335526342.png",
  superCardAlt: "https://web-api.iq.zain.com/storage/app/uploads/public/687/e04/738/687e0473826db512604349.png",
  bekefi: "https://web-api.iq.zain.com/storage/app/uploads/public/64e/ae6/cfe/64eae6cfe7a96135761801.jpg",
  openInternet: "https://web-api.iq.zain.com/storage/app/uploads/public/6a2/463/d25/6a2463d25ea68803034620.png",
  nitroFlyer: "https://www.iq.zain.com/storage/app/media/Flyers/Refresh%20Artwork/Unified-UL_Web-Page_Unified-UL_1200x1200px_Ar-min.jpg",
  roaming: "https://web-api.iq.zain.com/storage/app/uploads/public/678/509/a23/678509a232474735101611.png",
  gift: "https://www.iq.zain.com/_ipx/h_450/images/home/gift-new.png",
  zainFi: "https://web-api.iq.zain.com/storage/app/uploads/public/6ab/a36/4b6/6aba364b64a10888930352.png",
  worldOffers: "https://web-api.iq.zain.com/storage/app/uploads/public/687/cb9/768/687cb97685cd3354831832.png",
  tenTen: "https://web-api.iq.zain.com/storage/app/uploads/public/680/f6f/4d3/680f6f4d35d0f825456963.png",
  doubled: "https://web-api.iq.zain.com/storage/app/uploads/public/67b/1d9/37e/67b1d937eba2a055381401.png",
  foulFoul: "https://web-api.iq.zain.com/storage/app/uploads/public/6a2/460/f8e/6a2460f8e2ee9776541781.png",
  tiktok: "https://web-api.iq.zain.com/storage/app/uploads/public/6a2/463/218/6a2463218bb4c798098182.png",
  specialNumbers: "https://web-api.iq.zain.com/storage/app/uploads/public/69c/cc9/545/69ccc954551d9490410379.jpg",
  primePlus: "https://web-api.iq.zain.com/storage/app/uploads/public/6ae/9ab/6fe/6ae9ab6fe57b0659717870.png",
  giftInternet: "https://web-api.iq.zain.com/storage/app/uploads/public/67b/1dc/e52/67b1dce529a02440327214.png",
  zainFi2Cat7: "https://web-api.iq.zain.com/storage/app/uploads/public/6a6/71e/354/6a671e3540218505014125.png",
  zainFi2Cat4: "https://web-api.iq.zain.com/storage/app/uploads/public/6a6/71e/491/6a671e4914df4761469921.png",
  zainFiCat4: "https://web-api.iq.zain.com/storage/app/uploads/public/6aa/f8e/080/6aaf8e080f18e402253090.png",
  zainFiCat7: "https://web-api.iq.zain.com/storage/app/uploads/public/691/049/3b2/6910493b24958924165974.png",
  tiktokCurrent: "https://web-api.iq.zain.com/storage/app/uploads/public/6a2/462/7e2/6a24627e2206c157989394.png",
  foulFoulCurrent: "https://web-api.iq.zain.com/storage/app/uploads/public/6a2/460/d1e/6a2460d1ebd15294632271.png",
  doubleRecharge: "https://web-api.iq.zain.com/storage/app/uploads/public/63a/d85/115/63ad85115dab2984103930.jpg",
  fadshiii1001: "https://web-api.iq.zain.com/storage/app/uploads/public/6a0/18c/fdd/6a018cfddf4c2023604232.png",
  lebanonRoaming: "https://web-api.iq.zain.com/storage/app/uploads/public/6ab/127/462/6ab1274628df2655214192.png",
  kurdistanOpen: "https://web-api.iq.zain.com/storage/app/uploads/public/698/30b/865/69830b865f236503521264.jpg",
  iphoneDuo: "https://web-api.iq.zain.com/storage/app/uploads/public/6ae/35f/7d4/6ae35f7d42e5d596264629.png",
  samsungBundle: "https://web-api.iq.zain.com/storage/app/uploads/public/6a9/7ed/311/6a97ed311e9af551418902.png",
  walletCard: "https://web-api.iq.zain.com/storage/app/uploads/public/5d5/e86/691/5d5e866910680941773293.jpg",
  reehBalak: "https://web-api.iq.zain.com/storage/app/uploads/public/5d5/d15/939/5d5d159390812017750151.jpg",
  balanceValidity: "https://web-api.iq.zain.com/storage/app/uploads/public/5d5/d1a/b75/5d5d1ab753fc2886790694.jpg",
  esim: "https://web-api.iq.zain.com/storage/app/uploads/public/687/5f5/2a0/6875f52a08928087862524.png",
  personalizedCurrent: "https://web-api.iq.zain.com/storage/app/uploads/public/687/5f5/054/6875f50545626129802319.png",
  samsungA06: "https://web-api.iq.zain.com/storage/app/uploads/public/68c/2b2/249/68c2b224929a3484270214.png",
  honorMagicV5: "https://web-api.iq.zain.com/storage/app/uploads/public/698/c79/36e/698c7936e136f650128599.png",
  galaxyFold7: "https://web-api.iq.zain.com/storage/app/uploads/public/68a/190/ba8/68a190ba81e09307699317.png",
};

const categories = [
  { title: "الإنترنت", subtitle: "باقات يومية وشهرية", icon: "◉", tone: "violet" },
  { title: "كفوو", subtitle: "رصيد ومزايا أكثر", icon: "✦", tone: "aqua" },
  { title: "سوبر كارد", subtitle: "دقائق ورسائل وبيانات", icon: "▣", tone: "pink" },
  { title: "بكيفي", subtitle: "اختر الباقة المناسبة", icon: "◈", tone: "orange" },
  { title: "التجوال", subtitle: "ابقَ متصلاً أثناء السفر", icon: "✈", tone: "blue" },
  { title: "زين فاي", subtitle: "إنترنت منزلي ومتنقل", icon: "⌁", tone: "mint" },
  { title: "الدفع الآجل", subtitle: "Prime Plus وباقات إضافية", icon: "▤", tone: "purple" },
  { title: "ممنون", subtitle: "نقاط ومكافآت", icon: "♡", tone: "gold" },
  { title: "كفوو العائلة", subtitle: "رصيد ومزايا للمجموعة", icon: "♧", tone: "mint" },
  { title: "تيك توك", subtitle: "باقات يومية وأسبوعية", icon: "♪", tone: "pink" },
  { title: "فوول الفوول", subtitle: "عروض مناطق محددة", icon: "✹", tone: "orange" },
  { title: "عروض المناطق", subtitle: "باقات مرتبطة بالمحافظة", icon: "⌖", tone: "blue" },
  { title: "عروض خاصة", subtitle: "شحن وهدايا وحملات", icon: "✦", tone: "purple" },
  { title: "أجهزة وعروض", subtitle: "عروض الهواتف والأجهزة", icon: "▣", tone: "blue" },
  { title: "الخدمات", subtitle: "أكواد وخدمات إضافية", icon: "＋", tone: "gray" },
];

const internetUrl = "https://www.iq.zain.com/ar/prepaid/data-only-offers";
const freeSocialUrl = "https://www.iq.zain.com/ar/prepaid/data-only-offers";
const openInternetUrl = "https://www.iq.zain.com/ar/prepaid/data-only-offers";
const kafooUrl = "https://www.iq.zain.com/ar/prepaid/kafoo";
const comboUrl = "https://www.iq.zain.com/ar/prepaid/voice-and-data-offers";
const roamingUrl = "https://www.iq.zain.com/ar/prepaid/roaming-and-international-offers";
const offersUrl = "https://www.iq.zain.com/ar/offers";

const offers: Offer[] = [
  // باقات الإنترنت +4.5G وFree Social المنشورة في صفحة زين
  { id: "data-day-300", title: "يومي 300 ميگابايت + Free Social", description: "300 ميگابايت مع استخدام مجاني لواتساب وفايبر وفق شروط الباقة.", image: officialAssets.freeSocial, tag: "يومي", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 1250, internet: "300 ميگابايت", validity: "يوم واحد", code: "رمز 41 برسالة إلى 21777", includes: ["واتساب", "فايبر"] },
  { id: "data-day-600", title: "يومي 600 ميگابايت + Free Social", description: "600 ميگابايت مع استخدام مجاني لواتساب وفايبر وفق شروط الباقة.", image: officialAssets.freeSocialAlt, tag: "يومي", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 2000, internet: "600 ميگابايت", validity: "يوم واحد", code: "رمز 42 برسالة إلى 21777", includes: ["واتساب", "فايبر"] },
  { id: "data-week-3", title: "أسبوعي 3 گيگابايت + Free Social", description: "باقة أسبوعية تتضمن فيسبوك وفايبر وواتساب مجاناً وفق شروط الاستخدام.", image: officialAssets.freeSocialAlt, tag: "7 أيام", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 5000, internet: "3 گيگابايت", validity: "7 أيام", code: "رمز 43 برسالة إلى 21777", includes: ["فيسبوك", "فايبر", "واتساب"] },
  { id: "data-week-5", title: "أسبوعي 5 گيگابايت + Free Social", description: "5 گيگابايت لمدة أسبوع مع تطبيقات التواصل المشمولة.", image: officialAssets.freeSocial, tag: "7 أيام", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 7000, internet: "5 گيگابايت", validity: "7 أيام", code: "رمز 44 برسالة إلى 21777", includes: ["واتساب", "فايبر", "فيسبوك", "سناب چات"] },
  { id: "data-month-5", title: "5 گيگابايت + Free Social", description: "باقة بمدة أربعة أسابيع مع تطبيقات التواصل الاجتماعي المشمولة.", image: officialAssets.freeSocial, tag: "4 أسابيع", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 10000, internet: "5 گيگابايت", validity: "4 أسابيع", code: "رمز 45 برسالة إلى 21777", includes: ["واتساب", "فايبر", "فيسبوك", "سناب چات"] },
  { id: "data-month-6", title: "شهري 6 گيگابايت + Free Social", description: "6 گيگابايت بصلاحية 30 يوماً مع تطبيقات التواصل المشمولة.", image: officialAssets.freeSocialAlt, tag: "30 يوماً", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 12000, internet: "6 گيگابايت", validity: "30 يوماً", code: "رمز 55 برسالة إلى 21777", includes: ["واتساب", "فايبر", "فيسبوك", "سناب چات"] },
  { id: "data-month-10", title: "10 گيگابايت + Free Social", description: "10 گيگابايت بصلاحية أربعة أسابيع مع تطبيقات التواصل المشمولة.", image: officialAssets.freeSocial, tag: "4 أسابيع", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 15000, internet: "10 گيگابايت", validity: "4 أسابيع", code: "رمز 46 برسالة إلى 21777", includes: ["فيسبوك", "فايبر", "واتساب", "سناب چات"] },
  { id: "data-month-20", title: "20 گيگابايت + Free Social", description: "20 گيگابايت مع تطبيقات اجتماعية مشمولة وهدية منصة 1001 حسب شروط العرض.", image: officialAssets.freeSocialAlt, tag: "هدية 1001", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 25000, internet: "20 گيگابايت", validity: "4 أسابيع", code: "رمز 47 برسالة إلى 21777", includes: ["واتساب", "فايبر", "فيسبوك", "سناب چات", "يوتيوب", "اشتراك 1001 لمدة شهر"] },
  { id: "data-month-30", title: "30 گيگابايت + Free Social", description: "30 گيگابايت مع مجموعة موسعة من تطبيقات التواصل والفيديو.", image: officialAssets.freeSocial, tag: "4 أسابيع", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 30000, internet: "30 گيگابايت", validity: "4 أسابيع", code: "رمز 48 برسالة إلى 21777", includes: ["واتساب", "فايبر", "فيسبوك", "يوتيوب", "سناب چات", "إنستغرام", "تيك توك", "اشتراك 1001 لمدة شهر"] },
  { id: "data-month-50", title: "50 گيگابايت + Free Social", description: "50 گيگابايت بصلاحية أربعة أسابيع، مع تطبيقات التواصل المشمولة.", image: officialAssets.freeSocialAlt, tag: "سعة كبيرة", category: "الإنترنت", source: "زين العراق", sourceUrl: freeSocialUrl, price: 35000, internet: "50 گيگابايت", validity: "4 أسابيع", code: "رمز 51 برسالة إلى 21777", includes: ["واتساب", "فايبر", "فيسبوك", "يوتيوب", "سناب چات", "إنستغرام", "تيك توك", "اشتراك 1001 لمدة شهر"] },

  // الإنترنت المفتوح: تفاصيل حد السرعة موضحة كما وردت في صفحة الباقات
  { id: "open-day", title: "إنترنت يومي مفتوح", description: "3 گيگابايت بسرعة +4.5G، ثم استمرار بسرعة تصل إلى 3 ميگابت/ثانية.", image: officialAssets.openInternet, tag: "مفتوح يومي", category: "الإنترنت", source: "زين العراق", sourceUrl: openInternetUrl, price: 3000, internet: "3 گيگابايت بسرعة +4.5G ثم حتى 3 Mbps", validity: "24 ساعة", code: "رمز 10 إلى 21777 · إلغاء 010", note: "وصف (مفتوح) يخضع لسياسة السرعة المذكورة في تفاصيل الباقة." },
  { id: "open-week", title: "إنترنت أسبوعي مفتوح", description: "20 گيگابايت بسرعة +4.5G، ثم استمرار بسرعة تصل إلى 3 ميگابت/ثانية.", image: officialAssets.nitroFlyer, tag: "مفتوح أسبوعي", category: "الإنترنت", source: "زين العراق", sourceUrl: openInternetUrl, price: 12000, internet: "20 گيگابايت بسرعة +4.5G ثم حتى 3 Mbps", validity: "7 أيام", code: "رمز 20 إلى 21777 · إلغاء 020", note: "وصف (مفتوح) يخضع لسياسة السرعة المذكورة في تفاصيل الباقة." },
  { id: "open-40", title: "إنترنت مفتوح 40", description: "100 گيگابايت بسرعة الجيل الرابع، ثم استمرار بسرعة تصل إلى 3 ميگابت/ثانية.", image: officialAssets.openInternet, tag: "4 أسابيع", category: "الإنترنت", source: "زين العراق", sourceUrl: openInternetUrl, price: 40000, internet: "100 گيگابايت بسرعة +4.5G ثم حتى 3 Mbps", validity: "4 أسابيع", code: "رمز 40 إلى 21777 · إلغاء 040", includes: ["هدية اشتراك فدشييي على 1001 لمدة شهر"], note: "تختلف صلاحية الإهداء عن صلاحية الاشتراك حسب نوع خط المستلم." },
  { id: "open-45", title: "إنترنت مفتوح 45", description: "150 گيگابايت بسرعة الجيل الرابع، ثم استمرار بسرعة تصل إلى 3 ميگابت/ثانية.", image: officialAssets.nitroFlyer, tag: "30 يوماً", category: "الإنترنت", source: "زين العراق", sourceUrl: openInternetUrl, price: 45000, internet: "150 گيگابايت بسرعة +4.5G ثم حتى 3 Mbps", validity: "30 يوماً", code: "رمز 54 إلى 21777 · إلغاء 054", includes: ["هدية اشتراك فدشييي على 1001 لمدة شهر"], note: "وصف (مفتوح) يخضع لسياسة السرعة المذكورة في تفاصيل الباقة." },
  { id: "open-50", title: "نايترو مفتوح 50", description: "250 گيگابايت بسرعة +4.5G، وبعدها استمرار بسرعة تصل إلى 5 ميگابت/ثانية.", image: officialAssets.nitroFlyer, tag: "نايترو", category: "الإنترنت", source: "زين العراق", sourceUrl: openInternetUrl, price: 50000, internet: "250 گيگابايت بسرعة +4.5G ثم حتى 5 Mbps", validity: "4 أسابيع", code: "رمز 57 إلى 21777 · إلغاء 057", includes: ["هدية اشتراك فدشييي على 1001 لمدة شهر"], note: "تطبق سياسة الاستخدام العادل والسرعة المذكورة في شروط زين." },
  { id: "open-60", title: "ألترا مفتوح 60", description: "350 گيگابايت بسرعة +4.5G، وبعدها استمرار بسرعة تصل إلى 5 ميگابت/ثانية.", image: officialAssets.openInternet, tag: "ألترا", category: "الإنترنت", source: "زين العراق", sourceUrl: openInternetUrl, price: 60000, internet: "350 گيگابايت بسرعة +4.5G ثم حتى 5 Mbps", validity: "30 يوماً", code: "رمز 60 إلى 21777 · إلغاء 060", includes: ["هدية اشتراك فدشييي على 1001 لمدة شهر"], note: "تطبق سياسة الاستخدام العادل والسرعة المذكورة في شروط زين." },
  { id: "kurdistan-open-two-months", title: "إنترنت مفتوح لشهرين – كردستان", description: "باقة خاصة لمشتركي دهوك وأربيل والسليمانية: 100GB شهرياً داخل كردستان ثم سرعة تصل إلى 3Mbps، مع 5GB خارج الإقليم و60 دقيقة محلية.", image: officialAssets.kurdistanOpen, tag: "كردستان فقط · 60 يوماً", category: "عروض المناطق", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/prepaid-category/offers/2-months-ul-kurdistan-offer", price: 30000, internet: "100GB كل شهر داخل كردستان + 5GB خارجها", minutes: "60 دقيقة لكل الشبكات المحلية", validity: "60 يوماً", code: "إرسال 136 إلى 21777 · إلغاء 0136", note: "العرض لمشتركي دهوك وأربيل والسليمانية فقط. الإنترنت المفتوح بسرعة +4.5G داخل كردستان، وبعد استهلاك 100GB شهرياً تطبق سرعة تصل إلى 3Mbps. لا يمكن جمعه مع عروض الإنترنت المفتوح الأخرى." },

  // عروض كفوو: الرصيد المجاني، الرسائل، الصلاحية
  ...[
    ["5",5000,"12,500","25","7 أيام",officialAssets.kafoo],
    ["10",10000,"25,000","50","20 يوماً",officialAssets.kafooCampaign],
    ["15",15000,"45,000","100","4 أسابيع",officialAssets.kafoo],
    ["18",18000,"50,000","250","30 يوماً",officialAssets.kafooCampaign],
    ["20",20000,"60,000","150","4 أسابيع",officialAssets.kafoo],
    ["25",25000,"90,000","200","4 أسابيع",officialAssets.kafooCampaign],
    ["30",30000,"120,000","250","4 أسابيع",officialAssets.kafoo],
    ["40",40000,"160,000","1,000","30 يوماً",officialAssets.kafooCampaign],
  ].map(([number, price, credit, sms, validity, image]) => {
    const socialByPlan: Record<string, string[]> = {
      "10": ["فيسبوك", "واتساب"],
      "15": ["فيسبوك", "واتساب", "سناب چات", "إنستغرام"],
      "18": ["فيسبوك", "واتساب", "سناب چات", "إنستغرام"],
      "20": ["فيسبوك", "واتساب", "فايبر", "سناب چات", "إنستغرام"],
      "25": ["فيسبوك", "واتساب", "فايبر", "سناب چات", "إنستغرام", "تيك توك"],
      "30": ["فيسبوك", "واتساب", "فايبر", "يوتيوب", "سناب چات", "إنستغرام", "تيك توك"],
      "40": ["فيسبوك", "واتساب", "سناب چات", "إنستغرام", "تيليگرام", "تيك توك", "يوتيوب"],
    };
    const extras = socialByPlan[String(number)] ?? [];
    return {
      id: `kafoo-${number}`, title: `كفوو ${number}`, description: `باقة كفوو برصيد مجاني ${credit} دينار ورسائل مجانية ${sms} رسالة.`, image: String(image), tag: "رصيد ومكالمات", category: "كفوو", source: "زين العراق", sourceUrl: kafooUrl, price: Number(price), internet: `رصيد مجاني ${credit} د.ع`, sms: `${sms} رسالة`, validity: String(validity), code: "الاشتراك عبر #285* أو تطبيق زين", includes: ["رصيد للمكالمات والإنترنت والرسائل", ...(extras.length ? [`تطبيقات مجانية: ${extras.join("، ")}`] : []), ...(Number(price) >= 20000 ? ["زيادة رصيد 20% عند الاشتراك من تطبيق زين وفق شروط العرض"] : []), ...(Number(price) >= 25000 ? ["هدية اشتراك فدشييي على منصة 1001 لمدة شهر وفق الأهلية"] : [])], note: extras.length ? "الاستخدام المجاني للتطبيقات لا يشمل المكالمات الصوتية أو مكالمات الفيديو أو نقطة الاتصال (Hotspot). مزايا الزيادة وهدية 1001 تخضع لشروط زين." : "تفاصيل تطبيقات التواصل المجانية غير مذكورة لهذه الباقة؛ راجع الشروط الرسمية."
    } as Offer;
  }),

  // سوبر كارد
  ...[
    ["12",12000,"5 گيگابايت","180","180","7 أيام"],
    ["15",15000,"6 گيگابايت","150","250","30 يوماً"],
    ["25",25000,"8 گيگابايت","500","500","4 أسابيع"],
    ["35",35000,"20 گيگابايت","720","720","4 أسابيع"],
    ["50",50000,"50 گيگابايت","1,000","1,000","4 أسابيع"],
    ["60",60000,"60 گيگابايت","1,200","1,200","30 يوماً"],
  ].map(([number, price, data, minutes, sms, validity], index) => ({
    id: `super-${number}`, title: `سوبر كارد ${number}`, description: `باقة تجمع ${data} إنترنت و${minutes} دقيقة و${sms} رسالة ضمن زين والشبكات المحلية الأخرى.`, image: index % 2 ? officialAssets.superCardAlt : officialAssets.superCard, tag: "إنترنت + دقائق + رسائل", category: "سوبر كارد", source: "زين العراق", sourceUrl: comboUrl, price: Number(price), internet: String(data), minutes: `${minutes} دقيقة`, sms: `${sms} رسالة`, validity: String(validity), code: "الاتصال على #221* أو تطبيق زين", includes: Number(price) >= 25000 ? ["هدية اشتراك لمدة شهر في باقة فدشييي على منصة 1001"] : [], note: "طرق الاشتراك المنشورة: الاتصال على #221* لاختيار الباقة، أو إرسال رمز الاشتراك برسالة إلى 2122، أو استخدام تطبيق زين. التجديد تلقائي عند توفر رصيد كافٍ."
  } as Offer)),

  // بكيفي: خيارات مرنة للدقائق والإنترنت
  ...[
    ["الأسبوعية 4",4000,"1 گيگابايت","45", "—", "7 أيام"],
    ["الأسبوعية 6",6000,"1.5 گيگابايت","90", "30", "7 أيام"],
    ["15 - 3GB",15000,"3 گيگابايت","240", "—", "4 أسابيع"],
    ["15 - 4GB",15000,"4 گيگابايت","210", "50", "4 أسابيع"],
    ["20",20000,"4 گيگابايت","360", "—", "4 أسابيع"],
    ["25",25000,"2 گيگابايت","720", "150", "4 أسابيع"],
    ["55",55000,"30 گيگابايت","840", "150", "4 أسابيع"],
  ].map(([name, price, data, minutes, sms, validity], index) => ({
    id: `bekefi-${index}`, title: `بكيفي ${name}`, description: `باقة بكيفي تتضمن ${data} إنترنت و${minutes} دقيقة${sms !== "—" ? ` و${sms} رسالة` : ""}.`, image: officialAssets.bekefi, tag: "اختر ما يناسبك", category: "بكيفي", source: "زين العراق", sourceUrl: comboUrl, price: Number(price), internet: String(data), minutes: `${minutes} دقيقة`, sms: sms === "—" ? undefined : `${sms} رسالة`, validity: String(validity), code: "الاتصال على #221* أو تطبيق زين", includes: Number(price) >= 25000 ? ["اشتراك فدشييي على منصة 1001 لمدة شهر وفق شروط العرض"] : [], note: "تظهر بعض خيارات بكيفي مرتين بسعر 15,000 مع مزيج مختلف من البيانات والدقائق والرسائل. هدية 1001 مشروطة بأهلية الباقة والخط."
  } as Offer)),

  // عروض ترويجية منشورة في قسم العروض. بعض الحملات مرتبطة بالأهلية أو فترة ترويجية.
  { id: "ten-ten", title: "باقة 10/10", description: "إعلان زين عن 10 گيگابايت مع سوشيال ميديا مجاني مقابل 10,000 دينار لمدة أسبوعين.", image: officialAssets.tenTen, tag: "عرض ترويجي", category: "عروض خاصة", source: "زين العراق", sourceUrl: offersUrl, price: 10000, internet: "10 گيگابايت", validity: "أسبوعان", includes: ["سوشيال ميديا مجاني وفق شروط الإعلان"], note: "يرجى مراجعة صفحة العروض الرسمية للتأكد من استمرار الحملة وأهليتها قبل الاشتراك." },
  { id: "double-credit", title: "عرض الأضعاف للمشتركين الجدد", description: "عرض ترويجي مخصص للمشتركين الجدد؛ مقدار الرصيد الإضافي وشروط الاستحقاق تحددها الحملة الحالية.", image: officialAssets.doubled, tag: "للمشتركين الجدد", category: "عروض خاصة", source: "زين العراق", sourceUrl: offersUrl, note: "الأهلية وشروط الاستفادة قد تختلف. لم نضع رقماً للرصيد الإضافي دون تفاصيل مؤكدة." },
  ...[
    ["5GB",5000,"5 گيگابايت","4,000 د.ع","7 أيام","فوول الفوول 5","116","0116"],
    ["10GB",10000,"10 گيگابايت","10,000 د.ع","4 أسابيع","فوول الفوول 10","137","0137"],
    ["20GB",15000,"20 گيگابايت","15,000 د.ع","4 أسابيع","فوول الفوول 15","117","0117"],
  ].map(([id, price, data, extra, validity, title, code, cancel]) => ({
    id: `foul-${id}`, title: String(title), description: `باقة فوول الفوول تتضمن ${data} ورصيداً إضافياً بقيمة ${extra}.`, image: officialAssets.foulFoulCurrent, tag: "عرض لمناطق محددة", category: "فوول الفوول", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/fool-al-fool-bundle-more-internet-credit-better-price", price: Number(price), internet: String(data), validity: String(validity), code: `رمز الاشتراك ${code} برسالة إلى 2117 · إلغاء التجديد ${cancel}`, includes: [`رصيد إضافي ${extra}`], note: "العرض مقيّد بمحافظات محددة: أربيل ودهوك والسليمانية لجميع هذه المستويات، وتضاف الموصل وكركوك لبعض المستويات بحسب الجدول الرسمي. راجع توفر منطقتك قبل الاشتراك."
  } as Offer)),
  { id: "foul-2plus1", title: "فوول الفوول – عرض 2+1", description: "ثلاث دورات من باقة 20 گيگابايت ورصيد إضافي 15,000 دينار لكل دورة مقابل 30,000 دينار وفق شروط الحملة.", image: officialAssets.foulFoulCurrent, tag: "3 دورات", category: "فوول الفوول", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/fool-al-fool-bundle-more-internet-credit-better-price", price: 30000, internet: "20 گيگابايت لكل دورة", validity: "3 × 4 أسابيع", code: "رمز العرض 167 برسالة إلى 2117", includes: ["رصيد إضافي 15,000 د.ع لكل دورة", "ثلاثة اشتراكات ضمن عرض 2+1"], note: "عرض مقيّد بمحافظات أربيل ودهوك والسليمانية والموصل وكركوك. لا يوجد تجديد تلقائي لهذا العرض الثلاثي بحسب تفاصيل الحملة المنشورة." },
  ...[
    ["daily", "باقة TikTok اليومية", 750, "250 ميگابايت", "24 ساعة", "117", "0117"],
    ["weekly", "باقة TikTok الأسبوعية", 2500, "1 گيگابايت", "7 أيام", "118", "0118"],
    ["month", "TikTok 7", 7000, "3 گيگابايت", "4 أسابيع", "119", "0119"],
  ].map(([id, title, price, data, validity, code, cancel]) => ({
    id: `tiktok-${id}`, title: String(title), description: `باقة إنترنت مخصصة لاستخدام TikTok بسعة ${data}.`, image: officialAssets.tiktokCurrent, tag: String(validity), category: "تيك توك", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/prepaid-category/offers/tiktok-offers-1", price: Number(price), internet: String(data), validity: String(validity), code: `رمز الباقة ${code} · الإلغاء ${cancel}`, note: `رمز الباقة المنشور ${code} ورمز الإلغاء ${cancel}. قد تتجدد بعض الباقات تلقائياً عند توفر رصيد كافٍ. هذه الصفحة تعرض التفاصيل فقط ولا تنفذ الاشتراك.`
  } as Offer)),
  { id: "special-numbers", title: "الأرقام المميزة بأسعار مخفضة", description: "أرقام زين مميزة متاحة بأسعار تختلف حسب الرقم والفئة المعروضة.", image: officialAssets.specialNumbers, tag: "أرقام مميزة", category: "عروض خاصة", source: "زين العراق", sourceUrl: offersUrl, note: "السعر والتوفر يعتمدان على الرقم المختار ومخزون زين الحالي." },
  { id: "gift-data", title: "إهداء الإنترنت", description: "أهدِ باقات إنترنت +4.5G أو الإنترنت المفتوح إلى مشترك آخر، وفق خيارات الإهداء وشروط نوع خط المستلم.", image: officialAssets.giftInternet, tag: "مشاركة الباقات", category: "عروض خاصة", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/prepaid-category/offers/internet-gift", note: "تختلف صلاحية بعض الباقات المُهداة بحسب نوع خط المستلم؛ راجع شروط الإهداء في صفحة زين." },
  { id: "double-recharge", title: "ضعف الرصيد عند التعبئة", description: "اشحن 10,000 دينار أو أكثر واحصل على رصيد إضافي مماثل وفق شروط العرض المنشور.", image: officialAssets.doubleRecharge, tag: "100% رصيد إضافي", category: "عروض خاصة", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/prepaid-category/offers/get-double-credit", price: 10000, includes: ["رصيد إضافي مساوٍ لقيمة التعبئة"], validity: "الرصيد الإضافي صالح 3 أيام للمكالمات والرسائل داخل زين", code: "التحقق من الرصيد الإضافي والصلاحية عبر #233*", note: "يشمل تعبئة 10,000 دينار فأكثر، ولا يشمل تعبئة 5,000. يمكن أن تكون التعبئة عبر بطاقة أو بطاقة دفع إلكتروني بحسب شروط العرض. تحقق من التفاصيل الحالية قبل الشحن." },
  { id: "fadshiii-1001", title: "هدية فدشييي على منصة 1001", description: "اشتراك مجاني لمدة 30 يوماً على منصة 1001 عند الاشتراك بباقات مؤهلة بقيمة 25,000 دينار أو أكثر.", image: officialAssets.fadshiii1001, tag: "30 يوماً مجاناً", category: "عروض خاصة", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/services-category/zain-1001-offer", validity: "30 يوماً", includes: ["اشتراك فدشييي على منصة 1001"], note: "تسري الهدية على عائلات الباقات المؤهلة وفق شروط زين، ولا يعني ذلك أن كل باقة أو كل خط مؤهل تلقائياً. تصل تعليمات الاستفادة عبر رسالة من زين." },

  // باقات كفوو العائلة
  ...[
    ["50",50000,"200,000","1,500","1,000",2],
    ["70",70000,"300,000","3,000","1,000",4],
  ].map(([tier, price, credit, familyMinutes, sms, extraLines]) => ({
    id: `kafoo-family-${tier}`, title: `كفوو العائلة ${tier}`, description: `باقة عائلية برصيد ${credit} دينار و${familyMinutes} دقيقة للمجموعة العائلية.`, image: officialAssets.kafooCampaign, tag: "باقة عائلية", category: "كفوو العائلة", source: "زين العراق", sourceUrl: kafooUrl, price: Number(price), internet: `رصيد ${credit} د.ع`, minutes: `${familyMinutes} دقيقة عائلية`, sms: `${sms} رسالة`, validity: "4 أسابيع", includes: ["تطبيقات تواصل اجتماعي مجانية حسب الشروط", "اشتراك 1001 لمدة شهر", `إمكانية إضافة حتى ${extraLines} خطوط إضافية للمجموعة`], note: "الدقائق العائلية بين الأرقام المحددة ضمن المجموعة. الحد الأقصى لعدد الخطوط التابعة يختلف حسب الخطة، ورسوم وشروط التحويل أو مشاركة الرصيد تخضع لصفحة كفوو الرسمية."
  } as Offer)),

  // عروض كفوو 2+1: ادفع اشتراكين واحصل على الثالث مجاناً
  ...[
    ["15",15000,30000,"135,000","300",false],
    ["20",20000,40000,"180,000","450",false],
    ["25",25000,50000,"270,000","600",true],
    ["30",30000,60000,"360,000","750",true],
    ["40",40000,80000,"480,000","3,000",false],
  ].map(([tier, unitPrice, pay, totalCredit, sms, gift1001]) => ({
    id: `kafoo-231-${tier}`, title: `كفوو ${tier} – عرض 2+1`, description: `ادفع قيمة اشتراكين واحصل على ثلاث دورات من كفوو ${tier}، بإجمالي رصيد ${totalCredit} دينار.`, image: officialAssets.kafooCampaign, tag: "2+1 · الثالث مجاناً", category: "كفوو", source: "زين العراق", sourceUrl: kafooUrl, price: Number(pay), internet: `إجمالي رصيد ${totalCredit} د.ع`, sms: `${sms} رسالة إجمالاً`, validity: "3 دورات × 4 أسابيع", includes: ["ثلاث اشتراكات من مستوى الباقة المختار", ...(gift1001 ? ["هدية فدشييي 1001 لمدة شهر وفق الأهلية"] : [])], note: `قيمة الاشتراك الأساسي ${Number(unitPrice).toLocaleString("en-US")} د.ع. يدفع المشترك اشتراكين ويحصل على الثالث مجاناً. تحقق من الشروط والأهلية الحالية على صفحة زين قبل الاشتراك.`
  } as Offer)),

  // باقات التجوال الخاصة بلبنان على شبكة Touch
  ...[
    ["500mb", "500 ميگابايت", 10000, "7 أيام", "11"],
    ["1gb", "1 گيگابايت", 20000, "10 أيام", "12"],
    ["2gb", "2 گيگابايت", 40000, "4 أسابيع", "13"],
  ].map(([id, data, price, validity, code]) => ({
    id: `roaming-lebanon-${id}`, title: `تجوال لبنان – ${data}`, description: `باقة إنترنت تجوال في لبنان عبر شبكة Touch بسعة ${data}.`, image: officialAssets.lebanonRoaming, tag: "لبنان · Touch", category: "التجوال", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/prepaid-category/roaming-service/lebanon-bundles", price: Number(price), internet: String(data), validity: String(validity), code: `إرسال ${code} برسالة إلى 2050 أو الاشتراك عبر #225*`, note: "الباقات متاحة لمشتركي الدفع المسبق ومشتركي الدفع الآجل بعد تفعيل خدمة التجوال. تعمل في لبنان على شبكة Touch. هذه الصفحة تعرض المعلومات ولا ترسل الرسالة أو تنفذ الاشتراك."
  } as Offer)),

  // عروض الأجهزة المنشورة على الصفحة الرئيسية
  { id: "iphone-duo-campaign", title: "اطلب iPhone Duo الآن", description: "حملة طلب مسبق لجهاز iPhone Duo كما تظهر على الصفحة الرئيسية لزين العراق.", image: officialAssets.iphoneDuo, tag: "طلب مسبق", category: "أجهزة وعروض", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar", note: "لم يظهر سعر موحّد في بطاقة الحملة العامة؛ راجع صفحة الطلب والتوفر والشروط قبل الشراء." },
  { id: "honor-magic-v5-annual", title: "HONOR Magic V5 مع رصيد سنوي", description: "حملة جهاز HONOR Magic V5 مع رصيد استخدام معلن بقيمة 1,440,000 دينار على مدار سنة، وفق شروط العرض المنشور.", image: officialAssets.honorMagicV5, tag: "رصيد سنوي", category: "أجهزة وعروض", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar", includes: ["إجمالي رصيد معلن 1,440,000 د.ع على مدار سنة", "ما يعادل 120,000 د.ع شهرياً وفق الحملة", "مزايا Free Social حسب شروط العرض"], note: "الرصيد الشهري غير المرحّل لا ينتقل إلى الشهر التالي. تحقّق من سعر الجهاز والتوفر والشروط الحالية قبل الشراء." },
  { id: "samsung-a06-5g-kafoo", title: "Samsung Galaxy A06 5G مع هدية كفوو", description: "حملة جهاز Galaxy A06 5G مع هدية باقة كفوو بقيمة 45,000 دينار وفق العرض المنشور على موقع زين.", image: officialAssets.samsungA06, tag: "هدية كفوو 45,000", category: "أجهزة وعروض", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar", includes: ["هدية باقة كفوو بقيمة 45,000 د.ع وفق شروط الحملة"], note: "سعر الجهاز وتوفره وفترة الحملة قد تتغير. راجع زين قبل الشراء." },
  { id: "galaxy-fold7-flip7-delivery", title: "Galaxy Z Fold7 وZ Flip7", description: "حملة أجهزة Galaxy Z Fold7 وZ Flip7 مع توصيل مجاني وفق التفاصيل المنشورة على الصفحة الرئيسية لزين.", image: officialAssets.galaxyFold7, tag: "توصيل مجاني", category: "أجهزة وعروض", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar", note: "العرض لا يحدد سعراً موحداً في بطاقة الموقع العامة. تحقّق من الطراز والسعر والتوفر وشروط التوصيل قبل الطلب." },

  // باقات إنترنت التجوال العامة المنشورة حالياً؛ الشبكات المتاحة تتغير حسب بلد الوجهة
  { id: "roaming-1gb", title: "باقة التجوال 1 گيگابايت", description: "1 گيگابايت إنترنت تجوال لمدة 3 أيام بسعر 5,000 دينار.", image: officialAssets.roaming, tag: "3 أيام", category: "التجوال", source: "زين العراق", sourceUrl: roamingUrl, price: 5000, internet: "1 گيگابايت", validity: "3 أيام", note: "تختلف الشبكات المشغلة حسب الدولة. تحقق من جدول الدول والشبكات المدعومة قبل السفر." },
  { id: "roaming-2gb", title: "باقة التجوال 2 گيگابايت", description: "2 گيگابايت إنترنت تجوال لمدة 7 أيام بسعر 10,000 دينار.", image: officialAssets.roaming, tag: "7 أيام", category: "التجوال", source: "زين العراق", sourceUrl: roamingUrl, price: 10000, internet: "2 گيگابايت", validity: "7 أيام", note: "تختلف الشبكات المشغلة حسب الدولة. تحقق من جدول الدول والشبكات المدعومة قبل السفر." },
  { id: "roaming-rates", title: "تعرفة التجوال حسب الدولة والشبكة", description: "تعرف على أجور الإنترنت والمكالمات والرسائل حسب البلد وشبكة التجوال المتاحة.", image: officialAssets.worldOffers, tag: "جدول التعرفة", category: "التجوال", source: "زين العراق", sourceUrl: roamingUrl, note: "تعرفة الاستخدام خارج باقات التجوال تختلف حسب البلد والمشغل، وقد تكون أعلى من سعر الباقات." },

  // الدفع الآجل Prime Plus: ست باقات شهرية رئيسية وخمس إضافات منشورة
  ...[
    ["25",25000,"12 گيگابايت","500","500","—","—","لا يوجد",["واتساب","تيليگرام","فيسبوك","سناب چات","إنستغرام","تيك توك"]],
    ["40",40000,"40 گيگابايت","1,000","3,000","—","—","لا يوجد",["واتساب","تيليگرام","فيسبوك","يوتيوب","سناب چات","إنستغرام","تيك توك"]],
    ["60",60000,"80 گيگابايت","1,200","3,000","30","1 گيگابايت","60,000",["واتساب","تيليگرام","فيسبوك","يوتيوب","سناب چات","إنستغرام","تيك توك"]],
    ["80",80000,"120 گيگابايت","1,600","3,000","45","2 گيگابايت","80,000",["واتساب","تيليگرام","فيسبوك","يوتيوب","سناب چات","إنستغرام","تيك توك"]],
    ["100",100000,"250 گيگابايت","2,000","3,000","60","4 گيگابايت","100,000",["واتساب","تيليگرام","فيسبوك","يوتيوب","سناب چات","إنستغرام","تيك توك"]],
    ["120",120000,"300 گيگابايت","2,500","3,000","60","5 گيگابايت","120,000",["واتساب","فايبر","فيسبوك","يوتيوب","سناب چات","إنستغرام","تيك توك"]],
  ].map(([tier, price, data, minutes, sms, intl, roaming, deposit, socials]) => ({
    id: `prime-plus-${tier}`, title: `برايم بلس ${tier}`, description: `باقة فاتورة شهرية تشمل ${data} إنترنت و${minutes} دقيقة محلية و${sms} رسالة.`, image: officialAssets.primePlus, tag: "دفع آجل · شهري", category: "الدفع الآجل", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/postpaid/change-to-postpaid", price: Number(price), internet: String(data), minutes: `${minutes} دقيقة محلية`, sms: `${sms} رسالة`, validity: "شهر واحد", includes: [`دقائق دولية: ${intl === "—" ? "غير مشمولة" : `${intl} دقيقة`}`, `إنترنت تجوال: ${roaming === "—" ? "غير مشمول" : roaming}`, `تطبيقات اجتماعية: ${(socials as string[]).join("، ")}`, "اشتراك فدشييي على منصة 1001 لمدة شهر وفق شروط العرض"], note: `التأمينات المبدئية المنشورة: ${deposit} د.ع. يشترط دفع مبلغ يساوي قيمة الباقة كدفعة مقدمة عند شراء الخط. راجع صفحة برايم بلس للشروط الكاملة.`
  } as Offer)),
  ...[
    ["دقائق محلية 250",10000,"—","250 دقيقة"],
    ["دقائق محلية 500",15000,"—","500 دقيقة"],
    ["إنترنت محلي 8GB",10000,"8 گيگابايت","—"],
    ["إنترنت محلي 15GB",15000,"15 گيگابايت","—"],
    ["دقائق دولية 60",15000,"—","60 دقيقة دولية"],
  ].map(([name, price, data, minutes], index) => ({
    id: `prime-plus-addon-${index}`, title: `إضافة برايم بلس – ${name}`, description: `إضافة اختيارية لمدة 30 يوماً لخطوط برايم بلس.`, image: officialAssets.primePlus, tag: "إضافة اختيارية", category: "الدفع الآجل", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/postpaid/change-to-postpaid", price: Number(price), internet: String(data) === "—" ? undefined : String(data), minutes: String(minutes) === "—" ? undefined : String(minutes), validity: "30 يوماً", note: "يمكن إضافة أكثر من باقة مع الباقة الرئيسية؛ راجع الصفحة الرسمية للتفاصيل وآلية الاشتراك."
  } as Offer)),

  { id: "personalized-100", title: "عالم العروض #100*", description: "قائمة عروض مخصصة قد تختلف من رقم إلى آخر بحسب نوع الخط والأهلية والفترة المتاحة.", image: officialAssets.personalizedCurrent, tag: "حسب أهلية الخط", category: "الخدمات", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/prepaid/personalized-offers", note: "العروض الظاهرة داخل القائمة قد لا تكون متطابقة لجميع المشتركين." },
  { id: "mamnoon-program", title: "برنامج ممنون", description: "خدمات المكافآت والامتيازات التي تنشرها زين للمشتركين المؤهلين.", image: officialAssets.gift, tag: "مكافآت", category: "ممنون", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/services/mobile-app", note: "تفاصيل المكافآت والاستحقاق تعتمد على الشروط المنشورة والعضوية المتاحة." },
  { id: "zain-app", title: "تطبيق زين العراق", description: "التطبيق الرسمي لإدارة الخط، متابعة الرصيد والعروض والخدمات الرقمية.", image: officialAssets.app, tag: "خدمات رقمية", category: "الخدمات", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/services/mobile-app" },

  // أجهزة زين فاي وأسعارها المنشورة
  { id: "zainfi2-cat7", title: "جهاز زين فاي 2 – CAT7", description: "جهاز إنترنت منزلي يدعم اتصال ما يصل إلى 8 مستخدمين.", image: officialAssets.zainFi2Cat7, tag: "حتى 8 مستخدمين", category: "زين فاي", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/mbb/get-started", price: 129000, internet: "CAT7", includes: ["رصيد ابتدائي 50,000 د.ع حسب شروط الجهاز"] },
  { id: "zainfi2-cat4", title: "جهاز زين فاي 2 – CAT4", description: "جهاز إنترنت منزلي يدعم اتصال ما يصل إلى 8 مستخدمين.", image: officialAssets.zainFi2Cat4, tag: "حتى 8 مستخدمين", category: "زين فاي", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/mbb/get-started", price: 99000, internet: "CAT4", includes: ["رصيد ابتدائي 50,000 د.ع حسب شروط الجهاز"] },
  { id: "zainfi-cat4-79", title: "جهاز زين فاي – CAT4", description: "جهاز إنترنت محمول يدعم اتصال ما يصل إلى 10 مستخدمين.", image: officialAssets.zainFiCat4, tag: "حتى 10 مستخدمين", category: "زين فاي", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/mbb/get-started", price: 79000, internet: "CAT4", includes: ["رصيد ابتدائي 40,000 د.ع حسب شروط الجهاز"] },
  { id: "zainfi-cat7-109", title: "جهاز زين فاي – CAT7", description: "جهاز إنترنت محمول يدعم اتصال ما يصل إلى 10 مستخدمين.", image: officialAssets.zainFiCat7, tag: "حتى 10 مستخدمين", category: "زين فاي", source: "زين العراق", sourceUrl: "https://www.iq.zain.com/ar/mbb/get-started", price: 109000, internet: "CAT7", includes: ["رصيد ابتدائي 40,000 د.ع حسب شروط الجهاز"] },
];

const serviceItems: ServiceItem[] = [
  { id: "my-number", title: "معرفة رقمي", description: "طريقة الوصول إلى رقم الخط ومعلوماته من خدمات زين المتاحة.", icon: "#", tone: "violet", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/services/mobile-app", label: "خدمة أساسية" },
  { id: "balance", title: "متابعة رصيدي", description: "تابع رصيدك وتعرّف على كلفة المكالمات والاستهلاك.", icon: "◉", tone: "mint", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "transfer", title: "تحويل الرصيد", description: "أرسل رصيداً إلى مشترك آخر ضمن خدمات زين.", icon: "⇄", tone: "blue", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "fill-them", title: "عبيلهم رصيد", description: "اشحن رصيد خط دفع مسبق آخر بسهولة.", icon: "＋", tone: "orange", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "call-me", title: "خابرني", description: "أرسل طلب اتصال عندما ينفد رصيدك.", icon: "☎", tone: "pink", group: "خدمات المكالمات", sourceUrl: "https://www.iq.zain.com/ar/knowledge-center/services-category/services-offers" },
  { id: "collect-call", title: "واصل حسابك", description: "خدمة تتيح أن تكون أجور المكالمة على حساب متلقي الاتصال.", icon: "↗", tone: "purple", group: "خدمات المكالمات", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "peace", title: "ريح بالك", description: "إدارة المكالمات والرسائل المزعجة وغير المرغوب بها.", icon: "◌", tone: "aqua", group: "خدمات المكالمات", sourceUrl: "https://www.iq.zain.com/ar/category/services", image: officialAssets.reehBalak },
  { id: "sms", title: "خدمة الرسائل القصيرة", description: "خدمات الرسائل النصية لمشتركي زين.", icon: "✉", tone: "gold", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "sameni", title: "سمعني", description: "خدمة نغمات رنين المكالمات والمحتوى الصوتي.", icon: "♫", tone: "pink", group: "خدمات ترفيهية", sourceUrl: "https://www.iq.zain.com/ar/" },
  { id: "voicemail", title: "البريد الصوتي", description: "ابقَ على اطلاع على الرسائل الصوتية عند تعذّر الرد.", icon: "▣", tone: "blue", group: "خدمات المكالمات", sourceUrl: "https://www.iq.zain.com/ar/" },
  { id: "hundred", title: "عالم العروض #100*", description: "استكشف العروض الخاصة المتاحة لخطك وأهليتك.", icon: "✦", tone: "violet", group: "العروض الخاصة", sourceUrl: "https://www.iq.zain.com/ar/prepaid/personalized-offers", label: "عروض مخصصة" },
  { id: "mamnoon", title: "ممنون", description: "برنامج المكافآت والنقاط والعروض من زين.", icon: "♡", tone: "orange", group: "المكافآت", sourceUrl: "https://www.iq.zain.com/ar/services/mobile-app" },
  { id: "zain-cash", title: "زين كاش", description: "المحفظة الإلكترونية لخدمات الدفع والتحويل والشحن.", icon: "Z", tone: "mint", group: "الخدمات الرقمية", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "daily-data", title: "إنترنت يومي", description: "تعرّف على باقات الإنترنت اليومية وخيارات البيانات المتاحة.", icon: "◉", tone: "violet", group: "باقات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/prepaid/data-only-offers", label: "اشتراك يومي" },
  { id: "weekly-data", title: "إنترنت أسبوعي", description: "باقات بيانات بصلاحية أسبوعية لاستخدامك اليومي.", icon: "◷", tone: "blue", group: "باقات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/prepaid/data-only-offers", label: "7 أيام" },
  { id: "monthly-data", title: "إنترنت شهري", description: "اختر سعة البيانات والصلاحية التي تناسب استخدامك.", icon: "▦", tone: "pink", group: "باقات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/prepaid/data-only-offers", label: "4 أسابيع / 30 يوماً" },
  { id: "open-data", title: "الإنترنت المفتوح", description: "خيارات إنترنت مفتوح يومية وأسبوعية وفق سياسة الاستخدام العادل.", icon: "∞", tone: "mint", group: "باقات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/prepaid/data-only-offers" },
  { id: "free-social", title: "Free Social", description: "باقات بيانات مع استخدام مجاني لتطبيقات اجتماعية حسب شروط الباقة.", icon: "◎", tone: "orange", group: "باقات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/prepaid/data-only-offers" },
  { id: "tiktok", title: "باقة تيك توك", description: "خيارات مخصصة لاستخدام تطبيق تيك توك.", icon: "♪", tone: "purple", group: "باقات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/prepaid/data-only-offers" },
  { id: "kafoo-monthly", title: "كفوو", description: "باقات كفوو بمزايا متنوعة من الرصيد والإنترنت والتواصل.", icon: "✦", tone: "violet", group: "الباقات المتكاملة", sourceUrl: "https://www.iq.zain.com/ar/prepaid/kafoo" },
  { id: "super-card-monthly", title: "سوبر كارد", description: "باقات تجمع الإنترنت والدقائق والرسائل في اشتراك واحد.", icon: "▣", tone: "pink", group: "الباقات المتكاملة", sourceUrl: "https://www.iq.zain.com/ar/prepaid/voice-and-data-offers" },
  { id: "bekefi", title: "بكيفي", description: "خيارات باقات يمكن الاختيار بينها وفق احتياجك.", icon: "◈", tone: "gold", group: "الباقات المتكاملة", sourceUrl: "https://www.iq.zain.com/ar/prepaid/voice-and-data-offers" },
  { id: "roaming-service", title: "التجوال الدولي", description: "باقات وخيارات الاتصال والإنترنت أثناء السفر خارج العراق.", icon: "✈", tone: "blue", group: "خدمات السفر", sourceUrl: "https://www.iq.zain.com/ar/prepaid/roaming-and-international-offers" },
  { id: "esim", title: "الشريحة الإلكترونية eSIM", description: "تعرّف على خيار الشريحة الإلكترونية وإمكانية استخدام رقمك دون شريحة SIM فعلية على الأجهزة المتوافقة.", icon: "▤", tone: "purple", group: "الخدمات الرقمية", sourceUrl: "https://www.iq.zain.com/ar/", image: officialAssets.esim, label: "خدمة رقمية" },
  { id: "kafoo-family-service", title: "كفوو العائلة", description: "خطط عائلية تتضمن دقائق بين أعضاء المجموعة ومزايا مشاركة الرصيد وفق الخطة.", icon: "♧", tone: "mint", group: "الباقات المتكاملة", sourceUrl: "https://www.iq.zain.com/ar/prepaid/kafoo", image: officialAssets.kafooCampaign },
  { id: "sim-replacement", title: "استبدال الشريحة", description: "خدمة استبدال شريحة SIM عند الحاجة مع الاحتفاظ بالرقم وفق إجراءات زين ومتطلبات إثبات الملكية.", icon: "▤", tone: "blue", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/category/services", label: "خدمة فروع" },
  { id: "balance-validity", title: "صلاحية رصيدك بكيفك", description: "خيارات مرتبطة بتمديد أو إدارة صلاحية الرصيد بحسب فئة الخط والشروط المتاحة.", icon: "◷", tone: "gold", group: "خدمات الخط", sourceUrl: "https://www.iq.zain.com/ar/category/services", image: officialAssets.balanceValidity },
  { id: "wallet-card", title: "والت كارد من زين كاش", description: "بطاقة مرتبطة بمحفظة زين كاش وخدماتها المالية، وتخضع لشروط الإصدار والاستخدام المنشورة من زين كاش.", icon: "▣", tone: "mint", group: "الخدمات الرقمية", sourceUrl: "https://www.iq.zain.com/ar/category/services", image: officialAssets.walletCard },
  { id: "electronic-recharge", title: "التعبئة الإلكترونية", description: "خيارات تعبئة الرصيد وبطاقات الإنترنت عبر القنوات الرقمية المعتمدة.", icon: "↻", tone: "orange", group: "الخدمات الرقمية", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "after-sales-315", title: "دليل مراكز الخدمة #315*", description: "طريقة الوصول إلى معلومات مراكز زين والوكلاء وخدمات الدعم من خلال القنوات الرسمية.", icon: "⌖", tone: "blue", group: "خدمات الدعم", sourceUrl: "https://www.iq.zain.com/ar/category/services" },
  { id: "oodi", title: "Oodi", description: "خدمة رقمية تتيح تخصيص التطبيقات والباقات، مع مزايا ترفيهية وخيارات قابلة للتخصيص حسب الخطة.", icon: "◉", tone: "purple", group: "خدمات ترفيهية", sourceUrl: "https://www.oodi.iq/ar", label: "خدمة رقمية" },
  { id: "zain-connect", title: "شريحة زين كونكت", description: "شريحة اتصال بيانات لأجهزة الإنترنت المتوافقة، مع باقات وخيارات خاصة بالإنترنت.", icon: "⌁", tone: "aqua", group: "خدمات الإنترنت", sourceUrl: "https://www.iq.zain.com/ar/mbb/get-started" },
];

const heroSlides = [
  {
    kicker: "خطوط وباقات كفوو",
    title: "اختيارات أكثر\nومزايا أقرب لك",
    description: "اكتشف عالم كفوو وباقاته من زين العراق.",
    image: officialAssets.kafoo,
    action: "استكشف كفوو",
    category: "كفوو",
  },
  {
    kicker: "ابقَ على تواصل",
    title: "إنترنتك معك\nوين ما تكون",
    description: "تعرّف على باقات الإنترنت والتجوال المتاحة.",
    image: officialAssets.roaming,
    action: "اكتشف الباقات",
    category: "التجوال",
  },
  {
    kicker: "باقات مخصصة",
    title: "تيك توك\nبباقات تناسبك",
    description: "خيارات يومية وأسبوعية وشهرية لمحتوى TikTok.",
    image: officialAssets.tiktokCurrent,
    action: "شاهد باقات تيك توك",
    category: "تيك توك",
  },
  {
    kicker: "حملات ومزايا",
    title: "فوول الفوول\nبيانات ورصيد أكثر",
    description: "اطّلع على الباقات وشروط المناطق المشمولة.",
    image: officialAssets.foulFoulCurrent,
    action: "اكتشف العرض",
    category: "فوول الفوول",
  },
  {
    kicker: "تجربة رقمية أسهل",
    title: "خدمات زين\nفي مكان واحد",
    description: "تابع العروض والخدمات من واجهة واحدة.",
    image: officialAssets.gift,
    action: "تصفح الخدمات",
    category: "الخدمات",
  },
];

function BrandMark({ small = false, dark = false }: { small?: boolean; dark?: boolean }) {
  return (
    <div className={`brand-mark ${small ? "brand-mark-small" : ""} ${dark ? "brand-mark-dark" : ""}`} aria-label="زين العراق">
      <span className="brand-emblem" aria-hidden="true"><i /><i /><i /></span>
      <span className="brand-word">zain<span>العراق</span></span>
    </div>
  );
}

function PrimaryButton({ children, onClick, disabled = false }: { children: ReactNode; onClick: () => void; disabled?: boolean }) {
  return <button className="primary-button" onClick={onClick} disabled={disabled}>{children}<span aria-hidden="true">←</span></button>;
}

function SectionHeading({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="section-heading">
      <div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div>
      {action && <button className="section-action" onClick={onAction}>{action}<span>←</span></button>}
    </div>
  );
}

export default function Page() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const [showSplash, setShowSplash] = useState(true);
  const [phone, setPhone] = useState("");
  const [consent, setConsent] = useState(false);
  const [humanConfirmed, setHumanConfirmed] = useState(false);
  const [notice, setNotice] = useState("");
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [activeSlide, setActiveSlide] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [activeServiceGroup, setActiveServiceGroup] = useState("الكل");
  const [activeTab, setActiveTab] = useState("الرئيسية");

  useEffect(() => {
    const timer = window.setTimeout(() => setShowSplash(false), 3000);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (screen !== "home") return;
    const timer = window.setInterval(() => setActiveSlide((current) => (current + 1) % heroSlides.length), 6500);
    return () => window.clearInterval(timer);
  }, [screen]);

  const normalizedPhone = useMemo(() => phone.replace(/[\s-]/g, ""), [phone]);
  const validPhone = /^(07[0-9]{9}|\+9647[0-9]{9}|9647[0-9]{9})$/.test(normalizedPhone);
  const visibleOffers = offers.filter((offer) => {
    const matchesCategory = activeCategory === "الكل" || offer.category === activeCategory;
    const query = searchQuery.trim().toLowerCase();
    const searchable = `${offer.title} ${offer.description} ${offer.category} ${offer.internet ?? ""} ${offer.minutes ?? ""} ${offer.sms ?? ""} ${(offer.includes ?? []).join(" ")} ${offer.code ?? ""}`.toLowerCase();
    const matchesSearch = !query || searchable.includes(query);
    return matchesCategory && matchesSearch;
  });
  const serviceGroups = ["الكل", "خدمات الخط", "خدمات المكالمات", "خدمات الإنترنت", "باقات الإنترنت", "الباقات المتكاملة", "الخدمات الرقمية", "العروض الخاصة", "المكافآت", "خدمات ترفيهية", "خدمات السفر", "خدمات الدعم"];
  const visibleServices = serviceItems.filter((item) => {
    const matchesGroup = activeServiceGroup === "الكل" || item.group === activeServiceGroup;
    const query = searchQuery.trim().toLowerCase();
    const matchesQuery = !query || `${item.title} ${item.description} ${item.group}`.toLowerCase().includes(query);
    return matchesGroup && matchesQuery;
  });

  function submitPhone() {
    if (!validPhone) {
      setNotice("يرجى إدخال رقم هاتف عراقي صحيح، مثل 07XXXXXXXXX.");
      return;
    }
    if (!consent) {
      setNotice("يرجى الموافقة على استخدام الرقم لمعالجة طلب المكافأة.");
      return;
    }
    setNotice("");
    setScreen("verify");
  }

  function confirmRequest() {
    if (!humanConfirmed) {
      setNotice("يرجى تأكيد أنك صاحب الطلب للمتابعة.");
      return;
    }
    setNotice("");
    setScreen("pending");
  }

  function chooseCategory(category: string) {
    setActiveCategory(category);
    setActiveTab("العروض");
    setNotice("");
    window.setTimeout(() => document.getElementById("offers-section")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  }

  if (showSplash) {
    return (
      <main className="splash-screen">
        <div className="splash-aurora aurora-one" /><div className="splash-aurora aurora-two" />
        <div className="splash-content">
          <BrandMark />
          <div className="splash-loader"><span /></div>
          <p>عالمك من زين… أقرب</p>
        </div>
        <small className="prototype-stamp">تصميم تجريبي قيد التطوير</small>
      </main>
    );
  }


  if (screen !== "home") {
    return (
      <main className="app-shell flow-shell">
        <header className="topbar"><BrandMark small dark /><span className="secure-label"><span /> نموذج تجريبي</span></header>

        {screen === "welcome" && (
          <section className="flow-card reward-screen">
            <div className="gift-orbit"><span className="gift-emoji">🎁</span><b>+</b><i>✦</i></div>
            <span className="eyebrow">هدية ترحيبية للمستخدم الجديد</span>
            <h1>مبروك!</h1>
            <p className="reward-lead">قد تكون مؤهلاً للحصول على مكافأة ترحيبية بقيمة</p>
            <div className="amount">5,000 <small>دينار عراقي</small></div>
            <p className="muted-copy">تُراجع أهلية الطلب وتُصرف المكافأة بعد اعتمادها وتأكيد التحويل.</p>
            <PrimaryButton onClick={() => setScreen("method")}>اضغط للاستلام</PrimaryButton>
            <p className="tiny-note">المكافأة الترويجية تخضع لشروط الأهلية والتوفر.</p>
          </section>
        )}

        {screen === "method" && (
          <section className="flow-card">
            <div className="step-indicator">الخطوة 1 من 3</div>
            <span className="eyebrow">استلام المكافأة</span><h1>اختر وسيلة الاستلام</h1>
            <p className="muted-copy">اختر المحفظة التي ترغب باستلام المكافأة عليها.</p>
            <button className="wallet-option selected" onClick={() => setScreen("phone")}>
              <span className="wallet-icon">Z</span><span className="wallet-text"><b>Zain Cash</b><small>محفظة زين كاش</small></span><span className="radio-dot" />
            </button>
            <PrimaryButton onClick={() => setScreen("phone")}>متابعة</PrimaryButton>
            <button className="text-button" onClick={() => setScreen("welcome")}>رجوع</button>
          </section>
        )}

        {screen === "phone" && (
          <section className="flow-card">
            <div className="step-indicator">الخطوة 2 من 3</div><div className="wallet-icon wallet-icon-large">Z</div>
            <h1>بيانات محفظة زين كاش</h1>
            <p className="phone-instruction">قم بإدخال رقمك على زين كاش لتحويل المكافأة له</p>
            <label className="input-label" htmlFor="wallet-phone">رقم الهاتف المرتبط بمحفظة زين كاش</label>
            <div className="phone-input-wrap"><span>🇮🇶 +964</span><input id="wallet-phone" inputMode="tel" autoComplete="tel" placeholder="07XXXXXXXXX" value={phone} onChange={(e) => { setPhone(e.target.value); setNotice(""); }} /></div>
            <label className="consent-row"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} /><span>أوافق على استخدام الرقم الذي أدخلته لمعالجة طلب المكافأة والتواصل معي بشأنه.</span></label>
            {notice && <p className="inline-notice" role="alert">{notice}</p>}
            <PrimaryButton onClick={submitPhone}>متابعة</PrimaryButton>
            <p className="privacy-note">هذا نموذج أولي؛ لا يُرسل الرقم إلى أي خادم حالياً.</p>
            <button className="text-button" onClick={() => setScreen("method")}>رجوع</button>
          </section>
        )}

        {screen === "verify" && (
          <section className="flow-card">
            <div className="step-indicator">الخطوة 3 من 3</div><div className="verify-icon">✓</div>
            <h1>تأكيد الطلب</h1><p className="muted-copy">يرجى تأكيد أنك صاحب الطلب قبل إرسال طلب مراجعة المكافأة.</p>
            <label className="human-check"><input type="checkbox" checked={humanConfirmed} onChange={(e) => { setHumanConfirmed(e.target.checked); setNotice(""); }} /><span className="check-square">{humanConfirmed ? "✓" : ""}</span><span><b>أنا صاحب هذا الطلب</b><small>أؤكد أنني أدخلت رقم محفظتي بنفسي.</small></span></label>
            {notice && <p className="inline-notice" role="alert">{notice}</p>}
            <PrimaryButton onClick={confirmRequest}>تأكيد ومتابعة</PrimaryButton>
            <p className="privacy-note">هذا تأكيد للطلب وليس اختبار CAPTCHA أو إثباتاً تقنياً ضد الروبوتات.</p>
            <button className="text-button" onClick={() => setScreen("phone")}>رجوع</button>
          </section>
        )}

        {screen === "pending" && (
          <section className="flow-card success-card">
            <div className="success-icon">✓</div><span className="eyebrow">تم استلام طلبك</span><h1>شكراً لك!</h1>
            <div className="pending-amount">5,000 <small>د.ع</small></div>
            <p className="muted-copy">تم تسجيل طلب مراجعة المكافأة بنجاح في هذه النسخة التجريبية.</p>
            <div className="status-box"><span className="status-dot" /><span><b>حالة المكافأة: قيد المراجعة</b><small>لم يتم تحويل أي مبلغ بعد.</small></span></div>
            <p className="tiny-note">لن تظهر رسالة «تم التحويل» إلا بعد تأكيد التحويل الفعلي من الجهة المسؤولة.</p>
            <PrimaryButton onClick={() => setScreen("home")}>الانتقال إلى التطبيق</PrimaryButton>
          </section>
        )}
        <footer className="flow-footer">نسخة تجريبية قيد التطوير · عروض وخدمات زين العراق</footer>
      </main>
    );
  }

  const currentSlide = heroSlides[activeSlide];

  return (
    <main className="app-shell home-shell">
      <header className="home-header">
        <div className="header-brand-block"><BrandMark small dark /><p className="welcome-back">أهلاً بك، شنو تحتاج اليوم؟</p></div>
        <button className="profile-button" aria-label="الملف الشخصي" onClick={() => setNotice("ملف المستخدم سيُضاف في مرحلة ربط الحسابات.")}><span>م</span><i /></button>
      </header>

      <div className="search-bar"><span>⌕</span><input value={searchQuery} onChange={(e) => { setSearchQuery(e.target.value); setActiveTab("العروض"); }} placeholder="ابحث عن باقة أو خدمة أو عرض" aria-label="ابحث عن عرض أو خدمة" /><kbd>بحث</kbd></div>

      <div className="catalog-stats" aria-label="ملخص محتوى التطبيق">
        <div><b>{offers.length.toLocaleString("en-US")}</b><span>باقة وعرض</span></div>
        <div><b>{serviceItems.length.toLocaleString("en-US")}</b><span>خدمة</span></div>
        <div><b>{categories.length.toLocaleString("en-US")}</b><span>تصنيف</span></div>
      </div>

      <section className="hero-carousel" aria-label="العروض الرئيسية">
        <div className={`hero-slide slide-${activeSlide}`}>
          <div className="hero-content"><span className="hero-kicker"><i />{currentSlide.kicker}</span><h1>{currentSlide.title.split("\n").map((line) => <span key={line}>{line}<br /></span>)}</h1><p>{currentSlide.description}</p><button className="hero-button" onClick={() => chooseCategory(currentSlide.category)}>{currentSlide.action}<span>←</span></button></div>
          <div className="hero-image-wrap"><img src={currentSlide.image} alt="مواد ترويجية من زين العراق" /></div>
          <div className="hero-decoration hero-decoration-one" /><div className="hero-decoration hero-decoration-two" />
        </div>
        <div className="hero-pagination">{heroSlides.map((slide, index) => <button key={slide.kicker} className={index === activeSlide ? "active" : ""} onClick={() => setActiveSlide(index)} aria-label={`عرض ${index + 1}`} />)}</div>
      </section>

      <section className="quick-services">
        <button className="quick-service" onClick={() => setNotice("إعادة الشحن المباشر ستُفعّل بعد ربط بوابة زين المعتمدة.")}><span className="quick-icon recharge">↻</span><b>إعادة الشحن</b></button>
        <button className="quick-service" onClick={() => chooseCategory("الإنترنت")}><span className="quick-icon data">◉</span><b>باقات الإنترنت</b></button>
        <button className="quick-service" onClick={() => chooseCategory("التجوال")}><span className="quick-icon roam">✈</span><b>التجوال</b></button>
        <button className="quick-service" onClick={() => chooseCategory("ممنون")}><span className="quick-icon rewards">♡</span><b>ممنون</b></button>
      </section>


      <section className="section-block categories-section">
        <SectionHeading eyebrow="كل شيء بمكان واحد" title="تصفح الباقات حسب القسم" action="عرض الكل" onAction={() => chooseCategory("الكل")} />
        <div className="category-grid">
          {categories.map((item) => (
            <button className="category-card" key={item.title} onClick={() => chooseCategory(item.title)}>
              <span className={`category-icon tone-${item.tone}`}>{item.icon}</span><span className="category-copy"><b>{item.title}</b><small>{item.subtitle}</small></span><span className="category-count">{offers.filter((offer) => offer.category === item.title).length}</span><span className="category-arrow">←</span>
            </button>
          ))}
        </div>
      </section>

      <section className="offers-section" id="offers-section">
        <SectionHeading eyebrow={`كتالوج زين · ${offers.length} باقة وعرض`} title={activeCategory === "الكل" ? "كل العروض والباقات" : `عروض ${activeCategory}`} action="إعادة ضبط" onAction={() => { setActiveCategory("الكل"); setSearchQuery(""); }} />
        <div className="catalog-update-line"><span className="catalog-live-dot" /> مراجعة المصادر العامة لزين · 8 نوفمبر 2026 <span className="catalog-update-sep">•</span> تظهر هنا الباقات العامة المعلنة، وقد تختلف العروض المخصصة حسب الرقم والمنطقة</div>
        <div className="offer-filter-row">
          {["الكل", "الإنترنت", "كفوو", "كفوو العائلة", "سوبر كارد", "بكيفي", "تيك توك", "فوول الفوول", "عروض المناطق", "التجوال", "الدفع الآجل", "زين فاي", "عروض خاصة", "أجهزة وعروض", "ممنون", "الخدمات"].map((item) => <button key={item} className={activeCategory === item ? "filter-chip active" : "filter-chip"} onClick={() => setActiveCategory(item)}>{item}</button>)}
        </div>
        <div className="catalog-result-count">يعرض التطبيق {visibleOffers.length.toLocaleString("en-US")} من {offers.length.toLocaleString("en-US")} باقة وعرض ضمن هذا التصنيف</div>
        <div className="offer-grid">
          {visibleOffers.map((offer) => (
            <article className="offer-card" key={offer.id}>
              <button className="offer-image-button" onClick={() => setSelectedOffer(offer)} aria-label={`تفاصيل ${offer.title}`}><img src={offer.image} alt={`صورة عرض ${offer.title} من زين العراق`} loading="lazy" onError={(event) => { event.currentTarget.style.display = "none"; event.currentTarget.parentElement?.classList.add("image-unavailable"); }} /><span className="offer-badge">{offer.tag}</span><span className="image-open">↗</span></button>
              <div className="offer-card-body">
                <span className="offer-category">{offer.category} · {offer.tag}</span>
                <h3>{offer.title}</h3>
                {offer.price !== undefined && <div className="offer-price-row"><strong>{offer.price.toLocaleString("en-US")}</strong><small>د.ع</small></div>}
                <p>{offer.description}</p>
                <div className="offer-mini-stats">
                  {offer.internet && <span><i>◉</i>{offer.internet.length > 17 ? offer.internet.slice(0, 17) + "…" : offer.internet}</span>}
                  {offer.minutes && <span><i>◷</i>{offer.minutes}</span>}
                  {offer.validity && <span><i>◫</i>{offer.validity}</span>}
                </div>
                <button className="offer-detail-button" onClick={() => setSelectedOffer(offer)}>عرض التفاصيل <span>←</span></button>
              </div>
            </article>
          ))}
          {visibleOffers.length === 0 && <div className="empty-results"><span>⌕</span><b>ما لقينا نتائج مطابقة</b><small>جرّب كلمة بحث ثانية أو غيّر القسم.</small></div>}
        </div>
      </section>


      <section className="service-catalog-section" aria-labelledby="service-catalog-title">
        <div className="service-catalog-head">
          <div><span className="eyebrow">خدمات وباقات زين</span><h2 id="service-catalog-title">شنو تحتاج اليوم؟</h2><p>تصفح {serviceItems.length} خدمة واشتراكاً حسب احتياجك.</p></div>
          <span className="catalog-spark">✦</span>
        </div>
        <div className="service-group-tabs" role="tablist" aria-label="تصنيف الخدمات">
          {serviceGroups.map((group) => <button key={group} className={activeServiceGroup === group ? "active" : ""} onClick={() => setActiveServiceGroup(group)}>{group}</button>)}
        </div>
        <div className="service-catalog-grid">
          {visibleServices.map((item) => (
            <button className="service-tile" key={item.id} onClick={() => setSelectedService(item)}>
              {item.image ? <span className="service-tile-image"><img src={item.image} alt="" loading="lazy" onError={(event) => { event.currentTarget.style.display = "none"; }} /></span> : <span className={`service-tile-icon service-tone-${item.tone}`}>{item.icon}</span>}
              <span className="service-tile-copy"><b>{item.title}</b><small>{item.group}</small></span>
              {item.label && <span className="service-tile-label">{item.label}</span>}
              <span className="service-tile-arrow">←</span>
            </button>
          ))}
        </div>
        <div className="catalog-footnote"><span>ⓘ</span><p>دليل الخدمات والباقات يجمع المعلومات العامة المنشورة. قد تختلف الأهلية والأسعار أو التوفر حسب نوع الخط ووقت الاشتراك.</p></div>
      </section>

      <section className="app-promo-card">
        <div><span className="promo-label">خدمات رقمية</span><h2>إدارة أسهل<br />لاتصالك اليومي</h2><p>اكتشف خدمات زين الرقمية وتعرّف على التطبيق الرسمي.</p><a href="https://www.iq.zain.com/ar/services/mobile-app" target="_blank" rel="noreferrer">اكتشف المزيد <span>←</span></a></div>
        <img src={officialAssets.app} alt="تطبيق زين العراق" loading="lazy" />
      </section>

      <section className="official-note"><span>ⓘ</span><p>هذه واجهة تجريبية مستقلة قيد التطوير. تُراجع تفاصيل الأسعار والأكواد وتوفر العروض قبل النشر، ويمكن الرجوع للموقع الرسمي للتحديثات.</p><a href="https://www.iq.zain.com/ar/offers" target="_blank" rel="noreferrer">الموقع الرسمي</a></section>

      <nav className="bottom-nav">
        <button className={activeTab === "الرئيسية" ? "active" : ""} onClick={() => { setActiveTab("الرئيسية"); setActiveCategory("الكل"); setSearchQuery(""); window.scrollTo({ top: 0, behavior: "smooth" }); }}><span>⌂</span><small>الرئيسية</small></button>
        <button className={activeTab === "العروض" ? "active" : ""} onClick={() => { setActiveTab("العروض"); document.getElementById("offers-section")?.scrollIntoView({ behavior: "smooth" }); }}><span>✧</span><small>العروض</small></button>
        <button className={activeTab === "الخدمات" ? "active" : ""} onClick={() => chooseCategory("الخدمات")}><span>▦</span><small>الخدمات</small></button>
        <button className={activeTab === "حسابي" ? "active" : ""} onClick={() => { setActiveTab("حسابي"); setNotice("ملف المستخدم سيُضاف عند ربط تسجيل الدخول."); }}><span>♙</span><small>حسابي</small></button>
      </nav>

      {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="إغلاق">×</button></div>}

      {selectedOffer && <div className="modal-backdrop" role="presentation" onClick={() => setSelectedOffer(null)}><section className="offer-modal" role="dialog" aria-modal="true" aria-label={`تفاصيل ${selectedOffer.title}`} onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setSelectedOffer(null)} aria-label="إغلاق">×</button><img src={selectedOffer.image} alt={`الصورة الترويجية لـ ${selectedOffer.title}`} onError={(event) => { event.currentTarget.style.display = "none"; event.currentTarget.parentElement?.classList.add("image-unavailable"); }} /><div className="modal-content"><span className="offer-category">{selectedOffer.category} · {selectedOffer.source}</span><h2>{selectedOffer.title}</h2>{selectedOffer.price !== undefined && <div className="modal-price"><strong>{selectedOffer.price.toLocaleString("en-US")}</strong><span>دينار عراقي</span></div>}<p>{selectedOffer.description}</p><div className="modal-spec-grid">{selectedOffer.internet && <div><small>الإنترنت / الرصيد</small><b>{selectedOffer.internet}</b></div>}{selectedOffer.minutes && <div><small>الدقائق</small><b>{selectedOffer.minutes}</b></div>}{selectedOffer.sms && <div><small>الرسائل</small><b>{selectedOffer.sms}</b></div>}{selectedOffer.validity && <div><small>الصلاحية</small><b>{selectedOffer.validity}</b></div>}{selectedOffer.code && <div><small>معلومات الرمز</small><b>{selectedOffer.code}</b></div>}</div>{selectedOffer.includes && selectedOffer.includes.length > 0 && <div className="modal-includes"><b>المزايا المشمولة</b>{selectedOffer.includes.map((item) => <span key={item}>✓ {item}</span>)}</div>}{selectedOffer.note && <p className="modal-note">{selectedOffer.note}</p>}<p className="modal-note">قد تختلف الأسعار والأهلية والتوفر حسب نوع الخط والفترة. تأكد من الشروط الرسمية قبل الاشتراك.</p><a className="modal-link" href={selectedOffer.sourceUrl} target="_blank" rel="noreferrer">عرض التفاصيل على موقع زين <span>↗</span></a></div></section></div>}

      {selectedService && <div className="modal-backdrop" role="presentation" onClick={() => setSelectedService(null)}><section className="service-modal" role="dialog" aria-modal="true" aria-label={`تفاصيل ${selectedService.title}`} onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setSelectedService(null)} aria-label="إغلاق">×</button>{selectedService.image ? <img className="service-modal-image" src={selectedService.image} alt={`صورة ${selectedService.title}`} /> : <div className={`service-modal-art service-tone-${selectedService.tone}`}><span>{selectedService.icon}</span><i>✦</i></div>}<div className="service-modal-content"><span className="eyebrow">{selectedService.group}</span><h2>{selectedService.title}</h2><p>{selectedService.description}</p><div className="service-modal-status"><span className="status-dot" /><span><b>تفاصيل التفعيل قيد التجهيز</b><small>هذه صفحة معلومات فقط حالياً؛ لم يُفعّل الاشتراك أو الاتصال من التطبيق بعد.</small></span></div><a className="modal-link" href={selectedService.sourceUrl} target="_blank" rel="noreferrer">زيارة صفحة زين الرسمية <span>↗</span></a></div></section></div>}

      <footer className="home-disclaimer">تصميم تجريبي · الصور الترويجية من الصفحات الرسمية المنشورة لزين · لا يمثل هذا الإصدار التطبيق الرسمي.</footer>
    </main>
  );
}
