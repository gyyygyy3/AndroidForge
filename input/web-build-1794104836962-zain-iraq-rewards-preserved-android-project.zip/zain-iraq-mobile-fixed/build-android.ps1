$ErrorActionPreference = 'Stop'

$nodeMajor = [int]((node -p "process.versions.node.split('.')[0]").Trim())
if ($nodeMajor -lt 22) {
  throw "Node.js 22 أو أحدث مطلوب. الإصدار الحالي غير مدعوم."
}

if (-not (Test-Path 'node_modules')) {
  npm install
  if ($LASTEXITCODE -ne 0) { throw 'فشل تثبيت حزم المشروع عبر npm.' }
}

npm run build:web
if ($LASTEXITCODE -ne 0) { throw 'فشل بناء واجهة Next.js أو تصدير مجلد out.' }

if (-not (Test-Path 'android')) {
  npm run android:setup
  if ($LASTEXITCODE -ne 0) { throw 'فشل إنشاء مشروع Android بواسطة Capacitor.' }
}

npx cap sync android
if ($LASTEXITCODE -ne 0) { throw 'فشل مزامنة ملفات التطبيق مع Android.' }

Push-Location 'android'
try {
  & .\gradlew.bat assembleDebug
  if ($LASTEXITCODE -ne 0) { throw 'فشل بناء APK عبر Gradle. تحقق من Android SDK وJDK داخل Android Studio.' }
}
finally {
  Pop-Location
}

$apk = Join-Path (Get-Location) 'android\app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) { throw 'انتهى Gradle دون العثور على ملف APK المتوقع.' }
Write-Host "تم إنشاء APK بنجاح: $apk" -ForegroundColor Green
