package com.zainiraq.offers

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

private val ZainOrange = Color(0xFFF36B21)
private val ZainDeep = Color(0xFF202633)
private val PageBg = Color(0xFFF5F6F8)
private val Muted = Color(0xFF737B89)
private val SoftOrange = Color(0xFFFFF0E7)
private val Border = Color(0xFFE8EAF0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 246, 248)
        window.navigationBarColor = android.graphics.Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = lightColorScheme(
                        primary = ZainOrange,
                        onPrimary = Color.White,
                        secondary = Color(0xFF263B56),
                        background = PageBg,
                        surface = Color.White,
                        onSurface = ZainDeep
                    )
                ) {
                    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
                        ZainApp()
                    }
                }
            }
        }
    }
}

private enum class AppScreen { WELCOME, METHOD, PHONE, VERIFY, PENDING, HOME }

private data class Offer(
    val id: String,
    val title: String,
    val description: String,
    val image: String,
    val tag: String,
    val category: String,
    val source: String,
    val sourceUrl: String,
    val price: Int?,
    val internet: String?,
    val minutes: String?,
    val sms: String?,
    val validity: String?,
    val includes: List<String>,
    val note: String?,
    val code: String?
)

private data class ServiceItem(
    val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val tone: String,
    val group: String,
    val sourceUrl: String,
    val label: String?,
    val image: String?
)

private data class Category(val title: String, val subtitle: String, val icon: String, val tone: String)
private data class HeroSlide(
    val kicker: String,
    val title: String,
    val description: String,
    val image: String,
    val action: String,
    val category: String
)
private data class Catalog(
    val offers: List<Offer>,
    val services: List<ServiceItem>,
    val categories: List<Category>,
    val slides: List<HeroSlide>,
    val appImage: String
)

private fun JSONObject.str(key: String, fallback: String = ""): String =
    if (isNull(key)) fallback else optString(key, fallback).let { if (it == "null") fallback else it }

private fun JSONObject.nullableStr(key: String): String? =
    if (isNull(key) || !has(key)) null else optString(key).takeIf { it.isNotBlank() && it != "null" }

private fun JSONObject.stringList(key: String): List<String> {
    val array = optJSONArray(key) ?: return emptyList()
    return buildList { for (i in 0 until array.length()) add(array.optString(i)) }
}

private fun JSONObject.intOrNull(key: String): Int? =
    if (!has(key) || isNull(key)) null else optInt(key)

private fun loadCatalog(context: android.content.Context): Catalog {
    val root = context.assets.open("content.json").bufferedReader().use { JSONObject(it.readText()) }
    val offerArray = root.optJSONArray("offers") ?: JSONArray()
    val offers = buildList {
        for (i in 0 until offerArray.length()) {
            val o = offerArray.getJSONObject(i)
            add(
                Offer(
                    id = o.str("id"), title = o.str("title"), description = o.str("description"),
                    image = o.str("image"), tag = o.str("tag"), category = o.str("category"),
                    source = o.str("source", "زين العراق"), sourceUrl = o.str("sourceUrl"),
                    price = o.intOrNull("price"), internet = o.nullableStr("internet"),
                    minutes = o.nullableStr("minutes"), sms = o.nullableStr("sms"),
                    validity = o.nullableStr("validity"), includes = o.stringList("includes"),
                    note = o.nullableStr("note"), code = o.nullableStr("code")
                )
            )
        }
    }
    val serviceArray = root.optJSONArray("serviceItems") ?: JSONArray()
    val services = buildList {
        for (i in 0 until serviceArray.length()) {
            val s = serviceArray.getJSONObject(i)
            add(
                ServiceItem(
                    id = s.str("id"), title = s.str("title"), description = s.str("description"),
                    icon = s.str("icon", "✦"), tone = s.str("tone"), group = s.str("group"),
                    sourceUrl = s.str("sourceUrl"), label = s.nullableStr("label"), image = s.nullableStr("image")
                )
            )
        }
    }
    val categoryArray = root.optJSONArray("categories") ?: JSONArray()
    val categories = buildList {
        for (i in 0 until categoryArray.length()) {
            val c = categoryArray.getJSONObject(i)
            add(Category(c.str("title"), c.str("subtitle"), c.str("icon"), c.str("tone")))
        }
    }
    val slideArray = root.optJSONArray("heroSlides") ?: JSONArray()
    val slides = buildList {
        for (i in 0 until slideArray.length()) {
            val h = slideArray.getJSONObject(i)
            add(HeroSlide(h.str("kicker"), h.str("title"), h.str("description"), h.str("image"), h.str("action"), h.str("category")))
        }
    }
    val appImage = root.optJSONObject("officialAssets")?.str("app").orEmpty()
    return Catalog(offers, services, categories, slides, appImage)
}

@Composable
private fun ZainApp() {
    val context = LocalContext.current
    appContext = context.applicationContext
    val catalog = remember { runCatching { loadCatalog(context) }.getOrElse { Catalog(emptyList(), emptyList(), emptyList(), emptyList(), "") } }
    var screen by remember { mutableStateOf(AppScreen.WELCOME) }
    var showSplash by remember { mutableStateOf(true) }
    var phone by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    var humanConfirmed by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }
    var activeCategory by remember { mutableStateOf("الكل") }
    var activeServiceGroup by remember { mutableStateOf("الكل") }
    var searchQuery by remember { mutableStateOf("") }
    var activeSlide by remember { mutableIntStateOf(0) }
    var selectedOffer by remember { mutableStateOf<Offer?>(null) }
    var selectedService by remember { mutableStateOf<ServiceItem?>(null) }
    var activeTab by remember { mutableStateOf("الرئيسية") }

    LaunchedEffect(Unit) {
        delay(1450)
        showSplash = false
    }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val filteredOffers = catalog.offers.filter { offer ->
        val categoryMatch = activeCategory == "الكل" || offer.category == activeCategory
        val q = searchQuery.trim().lowercase(Locale.ROOT)
        val searchText = listOfNotNull(offer.title, offer.description, offer.category, offer.internet, offer.minutes, offer.sms, offer.code).joinToString(" ") + " " + offer.includes.joinToString(" ")
        categoryMatch && (q.isBlank() || searchText.lowercase(Locale.ROOT).contains(q))
    }
    val filteredServices = catalog.services.filter { service ->
        val groupMatch = activeServiceGroup == "الكل" || service.group == activeServiceGroup
        val q = searchQuery.trim().lowercase(Locale.ROOT)
        groupMatch && (q.isBlank() || "${service.title} ${service.description} ${service.group}".lowercase(Locale.ROOT).contains(q))
    }

    if (showSplash) {
        SplashScreen()
        return
    }

    BackHandler(enabled = screen != AppScreen.WELCOME && screen != AppScreen.HOME) {
        screen = when (screen) {
            AppScreen.METHOD -> AppScreen.WELCOME
            AppScreen.PHONE -> AppScreen.METHOD
            AppScreen.VERIFY -> AppScreen.PHONE
            AppScreen.PENDING -> AppScreen.HOME
            else -> screen
        }
    }

    if (screen != AppScreen.HOME) {
        RewardFlowScreen(
            screen = screen,
            phone = phone,
            onPhoneChange = { phone = it; notice = "" },
            consent = consent,
            onConsentChange = { consent = it },
            humanConfirmed = humanConfirmed,
            onHumanConfirmedChange = { humanConfirmed = it; notice = "" },
            notice = notice,
            onNoticeDismiss = { notice = "" },
            onContinue = { target -> screen = target; notice = "" },
            onSubmitPhone = {
                val normalized = phone.replace(Regex("[\\s-]"), "")
                val valid = Regex("^(07[0-9]{9}|\\+9647[0-9]{9}|9647[0-9]{9})$").matches(normalized)
                when {
                    !valid -> notice = "يرجى إدخال رقم هاتف عراقي صحيح، مثل 07XXXXXXXXX."
                    !consent -> notice = "يرجى الموافقة على استخدام الرقم لمعالجة طلب المكافأة."
                    else -> { notice = ""; screen = AppScreen.VERIFY }
                }
            },
            onConfirmRequest = {
                if (!humanConfirmed) notice = "يرجى تأكيد أنك صاحب الطلب للمتابعة."
                else { notice = ""; screen = AppScreen.PENDING }
            }
        )
        return
    }

    HomeScreen(
        catalog = catalog,
        filteredOffers = filteredOffers,
        filteredServices = filteredServices,
        activeCategory = activeCategory,
        activeServiceGroup = activeServiceGroup,
        searchQuery = searchQuery,
        activeSlide = activeSlide,
        activeTab = activeTab,
        listState = listState,
        notice = notice,
        onSearch = { searchQuery = it; activeTab = "العروض" },
        onCategory = { category -> activeCategory = category; activeTab = "العروض"; notice = ""; scope.launch { listState.animateScrollToItem(4) } },
        onServiceGroup = { activeServiceGroup = it },
        onSlide = { activeSlide = it },
        onOffer = { selectedOffer = it },
        onService = { selectedService = it },
        onNotice = { notice = it },
        onDismissNotice = { notice = "" },
        onTab = { tab ->
            activeTab = tab
            when (tab) {
                "الرئيسية" -> { activeCategory = "الكل"; activeServiceGroup = "الكل"; searchQuery = ""; scope.launch { listState.animateScrollToItem(0) } }
                "العروض" -> scope.launch { listState.animateScrollToItem(4.coerceAtMost(4 + filteredOffers.size)) }
                "الخدمات" -> scope.launch { listState.animateScrollToItem((5 + filteredOffers.size).coerceAtMost(5 + filteredOffers.size + filteredServices.size)) }
                "حسابي" -> notice = "ملف المستخدم سيُضاف عند ربط تسجيل الدخول."
            }
        }
    )

    selectedOffer?.let { offer -> OfferDetailsDialog(offer, onDismiss = { selectedOffer = null }) }
    selectedService?.let { service -> ServiceDetailsDialog(service, onDismiss = { selectedService = null }) }
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF202633), Color(0xFF36465B), Color(0xFF202633)))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandMark(large = true, dark = true)
            Spacer(Modifier.height(22.dp))
            Box(Modifier.width(54.dp).height(4.dp).clip(CircleShape).background(SoftOrange))
            Spacer(Modifier.height(14.dp))
            Text("عالمك من زين… أقرب", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(34.dp))
            Text("واجهة تجريبية مستقلة", color = Color(0xFFCDD4DE), fontSize = 11.sp)
        }
    }
}

@Composable
private fun BrandMark(large: Boolean = false, dark: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(if (large) 38.dp else 30.dp).clip(CircleShape).background(ZainOrange), contentAlignment = Alignment.Center) {
            Text("✦", color = Color.White, fontSize = if (large) 22.sp else 18.sp, fontWeight = FontWeight.Bold)
        }
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("zain", color = if (dark) Color.White else ZainDeep, fontSize = if (large) 31.sp else 23.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp)
            Text("العراق", color = if (dark) Color(0xFFFFC7A5) else ZainOrange, fontSize = if (large) 12.sp else 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RewardFlowScreen(
    screen: AppScreen,
    phone: String,
    onPhoneChange: (String) -> Unit,
    consent: Boolean,
    onConsentChange: (Boolean) -> Unit,
    humanConfirmed: Boolean,
    onHumanConfirmedChange: (Boolean) -> Unit,
    notice: String,
    onNoticeDismiss: () -> Unit,
    onContinue: (AppScreen) -> Unit,
    onSubmitPhone: () -> Unit,
    onConfirmRequest: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().background(PageBg).padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            BrandMark()
            Surface(shape = CircleShape, color = Color(0xFFE9EDF2)) {
                Text("●  نموذج تجريبي", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Muted, fontSize = 11.sp)
            }
        }
        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.White)
                .padding(horizontal = 20.dp, vertical = 22.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            when (screen) {
                AppScreen.WELCOME -> {
                    Box(Modifier.size(100.dp).clip(CircleShape).background(SoftOrange), contentAlignment = Alignment.Center) {
                        Text("🎁", fontSize = 48.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Eyebrow("هدية ترحيبية للمستخدم الجديد")
                    Spacer(Modifier.height(8.dp))
                    Text("مبروك!", fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, color = ZainDeep)
                    Spacer(Modifier.height(8.dp))
                    Text("قد تكون مؤهلاً للحصول على مكافأة ترحيبية بقيمة", color = Muted, fontSize = 15.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(4.dp))
                    Text("5,000", color = ZainOrange, fontSize = 44.sp, fontWeight = FontWeight.Black)
                    Text("دينار عراقي", color = ZainDeep, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Text("تُراجع أهلية الطلب وتُصرف المكافأة بعد اعتمادها وتأكيد التحويل.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(22.dp))
                    PrimaryAction("اضغط للاستلام") { onContinue(AppScreen.METHOD) }
                    Spacer(Modifier.height(12.dp))
                    Text("المكافأة الترويجية تخضع لشروط الأهلية والتوفر.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Text("هذا نموذج تجريبي مستقل؛ لا ينفّذ تحويلات مالية ولا يمثل التطبيق الرسمي.", color = Color(0xFFB45A2C), fontSize = 10.sp, textAlign = TextAlign.Center)
                }
                AppScreen.METHOD -> {
                    StepTag("الخطوة 1 من 3")
                    Spacer(Modifier.height(16.dp))
                    Eyebrow("استلام المكافأة")
                    Spacer(Modifier.height(8.dp))
                    Text("اختر وسيلة الاستلام", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = ZainDeep, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("اختر المحفظة التي ترغب باستلام المكافأة عليها.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                    Surface(shape = RoundedCornerShape(18.dp), color = SoftOrange, border = BorderStroke(1.dp, Color(0xFFFFD6C0)), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            WalletLogo()
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Zain Cash", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ZainDeep)
                                Text("محفظة زين كاش", fontSize = 12.sp, color = Muted)
                            }
                            Text("●", color = ZainOrange, fontSize = 18.sp)
                        }
                    }
                    Spacer(Modifier.height(26.dp))
                    PrimaryAction("متابعة") { onContinue(AppScreen.PHONE) }
                    TextButton(onClick = { onContinue(AppScreen.WELCOME) }) { Text("رجوع", color = Muted) }
                }
                AppScreen.PHONE -> {
                    StepTag("الخطوة 2 من 3")
                    Spacer(Modifier.height(14.dp))
                    WalletLogo(large = true)
                    Spacer(Modifier.height(13.dp))
                    Text("بيانات محفظة زين كاش", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = ZainDeep, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("قم بإدخال رقمك على زين كاش لتحويل المكافأة له", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(18.dp))
                    Text("رقم الهاتف المرتبط بمحفظة زين كاش", modifier = Modifier.fillMaxWidth(), color = ZainDeep, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Start)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = phone,
                        onValueChange = onPhoneChange,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("07XXXXXXXXX", color = Color(0xFF9AA1AC)) },
                        leadingIcon = { Text("🇮🇶 +964", color = ZainDeep, fontSize = 12.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(14.dp)
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = consent, onCheckedChange = onConsentChange)
                        Text("أوافق على استخدام الرقم الذي أدخلته لمعالجة طلب المكافأة والتواصل معي بشأنه.", color = Muted, fontSize = 11.sp)
                    }
                    if (notice.isNotBlank()) NoticeText(notice, onNoticeDismiss)
                    Spacer(Modifier.height(12.dp))
                    PrimaryAction("متابعة", onSubmitPhone)
                    Spacer(Modifier.height(8.dp))
                    Text("هذا نموذج أولي؛ لا يُرسل الرقم إلى أي خادم حالياً.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                    TextButton(onClick = { onContinue(AppScreen.METHOD) }) { Text("رجوع", color = Muted) }
                }
                AppScreen.VERIFY -> {
                    StepTag("الخطوة 3 من 3")
                    Spacer(Modifier.height(22.dp))
                    Box(Modifier.size(76.dp).clip(CircleShape).background(Color(0xFFEAF7EF)), contentAlignment = Alignment.Center) {
                        Text("✓", color = Color(0xFF238B57), fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("تأكيد الطلب", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = ZainDeep)
                    Spacer(Modifier.height(8.dp))
                    Text("يرجى تأكيد أنك صاحب الطلب قبل إرسال طلب مراجعة المكافأة.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(18.dp))
                    Surface(shape = RoundedCornerShape(16.dp), color = PageBg, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = humanConfirmed, onCheckedChange = onHumanConfirmedChange)
                            Column {
                                Text("أنا صاحب هذا الطلب", color = ZainDeep, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("أؤكد أنني أدخلت رقم محفظتي بنفسي.", color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                    if (notice.isNotBlank()) NoticeText(notice, onNoticeDismiss)
                    Spacer(Modifier.height(18.dp))
                    PrimaryAction("تأكيد ومتابعة", onConfirmRequest)
                    Spacer(Modifier.height(8.dp))
                    Text("هذا تأكيد للطلب وليس اختبار CAPTCHA أو إثباتاً تقنياً ضد الروبوتات.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                    TextButton(onClick = { onContinue(AppScreen.PHONE) }) { Text("رجوع", color = Muted) }
                }
                AppScreen.PENDING -> {
                    Box(Modifier.size(78.dp).clip(CircleShape).background(Color(0xFFEAF7EF)), contentAlignment = Alignment.Center) {
                        Text("✓", color = Color(0xFF238B57), fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(14.dp))
                    Eyebrow("تم استلام طلبك")
                    Spacer(Modifier.height(7.dp))
                    Text("شكراً لك!", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = ZainDeep)
                    Spacer(Modifier.height(12.dp))
                    Text("5,000", color = ZainOrange, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    Text("د.ع", color = ZainDeep, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text("تم تسجيل طلب مراجعة المكافأة بنجاح في هذه النسخة التجريبية.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFFFF7E8), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("●  حالة المكافأة: قيد المراجعة", color = Color(0xFF98601A), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("لم يتم تحويل أي مبلغ بعد.", color = Muted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("لن تظهر رسالة «تم التحويل» إلا بعد تأكيد التحويل الفعلي من الجهة المسؤولة.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(18.dp))
                    PrimaryAction("الانتقال إلى التطبيق") { onContinue(AppScreen.HOME) }
                }
                else -> Unit
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("نسخة تجريبية قيد التطوير · عروض وخدمات زين العراق", color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun WalletLogo(large: Boolean = false) {
    Box(Modifier.size(if (large) 58.dp else 48.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF243A51)), contentAlignment = Alignment.Center) {
        Text("Z", color = Color.White, fontSize = if (large) 30.sp else 25.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun StepTag(text: String) {
    Surface(shape = CircleShape, color = SoftOrange) {
        Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp), color = ZainOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Eyebrow(text: String) {
    Text(text, color = ZainOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun PrimaryAction(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ZainOrange, contentColor = Color.White)
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text("←", fontSize = 18.sp)
    }
}

@Composable
private fun NoticeText(text: String, onDismiss: () -> Unit) {
    Surface(color = Color(0xFFFFEEEE), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, modifier = Modifier.weight(1f), color = Color(0xFFB33D3D), fontSize = 11.sp)
            Text("×", modifier = Modifier.clickable { onDismiss() }.padding(horizontal = 5.dp), color = Color(0xFFB33D3D), fontSize = 18.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    catalog: Catalog,
    filteredOffers: List<Offer>,
    filteredServices: List<ServiceItem>,
    activeCategory: String,
    activeServiceGroup: String,
    searchQuery: String,
    activeSlide: Int,
    activeTab: String,
    listState: LazyListState,
    notice: String,
    onSearch: (String) -> Unit,
    onCategory: (String) -> Unit,
    onServiceGroup: (String) -> Unit,
    onSlide: (Int) -> Unit,
    onOffer: (Offer) -> Unit,
    onService: (ServiceItem) -> Unit,
    onNotice: (String) -> Unit,
    onDismissNotice: () -> Unit,
    onTab: (String) -> Unit
) {
    val filters = listOf("الكل", "الإنترنت", "كفوو", "كفوو العائلة", "سوبر كارد", "بكيفي", "تيك توك", "فوول الفوول", "عروض المناطق", "التجوال", "الدفع الآجل", "زين فاي", "عروض خاصة", "أجهزة وعروض", "ممنون", "الخدمات")
    val serviceGroups = listOf("الكل", "خدمات الخط", "خدمات المكالمات", "خدمات الإنترنت", "باقات الإنترنت", "الباقات المتكاملة", "الخدمات الرقمية", "العروض الخاصة", "المكافآت", "خدمات ترفيهية", "خدمات السفر", "خدمات الدعم")
    LaunchedEffect(activeSlide, catalog.slides.size) {
        if (catalog.slides.size > 1) {
            delay(6500)
            onSlide((activeSlide + 1) % catalog.slides.size)
        }
    }
    Box(Modifier.fillMaxSize().background(PageBg)) {
      Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            BrandMark()
                            Text("أهلاً بك، شنو تحتاج اليوم؟", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                        Surface(shape = CircleShape, color = Color.White, border = BorderStroke(1.dp, Border), modifier = Modifier.size(42.dp).clickable { onNotice("ملف المستخدم سيُضاف في مرحلة ربط الحسابات.") }) {
                            Box(contentAlignment = Alignment.Center) { Text("م", color = ZainOrange, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearch,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("ابحث عن باقة أو خدمة أو عرض", color = Muted, fontSize = 13.sp) },
                        leadingIcon = { Text("⌕", fontSize = 24.sp, color = ZainOrange) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        StatCard(catalog.offers.size.toString(), "باقة وعرض", Modifier.weight(1f))
                        StatCard(catalog.services.size.toString(), "خدمة", Modifier.weight(1f))
                        StatCard(catalog.categories.size.toString(), "تصنيف", Modifier.weight(1f))
                    }
                }
            }
            item {
                val slide = catalog.slides.getOrNull(activeSlide)
                if (slide != null) HeroCard(slide = slide, currentIndex = activeSlide, total = catalog.slides.size, onAction = { onCategory(slide.category) }, onSlide = onSlide)
            }
            item { QuickActions(onNotice = onNotice, onCategory = onCategory) }
            item {
                Column(Modifier.fillMaxWidth()) {
                    SectionTitle("كل شيء بمكان واحد", "تصفح الباقات حسب القسم")
                    androidx.compose.foundation.lazy.LazyRow(
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 15.dp),
                        horizontalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        items(catalog.categories, key = { it.title }) { category ->
                            CategoryCard(category, catalog.offers.count { it.category == category.title }) { onCategory(category.title) }
                        }
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 15.dp)) {
                    SectionTitle("كتالوج زين · ${catalog.offers.size} باقة وعرض", if (activeCategory == "الكل") "كل العروض والباقات" else "عروض $activeCategory")
                    Text("مراجعة المصادر العامة · تظهر الباقات العامة المعلنة، وقد تختلف العروض المخصصة حسب الرقم والمنطقة.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp, bottom = 4.dp))
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(filters) { filter ->
                            FilterChip(selected = activeCategory == filter, onClick = { onCategory(filter) }, label = { Text(filter, fontSize = 11.sp) })
                        }
                    }
                    Text("يعرض التطبيق ${filteredOffers.size} من ${catalog.offers.size} باقة وعرض ضمن هذا التصنيف", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 7.dp))
                }
            }
            if (filteredOffers.isEmpty()) {
                item {
                    EmptyState("ما لقينا نتائج مطابقة", "جرّب كلمة بحث ثانية أو غيّر القسم.")
                }
            } else {
                items(filteredOffers, key = { it.id }) { offer -> OfferCard(offer) { onOffer(offer) } }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 15.dp)) {
                    SectionTitle("خدمات وباقات زين", "شنو تحتاج اليوم؟")
                    Text("تصفح ${catalog.services.size} خدمة واشتراكاً حسب احتياجك.", color = Muted, fontSize = 11.sp)
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
                        items(serviceGroups) { group ->
                            FilterChip(selected = activeServiceGroup == group, onClick = { onServiceGroup(group) }, label = { Text(group, fontSize = 10.sp) })
                        }
                    }
                }
            }
            if (filteredServices.isEmpty()) {
                item { EmptyState("لا توجد خدمات مطابقة", "غيّر مجموعة الخدمات أو كلمة البحث.") }
            } else {
                items(filteredServices, key = { it.id }) { service -> ServiceCard(service) { onService(service) } }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF263B56))
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("خدمات رقمية", color = Color(0xFFFFC7A5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("إدارة أسهل لاتصالك اليومي", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                            Text("اكتشف خدمات زين الرقمية وتعرّف على التطبيق الرسمي.", color = Color(0xFFD9E0E8), fontSize = 11.sp)
                            TextButton(onClick = { openUrl("https://www.iq.zain.com/ar/services/mobile-app") }) { Text("اكتشف المزيد ←", color = Color(0xFFFFC7A5)) }
                        }
                        Spacer(Modifier.width(8.dp))
                        AsyncImage(model = catalog.appImage, contentDescription = "تطبيق زين العراق", modifier = Modifier.size(94.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 3.dp)) {
                    Text("ⓘ  هذه واجهة تجريبية مستقلة قيد التطوير. الأسعار والأكواد والتوفر قد تتغير؛ راجع موقع زين الرسمي للتحديثات.", color = Muted, fontSize = 10.sp)
                    TextButton(onClick = { openUrl("https://www.iq.zain.com/ar/offers") }) { Text("الموقع الرسمي لزين", color = ZainOrange, fontSize = 11.sp) }
                    Text("لا يمثل هذا الإصدار التطبيق الرسمي.", color = Muted, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        }
        BottomNavigation(activeTab = activeTab, onTab = onTab)
      }
      if (notice.isNotBlank()) {
        Surface(color = ZainDeep, shape = RoundedCornerShape(14.dp), shadowElevation = 8.dp, modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(notice, modifier = Modifier.weight(1f), color = Color.White, fontSize = 12.sp)
                Text("×", modifier = Modifier.clickable { onDismissNotice() }.padding(start = 10.dp), color = Color.White, fontSize = 19.sp)
            }
        }
      }
    }
}

@Composable
private fun StatCard(number: String, label: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(13.dp), color = Color.White, border = BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(number, color = ZainOrange, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SectionTitle(eyebrow: String, title: String) {
    Column(Modifier.padding(horizontal = 15.dp, vertical = 2.dp)) {
        Text(eyebrow, color = ZainOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(title, color = ZainDeep, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun HeroCard(slide: HeroSlide, currentIndex: Int, total: Int, onAction: () -> Unit, onSlide: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF263B56))
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("●  ${slide.kicker}", color = Color(0xFFFFC7A5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(slide.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 28.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(slide.description, color = Color(0xFFD7E0E9), fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = ZainOrange), shape = RoundedCornerShape(12.dp)) {
                        Text(slide.action, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                AsyncImage(model = slide.image, contentDescription = "مواد ترويجية من زين العراق", modifier = Modifier.width(116.dp).height(148.dp).clip(RoundedCornerShape(17.dp)), contentScale = ContentScale.Crop)
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(total) { index ->
                    Box(Modifier.padding(horizontal = 3.dp).size(if (index == currentIndex) 19.dp else 7.dp, 7.dp).clip(CircleShape).background(if (index == currentIndex) ZainOrange else Color(0xFF7B899A)).clickable { onSlide(index) })
                }
            }
        }
    }
}

@Composable
private fun QuickActions(onNotice: (String) -> Unit, onCategory: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        QuickAction("↻", "إعادة الشحن", Color(0xFFFFF0E7), Modifier.weight(1f)) { onNotice("إعادة الشحن المباشر ستُفعّل بعد ربط بوابة زين المعتمدة.") }
        QuickAction("◉", "باقات الإنترنت", Color(0xFFEAF2FF), Modifier.weight(1f)) { onCategory("الإنترنت") }
        QuickAction("✈", "التجوال", Color(0xFFE9F7F5), Modifier.weight(1f)) { onCategory("التجوال") }
        QuickAction("♡", "ممنون", Color(0xFFFFF5E3), Modifier.weight(1f)) { onCategory("ممنون") }
    }
}

@Composable
private fun QuickAction(icon: String, label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { onClick() }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            Text(icon, color = ZainOrange, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = ZainDeep, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CategoryCard(category: Category, count: Int, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.width(142.dp).height(104.dp).clickable { onClick() },
        shape = RoundedCornerShape(17.dp), color = Color.White, border = BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(33.dp).clip(RoundedCornerShape(11.dp)).background(toneColor(category.tone)), contentAlignment = Alignment.Center) {
                    Text(category.icon, color = ZainOrange, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text(count.toString(), color = Muted, fontSize = 10.sp)
            }
            Column {
                Text(category.title, color = ZainDeep, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(category.subtitle, color = Muted, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun OfferCard(offer: Offer, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp).clickable { onClick() },
        shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Border)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(155.dp).background(Color(0xFFF1F3F6))) {
                AsyncImage(model = offer.image, contentDescription = offer.title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Surface(color = ZainOrange, shape = RoundedCornerShape(topStart = 0.dp, bottomEnd = 13.dp), modifier = Modifier.align(Alignment.TopEnd)) {
                    Text(offer.tag, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.padding(14.dp)) {
                Text("${offer.category} · ${offer.tag}", color = ZainOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(offer.title, color = ZainDeep, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                if (offer.price != null) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(formatNumber(offer.price), color = ZainOrange, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(" د.ع", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                    }
                }
                Text(offer.description, color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
                val specs = listOfNotNull(offer.internet, offer.minutes, offer.validity)
                if (specs.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        specs.take(3).forEach { spec ->
                            Surface(color = PageBg, shape = RoundedCornerShape(8.dp)) {
                                Text(spec, color = ZainDeep, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp), fontSize = 9.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("عرض التفاصيل ←", color = ZainOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ServiceCard(service: ServiceItem, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp).clickable { onClick() },
        shape = RoundedCornerShape(16.dp), color = Color.White, border = BorderStroke(1.dp, Border)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!service.image.isNullOrBlank()) {
                AsyncImage(model = service.image, contentDescription = service.title, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(toneColor(service.tone)), contentAlignment = Alignment.Center) {
                    Text(service.icon, color = ZainOrange, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(service.title, color = ZainDeep, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(service.group, color = Muted, fontSize = 10.sp)
                if (!service.label.isNullOrBlank()) Text(service.label, color = ZainOrange, fontSize = 9.sp)
            }
            Text("←", color = ZainOrange, fontSize = 19.sp)
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("⌕", color = ZainOrange, fontSize = 34.sp)
        Text(title, color = ZainDeep, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun BottomNavigation(activeTab: String, onTab: (String) -> Unit) {
    Surface(color = Color.White, shadowElevation = 8.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            listOf("الرئيسية" to "⌂", "العروض" to "✧", "الخدمات" to "▦", "حسابي" to "♙").forEach { (label, icon) ->
                Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onTab(label) }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(icon, color = if (activeTab == label) ZainOrange else Muted, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(label, color = if (activeTab == label) ZainOrange else Muted, fontSize = 9.sp, fontWeight = if (activeTab == label) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun OfferDetailsDialog(offer: Offer, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(offer.title, color = ZainDeep, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) },
        text = {
            Column(Modifier.heightIn(max = 460.dp)) {
                AsyncImage(model = offer.image, contentDescription = offer.title, modifier = Modifier.fillMaxWidth().height(145.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(10.dp))
                Text("${offer.category} · ${offer.source}", color = ZainOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                if (offer.price != null) Text("${formatNumber(offer.price)} دينار عراقي", color = ZainOrange, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text(offer.description, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                listOfNotNull(
                    offer.internet?.let { "الإنترنت / الرصيد: $it" },
                    offer.minutes?.let { "الدقائق: $it" },
                    offer.sms?.let { "الرسائل: $it" },
                    offer.validity?.let { "الصلاحية: $it" },
                    offer.code?.let { "معلومات الرمز: $it" }
                ).forEach { Text("• $it", color = ZainDeep, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp)) }
                if (offer.includes.isNotEmpty()) {
                    Spacer(Modifier.height(7.dp))
                    Text("المزايا المشمولة", color = ZainDeep, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    offer.includes.forEach { Text("✓ $it", color = Muted, fontSize = 11.sp) }
                }
                offer.note?.let { Text(it, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp)) }
                Text("قد تختلف الأسعار والأهلية والتوفر حسب نوع الخط والفترة. تأكد من الشروط الرسمية قبل الاشتراك.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(onClick = { openUrl(offer.sourceUrl) }) { Text("موقع زين الرسمي ↗", color = ZainOrange) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إغلاق", color = Muted) } },
        containerColor = Color.White
    )
}

@Composable
private fun ServiceDetailsDialog(service: ServiceItem, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(service.title, color = ZainDeep, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                Text(service.group, color = ZainOrange, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text(service.description, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Surface(shape = RoundedCornerShape(13.dp), color = PageBg) {
                    Column(Modifier.padding(12.dp)) {
                        Text("تفاصيل التفعيل قيد التجهيز", color = ZainDeep, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("هذه صفحة معلومات فقط حالياً؛ لم يُفعّل الاشتراك أو الاتصال من التطبيق بعد.", color = Muted, fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { openUrl(service.sourceUrl) }) { Text("زيارة صفحة زين الرسمية ↗", color = ZainOrange) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إغلاق", color = Muted) } },
        containerColor = Color.White
    )
}

private fun formatNumber(value: Int): String = NumberFormat.getIntegerInstance(Locale.US).format(value)

private fun toneColor(tone: String): Color = when (tone.lowercase(Locale.ROOT)) {
    "violet", "purple" -> Color(0xFFF0ECFF)
    "aqua", "mint" -> Color(0xFFE6F7F3)
    "pink" -> Color(0xFFFFEAF2)
    "orange" -> Color(0xFFFFF0E7)
    "blue" -> Color(0xFFEAF2FF)
    "gold" -> Color(0xFFFFF5DF)
    else -> Color(0xFFEFF1F4)
}

private fun openUrl(url: String) {
    if (url.isBlank()) return
    runCatching {
        // Launches the official information page in the device's browser; no subscription is initiated here.
        appContext?.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private var appContext: android.content.Context? = null
