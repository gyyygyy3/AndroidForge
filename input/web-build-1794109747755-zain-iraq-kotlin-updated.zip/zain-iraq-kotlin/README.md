# Zain Iraq Offers and Services — Native Android / Kotlin

Native Android app built with Kotlin and Jetpack Compose. The app includes an Arabic RTL offers/services catalog, local phone-format validation, a five-second processing view, and a button that opens the official Zain Iraq app (or its Google Play page if it is not installed).

After the user completes the intro flow, the app stores a local preference and opens directly to the offers home screen on subsequent launches. Phone numbers are validated on-device only and are not sent to a server or stored. No reward or payment backend is connected, so the app does not claim that a reward has been won or a transfer has been scheduled.

The project is an independent information app, not the official Zain Iraq app. See `README-AR.md` for setup and implementation details.

Build with JDK 17, Android SDK 35 and Gradle 8.9+:

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
