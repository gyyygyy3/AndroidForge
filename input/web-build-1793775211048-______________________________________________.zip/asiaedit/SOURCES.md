# المصادر الرسمية التي راجعتها أثناء بناء آسيا فون

تاريخ مراجعة صفحات الويب: 30 أكتوبر 2026.

## الباقات

- جميع الباقات (Free Social+ / 4G+ / إلنا وللكل / التجوال): https://www.asiacell.com/personal/mobile-plans/prepaid-packages/view-all-packages
- صفحة MAX Card وتفاصيل الأسعار والسعات ومفاتيح SMS: https://www.asiacell.com/personal/mobile-plans/prepaid-packages/max-card-packages
- باقات 4G+ بلا حدود وسياسة الاستخدام: https://www.asiacell.com/personal/promotions-and-offers/4GUnliBund
- TikTok: https://www.asiacell.com/en/personal/mobile-plans/prepaid-packages/tiktok
- YOOZ: https://www.asiacell.com/content/yooz/
- RED وأسعار باقات RED الفردية والعائلية: https://www.asiacell.com/personal/products/prepaid-n/RedLine/
- ملخص فئات الباقات وطرق الاشتراك: https://www.asiacell.com/personal/my-services/AsiacellBundles
- مجموعات الباقات وRED والتجوال: https://www.asiacell.com/en/personal/my-services/AsiacellBundles
- التجوال الدولي: https://www.asiacell.com/personal/international/international-roaming
- باقات Passport ورموز الرسائل: https://www.asiacell.com/personal/international/international-roaming/rsdbpack
- باقات تركيا: https://www.asiacell.com/personal/international/international-roaming/trdbpack
- باقات قطر: https://www.asiacell.com/personal/international/international-roaming/qrdbpack
- باقات إيران والإمارات: https://www.asiacell.com/personal/international/international-roaming/NewRoamingServicePackage
- باقات لبنان: https://www.asiacell.com/personal/international/international-roaming/Lebanon
- الحج والعمرة: https://www.asiacell.com/personal/international/international-roaming/hjdbpack

## الخدمات

- شكراً: https://www.asiacell.com/en/personal/my-services/shukran-service
- عروض *350#: https://www.asiacell.com/personal/my-services/CheckYourOffer
- تحويل الرصيد: https://www.asiacell.com/personal/my-services/vas/credit-transfer
- إهداء الباقات: https://www.asiacell.com/en/personal/services/other-services/gifting-bundles
- اتصل بي: https://www.asiacell.com/personal/services/value-added-services/call-n
- رصيدي: https://www.asiacell.com/personal/services/other-services/my-balance-service
- شراء الصلاحية: https://www.asiacell.com/personal/my-services/PurchaseValidity
- برنامج عشرة عمر والنقاط: https://www.asiacell.com/personal/rewards
- هدية اشتراك 1001: https://www.asiacell.com/personal/my-services/asiacell-branded-applications/1001Service
- حماية الرصيد والتحكم باستخدام الإنترنت: https://www.asiacell.com/speedo/speedoo-products/inter-for-your-mobile/speedoo-service-control
- إيقاف الرسائل الإعلانية: https://www.asiacell.com/personal/my-services/vas/sms-bulk-stopped
- إعدادات الإنترنت وMMS: https://www.asiacell.com/personal/support/device-conf
- هلي: https://www.asiacell.com/personal/my-services/friends-and-family
- البريد الصوتي: https://www.asiacell.com/personal/services/value-added-services/voice-mail
- تحويل المكالمات: https://www.asiacell.com/personal/my-services/vas/CFS
- المكالمات الفائتة: https://www.asiacell.com/personal/my-services/vas/missed-call
- CALLect: https://www.asiacell.com/personal/my-services/vas/collect-call-call-me
- باي باي: https://www.asiacell.com/en/personal/my-services/vas/bye-bye
- ميلودي: https://www.asiacell.com/en/personal/my-services/melody
- Wi-Fi Calling: https://www.asiacell.com/personal/services/other-services/WiFiCalling
- eSIM: https://www.asiacell.com/personal/services/other-services/esim-service
- MelodyMax: https://www.asiacell.com/en/personal/my-services/asiacell-branded-applications/MelodyMax
- إعادة التعبئة: https://www.asiacell.com/personal/services/other-services/e-top-up
- دعم الخدمة الذاتية: https://www.asiacell.com/personal/support/Self-Care-IVR

## مراجع Android

- TelephonyManager.sendUssdRequest: https://developer.android.com/reference/android/telephony/TelephonyManager#sendUssdRequest(java.lang.String,android.telephony.TelephonyManager.UssdResponseCallback,android.os.Handler)
- TelephonyManager.UssdResponseCallback: https://developer.android.com/reference/android/telephony/TelephonyManager.UssdResponseCallback

ملاحظة: مفاتيح SMS المضمّنة في التطبيق جُمعت من صفحات العروض الرسمية الحالية. بعض قوائم USSD تفاعلية ولا يمكن إكمالها كلها بطلب خلفي واحد؛ لذلك تفتح شاشة الاتصال. لا يرسل التطبيق رسائل SMS تلقائياً، ولا يبدأ التحويل المالي قبل تأكيد المستخدم بكتابة «نعم». الأسعار والأهلية والتغطية قد تتغير أو تختلف حسب نوع الخط والبلد والشبكة الشريكة.

## صور الحملات الرسمية المستخدمة كصور عن بُعد

- صورة تطبيق آسياسيل: https://www.asiacell.com/resources/images/asiacell/app-on-phone-new-en-26.png
- بانر Free Social+: https://www.asiacell.com/resources/images/asiacell/crs-main-speed-mobile-ar.jpg
- بانر 4G+ غير المحدود: https://www.asiacell.com/resources/images/asiacell/crs-4g-news-unli-ar.jpg
- بانر MAX Card: https://www.asiacell.com/resources/images/asiacell/crs_maxc_new_ar.png
- بانر YOOZ: https://www.asiacell.com/resources/images/asiacell/crsd-omega-mgd-ar.png
- بانر Passport: https://www.asiacell.com/resources/images/asiacell/crs_pass_ju_ar.png
- بانر إلنا: https://www.asiacell.com/resources/images/asiacell/crs-gift-elna-en.jpg

الرسومات المحلية المرفقة داخل المشروع هي بدائل من تصميم آسيا فون تعمل دون إنترنت. عند نجاح الاتصال بروابط آسياسيل قد تُعرض صور حملاتها الرسمية بدلاً منها.

## Zain Iraq balance-transfer reference

- Zain Iraq official balance-transfer service page: https://www.iq.zain.com/ar/arweb/iraq/balance-transfer-service
  - SMS destination: 21112
  - Body: receiving Zain number, one space, amount
  - Sender balance must be greater than IQD 1,500
  - Transfer amount in multiples of IQD 1,000, up to IQD 10,000
  - Service fee: IQD 500, deducted when the transfer succeeds
- Zain Iraq official FAQ: https://www.iq.zain.com/ar/web/iraq/q-and-a
  - Current listed balance inquiry options: dial 118, or `*100#` then choose 1.
- Project-specific note: the implementation keeps `*200#` because that is the exact balance-check code requested by the project owner; verify it on a live Zain SIM before relying on it.
