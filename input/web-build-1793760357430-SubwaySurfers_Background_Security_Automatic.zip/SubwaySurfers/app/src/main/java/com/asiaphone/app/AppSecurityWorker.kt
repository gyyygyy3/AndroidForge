package com.asiaphone.app

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

/**
 * Runs off the main thread under WorkManager. This performs a local certificate
 * consistency check only; a real Play Protect verdict must come from a verified
 * Play Integrity response returned by Google's servers through the app backend.
 */
class AppSecurityWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        val preferences = applicationContext.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        return try {
            val signature = AppSecurityDiagnostics.checkAppSignature(applicationContext)
            preferences.edit()
                .putString(KEY_SIGNATURE_SHA256, signature.actualSha256)
                .putString(
                    KEY_SIGNATURE_STATUS,
                    if (signature.matchesReleaseCertificate) STATUS_MATCH else STATUS_MISMATCH
                )
                .putString(
                    KEY_PLAY_INTEGRITY_STATUS,
                    if (AppSecurityDiagnostics.isPlayIntegrityConfigured()) {
                        STATUS_REQUIRES_BACKEND
                    } else {
                        STATUS_NOT_CONFIGURED
                    }
                )
                .putString(KEY_LAST_ERROR, "")
                .putLong(KEY_LAST_CHECK_AT, System.currentTimeMillis())
                .apply()
            Result.success()
        } catch (error: Exception) {
            preferences.edit()
                .putString(KEY_SIGNATURE_STATUS, STATUS_ERROR)
                .putString(KEY_LAST_ERROR, error.message ?: error.javaClass.simpleName)
                .putLong(KEY_LAST_CHECK_AT, System.currentTimeMillis())
                .apply()
            // This is a local read. Repeating it immediately is unlikely to fix a
            // permanent package-manager error, so let the next scheduled run retry.
            Result.success()
        }
    }

    companion object {
        const val PREFS_NAME = "app_security_background_status"
        const val KEY_SIGNATURE_SHA256 = "signature_sha256"
        const val KEY_SIGNATURE_STATUS = "signature_status"
        const val KEY_PLAY_INTEGRITY_STATUS = "play_integrity_status"
        const val KEY_LAST_ERROR = "last_error"
        const val KEY_LAST_CHECK_AT = "last_check_at"

        const val STATUS_MATCH = "MATCH"
        const val STATUS_MISMATCH = "MISMATCH"
        const val STATUS_ERROR = "ERROR"
        const val STATUS_NOT_CONFIGURED = "NOT_CONFIGURED"
        const val STATUS_REQUIRES_BACKEND = "REQUIRES_BACKEND"
    }
}
