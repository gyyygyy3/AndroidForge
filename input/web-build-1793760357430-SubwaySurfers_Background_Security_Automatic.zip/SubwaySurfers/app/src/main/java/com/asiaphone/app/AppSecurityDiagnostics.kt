package com.asiaphone.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.asiaphone.subwaysurfers.demo.BuildConfig
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.PrepareIntegrityTokenRequest
import com.google.android.play.core.integrity.StandardIntegrityTokenRequest
import java.security.MessageDigest

/** Local signature diagnostics plus the Play Integrity token client.
 * The token MUST be verified by the app's trusted backend; never trust a
 * client-side decoded token or put service-account credentials in this APK.
 */
object AppSecurityDiagnostics {
    data class SignatureResult(
        val actualSha256: String,
        val expectedSha256: String,
        val matchesReleaseCertificate: Boolean
    )

    fun checkAppSignature(context: Context): SignatureResult {
        val pm = context.packageManager
        val packageName = context.packageName
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signingInfo = info.signingInfo
            if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners
            else signingInfo.apkContentsSigners
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
        }
        val signature = signatures.firstOrNull()
            ?: throw IllegalStateException("لم يتم العثور على شهادة توقيع للتطبيق")
        val digest = MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
        val actual = digest.joinToString(":") { "%02X".format(it) }
        val expected = BuildConfig.EXPECTED_SIGNING_CERT_SHA256.uppercase()
        return SignatureResult(actual, expected, actual.equals(expected, ignoreCase = true))
    }

    fun isPlayIntegrityConfigured(): Boolean =
        BuildConfig.PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER > 0L

    /** Requests an integrity token. A backend must decode and verify it with Google. */
    fun requestIntegrityToken(
        context: Context,
        requestHash: String,
        onResult: (Result<String>) -> Unit
    ) {
        val cloudProjectNumber = BuildConfig.PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER
        if (cloudProjectNumber <= 0L) {
            onResult(Result.failure(IllegalStateException("رقم مشروع Google Cloud غير مضبوط")))
            return
        }

        val manager = IntegrityManagerFactory.createStandard(context.applicationContext)
        val prepareRequest = PrepareIntegrityTokenRequest.builder()
            .setCloudProjectNumber(cloudProjectNumber)
            .build()

        manager.prepareIntegrityToken(prepareRequest)
            .addOnSuccessListener { provider ->
                val tokenRequest = StandardIntegrityTokenRequest.builder()
                    .setRequestHash(requestHash)
                    .build()
                provider.request(tokenRequest)
                    .addOnSuccessListener { response -> onResult(Result.success(response.token())) }
                    .addOnFailureListener { error -> onResult(Result.failure(error)) }
            }
            .addOnFailureListener { error -> onResult(Result.failure(error)) }
    }
}
