package com.asiaphone.app

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** Schedules automatic checks without a foreground service or user interaction. */
object AppSecurityScheduler {
    private const val PERIODIC_WORK_NAME = "automatic_app_security_check_daily"
    private const val OPEN_WORK_NAME = "automatic_app_security_check_on_open"

    fun schedule(context: Context) {
        val workManager = WorkManager.getInstance(context.applicationContext)

        val periodicRequest = PeriodicWorkRequestBuilder<AppSecurityWorker>(
            24,
            TimeUnit.HOURS
        ).build()

        workManager.enqueueUniquePeriodicWork(
            PERIODIC_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            periodicRequest
        )

        // Also request a check whenever the user opens the app. WorkManager runs
        // it on a background executor; it does not block the first screen.
        val launchRequest = OneTimeWorkRequestBuilder<AppSecurityWorker>().build()
        workManager.enqueueUniqueWork(
            OPEN_WORK_NAME,
            ExistingWorkPolicy.KEEP,
            launchRequest
        )
    }
}
