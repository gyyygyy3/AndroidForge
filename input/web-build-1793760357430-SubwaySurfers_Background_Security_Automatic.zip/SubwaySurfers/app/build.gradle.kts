import java.util.Properties

val integrityCloudProjectNumber = (project.findProperty("PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER") as String?)?.toLongOrNull() ?: 0L

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signingPropertiesFile = rootProject.file("signing.properties")
val signingProperties = Properties().apply {
    if (signingPropertiesFile.exists()) {
        signingPropertiesFile.inputStream().use { load(it) }
    }
}

android {
    namespace = "com.asiaphone.subwaysurfers.demo"
    // Pin to API 34, which is preinstalled in AndroidForge's build image.
    compileSdk = 34
    buildToolsVersion = "34.0.0"

    signingConfigs {
        create("release") {
            if (signingPropertiesFile.exists()) {
                storeFile = rootProject.file(signingProperties.getProperty("storeFile"))
                storePassword = signingProperties.getProperty("storePassword")
                keyAlias = signingProperties.getProperty("keyAlias")
                keyPassword = signingProperties.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        getByName("release") {
            if (signingPropertiesFile.exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "com.asiaphone.subwaysurfers.demo"
        minSdk = 26
        targetSdk = 34
        versionCode = 37002
        versionName = "3.70.2-demo"
        buildConfigField("long", "PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER", "${integrityCloudProjectNumber}L")
        buildConfigField("String", "EXPECTED_SIGNING_CERT_SHA256", "\"21:C5:93:13:C7:C7:4B:8F:32:73:D3:AC:A7:0F:62:65:C2:6D:3A:A3:0F:3F:49:D1:E8:14:46:90:57:CB:94:3E\"")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}


dependencies {
    // Background scheduling for automatic, battery-aware security checks.
    implementation("androidx.work:work-runtime:2.12.0")

    // Google Play Integrity API. A Cloud project number and a verification backend
    // are still required before a real Google verdict can be trusted.
    implementation("com.google.android.play:integrity:1.6.0")
}
