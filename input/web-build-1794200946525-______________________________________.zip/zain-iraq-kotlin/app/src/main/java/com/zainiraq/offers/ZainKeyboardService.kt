package com.zainiraq.offers

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

/** Local-only Arabic/English keyboard with conventional key layouts. */
class ZainKeyboardService : InputMethodService() {
    private enum class Language { ARABIC, ENGLISH }
    private var language = Language.ARABIC
    private var symbolsMode = false
    private var shifted = false
    private var keyboardRoot: LinearLayout? = null

    private val ink = Color.rgb(45, 38, 57)
    private val purple = Color.rgb(105, 52, 145)
    private val purpleDark = Color.rgb(78, 35, 112)
    private val page = Color.rgb(244, 240, 248)

    override fun onCreateInputView(): View = buildKeyboard().also { keyboardRoot = it }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shifted = false
        refreshKeyboard()
    }

    private fun buildKeyboard(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(7), dp(7), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(250, 248, 252), page)).apply { cornerRadius = dp(17).toFloat() }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val logo = TextView(this).apply {
            text = "Z"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(purple) }
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(26), dp(26)))
        val title = TextView(this).apply {
            text = if (language == Language.ARABIC) "زين  ·  لوحة المفاتيح" else "ZAIN  ·  KEYBOARD"
            textSize = 11f
            setTextColor(ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(dp(8), 0, dp(5), 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(29), 1f))
        TextView(this).apply {
            text = if (language == Language.ARABIC) "عربي" else "ENGLISH"
            textSize = 10f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }.also { header.addView(it, LinearLayout.LayoutParams(dp(54), dp(27))) }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(29)))
        root.addView(View(this).apply { setBackgroundColor(Color.rgb(229, 221, 235)) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(5); bottomMargin = dp(5) })

        if (symbolsMode) {
            addKeyRow(root, listOf("1","2","3","4","5","6","7","8","9","0"), 43)
            addKeyRow(root, listOf("@","#","$","%","&","-","+","(",")","/"), 43)
            addKeyRow(root, listOf("*","\"","'",":",";","!","؟",",","."), 43)
        } else {
            val numberRow = if (language == Language.ARABIC)
                listOf("١","٢","٣","٤","٥","٦","٧","٨","٩","٠")
            else listOf("1","2","3","4","5","6","7","8","9","0")
            addKeyRow(root, numberRow, 40)

            if (language == Language.ARABIC) {
                addKeyRow(root, listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج","د"), 44)
                addKeyRow(root, listOf("ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط"), 44, insetWeight = 0.35f)
                addLetterRowWithSides(root, listOf("ئ","ء","ؤ","ر","لا","ى","ة","و","ز","ظ"), arabic = true)
            } else {
                addKeyRow(root, listOf("q","w","e","r","t","y","u","i","o","p"), 44)
                addKeyRow(root, listOf("a","s","d","f","g","h","j","k","l"), 44, insetWeight = 0.45f)
                addLetterRowWithSides(root, listOf("z","x","c","v","b","n","m"), arabic = false)
            }
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        controls.addView(key(if (symbolsMode) "ABC" else "?123", true, 13f) {
            symbolsMode = !symbolsMode; shifted = false; refreshKeyboard()
        }, controlParams(1.05f))
        controls.addView(key(if (language == Language.ARABIC) "EN" else "ع", true, 14f) {
            language = if (language == Language.ARABIC) Language.ENGLISH else Language.ARABIC
            symbolsMode = false; shifted = false; refreshKeyboard()
        }, controlParams(0.8f))
        controls.addView(key("🌐", true, 18f) {
            // Switch to the next installed keyboard (for example, the user's previous keyboard).
            // If Android has no next IME to switch to, open its system keyboard picker.
            val switched = try { switchToNextInputMethod(false) } catch (_: Exception) { false }
            if (!switched) {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showInputMethodPicker()
            }
        }, controlParams(0.8f))
        controls.addView(key(if (language == Language.ARABIC) "،" else ",", false, 17f) {
            currentInputConnection?.commitText(if (language == Language.ARABIC) "،" else ",", 1)
        }, controlParams(0.7f))
        controls.addView(key("مسافة", false, 11f) { currentInputConnection?.commitText(" ", 1) }, controlParams(2.5f))
        controls.addView(key(".", false, 17f) { currentInputConnection?.commitText(".", 1) }, controlParams(0.7f))
        controls.addView(key("↵", true, 17f) { sendEnter() }, controlParams(0.85f))
        root.addView(controls, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(3) })
        return root
    }

    private fun addKeyRow(root: LinearLayout, labels: List<String>, height: Int, insetWeight: Float = 0f) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = if (language == Language.ARABIC && !symbolsMode) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        if (insetWeight > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, 1, insetWeight))
        labels.forEach { label ->
            row.addView(key(label, false, if (label.length > 1) 15f else 18f) { commitCharacter(label) },
                LinearLayout.LayoutParams(0, dp(height - 5), 1f).apply { setMargins(dp(1), dp(2), dp(1), dp(2)) })
        }
        if (insetWeight > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, 1, insetWeight))
        root.addView(row, LinearLayout.LayoutParams(-1, dp(height)))
    }

    private fun addLetterRowWithSides(root: LinearLayout, letters: List<String>, arabic: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = if (arabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        row.addView(key("⇧", true, 19f) { shifted = !shifted; refreshKeyboard() },
            LinearLayout.LayoutParams(0, dp(39), 1.25f).apply { setMargins(dp(1), dp(2), dp(1), dp(2)) })
        letters.forEach { label ->
            val shown = if (!arabic && shifted) label.uppercase() else label
            row.addView(key(shown, false, if (label.length > 1) 14f else 18f) { commitCharacter(shown) },
                LinearLayout.LayoutParams(0, dp(39), 1f).apply { setMargins(dp(1), dp(2), dp(1), dp(2)) })
        }
        row.addView(key("⌫", true, 19f) { currentInputConnection?.deleteSurroundingText(1, 0) },
            LinearLayout.LayoutParams(0, dp(39), 1.25f).apply { setMargins(dp(1), dp(2), dp(1), dp(2)) })
        root.addView(row, LinearLayout.LayoutParams(-1, dp(43)))
    }

    private fun commitCharacter(value: String) {
        currentInputConnection?.commitText(value, 1)
        if (language == Language.ENGLISH && shifted) { shifted = false; refreshKeyboard() }
    }

    private fun sendEnter() {
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun key(label: String, accent: Boolean, size: Float, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(if (accent) Color.WHITE else ink)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        gravity = Gravity.CENTER
        includeFontPadding = false
        minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        elevation = dp(if (accent) 1 else 2).toFloat()
        val base = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (accent) purple else Color.WHITE)
            if (!accent) setStroke(dp(1), Color.rgb(235, 229, 240))
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (accent) purpleDark else Color.rgb(232, 222, 241))
        }
        background = RippleDrawable(ColorStateList.valueOf(Color.rgb(210, 190, 224)), base, pressed)
        setOnClickListener { action() }
    }

    private fun controlParams(weight: Float) = LinearLayout.LayoutParams(0, dp(43), weight).apply {
        setMargins(dp(1), dp(1), dp(1), dp(1))
    }

    private fun refreshKeyboard() {
        val old = keyboardRoot ?: return
        val parent = old.parent as? ViewGroup ?: return
        val index = parent.indexOfChild(old)
        val params = old.layoutParams
        parent.removeView(old)
        val replacement = buildKeyboard().also { keyboardRoot = it }
        parent.addView(replacement, index, params)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
