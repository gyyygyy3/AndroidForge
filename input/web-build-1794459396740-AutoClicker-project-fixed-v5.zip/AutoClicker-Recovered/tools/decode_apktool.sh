#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v apktool >/dev/null || { echo "APKTool is required. Install it from https://apktool.org/" >&2; exit 2; }
mkdir -p "$ROOT/decompiled"
if [[ -f "$ROOT/original/original.apk" ]]; then
  INPUT_APK="$ROOT/original/original.apk"
else
  INPUT_APK="$ROOT/build/recovered-unpacked.apk"
  python3 "$ROOT/tools/package_extracted_apk.py" --input-dir "$ROOT/extracted_apk" --output "$INPUT_APK"
fi
apktool d -f "$INPUT_APK" -o "$ROOT/decompiled/apktool"
echo "APKTool output: $ROOT/decompiled/apktool"
