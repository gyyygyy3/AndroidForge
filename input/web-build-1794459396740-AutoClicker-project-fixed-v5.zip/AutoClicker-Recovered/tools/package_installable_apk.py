#!/usr/bin/env python3
"""Patch a recovered binary AndroidManifest, package, align, and debug-sign an APK.

This does not recompile Java/Kotlin source. It repackages the original compiled APK
entries and removes only the stale requiredSplitTypes manifest attribute that
would make this base-only recovery require a missing ABI split.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

ANDROID_NS = "http://schemas.android.com/apk/res/android"
TARGET_ATTR = "requiredSplitTypes"
REQUIRED = ("AndroidManifest.xml", "resources.arsc", "classes.dex")
PADDING_FIELD_ID = 0xD935


def _u16_len(data: bytes, offset: int) -> tuple[int, int]:
    value = struct.unpack_from("<H", data, offset)[0]
    if value & 0x8000:
        value = ((value & 0x7FFF) << 16) | struct.unpack_from("<H", data, offset + 2)[0]
        return value, offset + 4
    return value, offset + 2


def _u8_len(data: bytes, offset: int) -> tuple[int, int]:
    first = data[offset]
    if first & 0x80:
        return ((first & 0x7F) << 8) | data[offset + 1], offset + 2
    return first, offset + 1


def decode_string_pool(axml: bytes, chunk_offset: int) -> list[str]:
    chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", axml, chunk_offset)
    if chunk_type != 0x0001 or chunk_size < header_size:
        raise ValueError("Invalid Android binary XML string pool")
    string_count, style_count, flags, strings_start, _styles_start = struct.unpack_from(
        "<IIIII", axml, chunk_offset + 8
    )
    if string_count > 100_000 or chunk_offset + chunk_size > len(axml):
        raise ValueError("Unreasonable Android XML string-pool size")
    offsets_start = chunk_offset + header_size
    strings_base = chunk_offset + strings_start
    strings: list[str] = []
    is_utf8 = bool(flags & 0x100)
    for i in range(string_count):
        rel = struct.unpack_from("<I", axml, offsets_start + i * 4)[0]
        pos = strings_base + rel
        if is_utf8:
            _utf16_chars, pos = _u8_len(axml, pos)
            byte_len, pos = _u8_len(axml, pos)
            raw = axml[pos : pos + byte_len]
            strings.append(raw.decode("utf-8", "replace"))
        else:
            char_len, pos = _u16_len(axml, pos)
            raw = axml[pos : pos + char_len * 2]
            strings.append(raw.decode("utf-16le", "replace"))
    return strings


def patch_manifest_remove_required_split(axml: bytes) -> tuple[bytes, bool]:
    """Remove android:requiredSplitTypes from the top-level <manifest> tag."""
    if len(axml) < 8:
        raise ValueError("AndroidManifest.xml is truncated")
    file_type, file_header_size, file_size = struct.unpack_from("<HHI", axml, 0)
    if file_type != 0x0003 or file_header_size != 8 or file_size != len(axml):
        raise ValueError("AndroidManifest.xml is not a valid binary XML document")

    chunks: list[tuple[int, int, int]] = []
    pos = file_header_size
    while pos < len(axml):
        if pos + 8 > len(axml):
            raise ValueError("Truncated Android XML chunk header")
        kind, header_size, size = struct.unpack_from("<HHI", axml, pos)
        if size < header_size or pos + size > len(axml):
            raise ValueError("Invalid Android XML chunk size")
        chunks.append((kind, pos, size))
        pos += size
    if pos != len(axml):
        raise ValueError("Android XML chunks do not fill the document")

    pool_offsets = [p for t, p, _ in chunks if t == 0x0001]
    if not pool_offsets:
        raise ValueError("Android XML string pool is missing")
    strings = decode_string_pool(axml, pool_offsets[0])
    try:
        manifest_name_index = strings.index("manifest")
        attr_name_index = strings.index(TARGET_ATTR)
        android_ns_index = strings.index(ANDROID_NS)
    except ValueError:
        return axml, False

    for kind, chunk_pos, chunk_size in chunks:
        if kind != 0x0102:  # RES_XML_START_ELEMENT_TYPE
            continue
        if chunk_pos + 36 > len(axml):
            continue
        _line, _comment, ns_idx, name_idx = struct.unpack_from("<IIII", axml, chunk_pos + 8)
        if name_idx != manifest_name_index or ns_idx != 0xFFFFFFFF:
            continue
        attr_start, attr_size, attr_count = struct.unpack_from("<HHH", axml, chunk_pos + 24)
        if attr_size < 20 or attr_count > 1000:
            raise ValueError("Unexpected manifest attribute layout")
        attrs_offset = chunk_pos + 16 + attr_start
        remove_at = None
        for index in range(attr_count):
            attr_offset = attrs_offset + index * attr_size
            attr_ns, attr_name = struct.unpack_from("<II", axml, attr_offset)
            if attr_name == attr_name_index and attr_ns == android_ns_index:
                remove_at = attr_offset
                break
        if remove_at is None:
            return axml, False
        # Preserve any bytes beyond the first 20 bytes of an attribute, should
        # the file use a future extended attribute size.
        attr_size_bytes = attr_size
        patched = bytearray(axml[:remove_at] + axml[remove_at + attr_size_bytes :])
        struct.pack_into("<H", patched, chunk_pos + 28, attr_count - 1)
        struct.pack_into("<I", patched, chunk_pos + 4, chunk_size - attr_size_bytes)
        struct.pack_into("<I", patched, 4, len(patched))
        return bytes(patched), True
    return axml, False


def aligned_extra(current_offset: int, filename: str) -> bytes:
    """Return a valid ZIP extra field that aligns file data to a 4-byte boundary."""
    try:
        encoded_name = filename.encode("ascii")
    except UnicodeEncodeError:
        encoded_name = filename.encode("utf-8")
    data_start_without_extra = current_offset + 30 + len(encoded_name)
    padding_data_len = (-(data_start_without_extra + 4)) % 4
    # A zero-length extra field still occupies its 4-byte header; use no field
    # when that header itself is unnecessary.
    if padding_data_len == 0 and data_start_without_extra % 4 == 0:
        return b""
    return struct.pack("<HH", PADDING_FIELD_ID, padding_data_len) + (b"\0" * padding_data_len)


def write_aligned_stored_zip(source_entries: list[tuple[str, bytes]], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", allowZip64=True) as archive:
        for name, data in source_entries:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = (0o100644 & 0xFFFF) << 16
            info.extra = aligned_extra(archive.fp.tell(), name)
            archive.writestr(info, data)
    verify_aligned_zip(output)


def verify_aligned_zip(path: Path) -> None:
    with zipfile.ZipFile(path, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f"ZIP integrity check failed at {bad}")
        for info in archive.infolist():
            # Only uncompressed APK payloads require 4-byte alignment.
            # apksigner may add compressed META-INF/*.SF and *.RSA v1
            # signature records whose data offsets are not 4-byte aligned.
            if info.compress_type != zipfile.ZIP_STORED:
                continue
            with path.open("rb") as fh:
                fh.seek(info.header_offset)
                header = fh.read(30)
                if len(header) != 30 or header[:4] != b"PK\x03\x04":
                    raise ValueError(f"Invalid local ZIP header for {info.filename}")
                name_len, extra_len = struct.unpack_from("<HH", header, 26)
                data_offset = info.header_offset + 30 + name_len + extra_len
                if data_offset % 4:
                    raise ValueError(f"Uncompressed APK entry is not 4-byte aligned: {info.filename}")


def run_checked(command: list[str]) -> None:
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}")


def find_jdk_tool(tool: str) -> str:
    found = shutil.which(tool)
    if found:
        return found
    java_home = os.environ.get("JAVA_HOME")
    if java_home:
        candidate = Path(java_home) / "bin" / tool
        if candidate.is_file():
            return str(candidate)
        candidate_exe = candidate.with_suffix(".exe")
        if candidate_exe.is_file():
            return str(candidate_exe)
    raise FileNotFoundError(f"Cannot find JDK tool: {tool}")


def find_apksigner() -> str:
    found = shutil.which("apksigner")
    if found:
        return found
    for root in (os.environ.get("ANDROID_SDK_ROOT"), os.environ.get("ANDROID_HOME")):
        if root:
            folder = Path(root) / "build-tools"
            if folder.is_dir():
                for candidate in sorted(folder.glob("*/apksigner"), reverse=True):
                    if candidate.is_file():
                        return str(candidate)
    raise FileNotFoundError(
        "Android SDK apksigner is required. Install Android SDK Build-Tools "
        "and expose apksigner through PATH, ANDROID_SDK_ROOT, or ANDROID_HOME."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--keystore", type=Path, required=True)
    parser.add_argument("--storepass", default="recovered-debug-store")
    parser.add_argument("--alias", default="recovered-debug")
    args = parser.parse_args()

    source = args.input_dir.resolve()
    output = args.output.resolve()
    keystore = args.keystore.resolve()
    if not source.is_dir():
        parser.error(f"Input directory does not exist: {source}")
    for entry in REQUIRED:
        if not (source / entry).is_file():
            parser.error(f"Missing required APK entry: {entry}")

    keytool = find_jdk_tool("keytool")
    apksigner = find_apksigner()
    keystore.parent.mkdir(parents=True, exist_ok=True)
    if not keystore.exists():
        run_checked([
            keytool, "-genkeypair", "-noprompt", "-keystore", str(keystore),
            "-storetype", "PKCS12", "-storepass", args.storepass,
            "-alias", args.alias,
            "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
            "-dname", "CN=Recovered Debug APK, OU=Local Build, O=Local, C=US",
        ])

    # Read the archive entries and patch only the compiled manifest bytes.
    entries: list[tuple[str, bytes]] = []
    patched_split_requirement = False
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        name = path.relative_to(source).as_posix()
        upper = name.upper()
        # Old APK signature records must not be copied into the new package.
        if upper.startswith("META-INF/") and upper.endswith((".SF", ".RSA", ".DSA", ".EC")):
            continue
        data = path.read_bytes()
        if name == "AndroidManifest.xml":
            data, patched_split_requirement = patch_manifest_remove_required_split(data)
        entries.append((name, data))

    if not any(name == "AndroidManifest.xml" for name, _ in entries):
        raise ValueError("AndroidManifest.xml was not included")

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="recovered-apk-") as temp_dir:
        temp_dir_path = Path(temp_dir)
        unsigned = temp_dir_path / "unsigned-aligned.apk"
        write_aligned_stored_zip(entries, unsigned)

        # Sign using modern Android APK signature schemes.
        # Do not rewrite the APK after apksigner inserts its v2/v3 signing block.
        run_checked([
            apksigner, "sign",
            "--ks", str(keystore),
            "--ks-key-alias", args.alias,
            "--ks-pass", f"pass:{args.storepass}",
            "--key-pass", f"pass:{args.storepass}",
            "--min-sdk-version", "26",
            "--v1-signing-enabled", "true",
            "--v2-signing-enabled", "true",
            "--v3-signing-enabled", "true",
            "--out", str(output),
            str(unsigned),
        ])
        run_checked([apksigner, "verify", "--verbose", "--print-certs", str(output)])
        verify_aligned_zip(output)

    with zipfile.ZipFile(output, "r") as apk:
        missing = [name for name in REQUIRED if name not in apk.namelist()]
        if missing:
            raise ValueError("Final APK missing required entries: " + ", ".join(missing))
        manifest = apk.read("AndroidManifest.xml")
        _, was_still_required = patch_manifest_remove_required_split(manifest)
        if was_still_required:
            raise ValueError("Final APK still contains requiredSplitTypes")
        # Ensure the patched manifest still decodes as a structurally valid AXML.
        struct.unpack_from("<HHI", manifest, 0)

    print(f"Created signed and 4-byte-aligned APK: {output}")
    print(f"Removed requiredSplitTypes: {'yes' if patched_split_requirement else 'not present'}")
    print(f"Entries: {len(entries)} original payload entries + signing metadata")
    print("Signature: APK Signature Scheme v1 + v2 + v3 (local debug key; not the original developer certificate)")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
