#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v jadx >/dev/null || { echo "JADX is required. Install it from https://github.com/skylot/jadx/releases" >&2; exit 2; }
mkdir -p "$ROOT/decompiled/jadx"
if [[ -f "$ROOT/original/original.apk" ]]; then
  jadx --show-bad-code -d "$ROOT/decompiled/jadx" "$ROOT/original/original.apk"
else
  mapfile -t DEX_FILES < <(find "$ROOT/extracted_apk" -type f -name '*.dex' -print | sort)
  if [[ ${#DEX_FILES[@]} -eq 0 ]]; then
    echo "No APK or DEX files found. Restore original/original.apk or extracted_apk/*.dex." >&2
    exit 3
  fi
  jadx --show-bad-code -d "$ROOT/decompiled/jadx" "${DEX_FILES[@]}"
fi
echo "JADX output: $ROOT/decompiled/jadx"
