#!/usr/bin/env python3
"""Repackage the extracted APK entries into an unsigned APK-shaped ZIP."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import zipfile

REQUIRED = ("AndroidManifest.xml", "resources.arsc", "classes.dex")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source = args.input_dir.resolve()
    output = args.output.resolve()
    if not source.is_dir():
        parser.error(f"Input directory does not exist: {source}")

    missing = [name for name in REQUIRED if not (source / name).is_file()]
    if missing:
        parser.error("Missing required APK entries: " + ", ".join(missing))

    output.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    try:
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED) as apk:
            for path in sorted(source.rglob("*")):
                if not path.is_file():
                    continue
                relative = path.relative_to(source).as_posix()
                # The extracted directory contains no original JAR signature,
                # but omit any stale signature files if added later.
                upper = relative.upper()
                if upper.startswith("META-INF/") and upper.endswith((".SF", ".RSA", ".DSA", ".EC")):
                    continue
                info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_STORED
                info.external_attr = (0o100644 & 0xFFFF) << 16
                apk.writestr(info, path.read_bytes())
                count += 1
    except (OSError, zipfile.BadZipFile) as exc:
        print(f"Unable to create APK archive: {exc}", file=sys.stderr)
        return 1

    with zipfile.ZipFile(output, "r") as check:
        bad = check.testzip()
        if bad:
            print(f"Archive verification failed at entry: {bad}", file=sys.stderr)
            return 1
        missing_after = [name for name in REQUIRED if check.getinfo(name) is None]

    if missing_after:
        print("Archive verification failed: " + ", ".join(missing_after), file=sys.stderr)
        return 1
    print(f"Created {output} with {count} entries (unsigned; not yet zip-aligned).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
