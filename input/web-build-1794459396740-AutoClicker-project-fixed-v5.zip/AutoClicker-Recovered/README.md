Recovered APK payload and Gradle packaging workspace. See README_AR.md for build, signing, installation, and recovery limitations.
