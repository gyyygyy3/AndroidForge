package com.example.autoclickersimple

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var clickCount = 0L
    private var targetSizeDp = 112
    private var targetLabel = "ابدأ"
    private var targetXFraction = 0.5f
    private var targetYFraction = 0.5f
    private var dragged = false

    private lateinit var avatar: ImageView
    private lateinit var status: TextView
    private lateinit var target: TextView
    private lateinit var count: TextView
    private lateinit var workspace: FrameLayout
    private lateinit var sizeLabel: TextView

    private val prefs by lazy { getSharedPreferences("autoclicker_settings", MODE_PRIVATE) }

    private val clickTask = object : Runnable {
        override fun run() {
            if (!running) return
            performInAppClick()
            handler.postDelayed(this, CLICK_INTERVAL_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        targetSizeDp = prefs.getInt("target_size", 112).coerceIn(76, 160)
        targetLabel = prefs.getString("target_label", "ابدأ") ?: "ابدأ"
        targetXFraction = prefs.getFloat("target_x", 0.5f).coerceIn(0f, 1f)
        targetYFraction = prefs.getFloat("target_y", 0.5f).coerceIn(0f, 1f)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(Color.rgb(246, 248, 252))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        avatar = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(225, 232, 243), 27)
            clipToOutline = true
            setImageResource(android.R.drawable.ic_menu_camera)
            contentDescription = "اختيار صورة الملف الشخصي"
            setOnClickListener { chooseProfilePhoto() }
        }
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        heading.addView(text("النقر التلقائي", 21, Color.rgb(24, 34, 54), true))
        heading.addView(text("لوحة التحكم", 13, Color.rgb(111, 122, 143)))
        header.addView(avatar)
        header.addView(heading)
        root.addView(header)

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, 16)
            elevation = dp(2).toFloat()
        }
        val statusDot = View(this).apply {
            tag = "status_dot"
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10))
            background = rounded(Color.rgb(220, 75, 75), 10)
        }
        status = text("متوقف", 15, Color.rgb(65, 75, 95), true)
        status.setPadding(dp(9), 0, 0, 0)
        statusCard.addView(statusDot)
        statusCard.addView(status)
        val spacer = View(this)
        statusCard.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        statusCard.addView(text("الفاصل: 100 ms", 12, Color.rgb(110, 120, 140)))
        val statusParams = LinearLayout.LayoutParams(-1, -2)
        statusParams.topMargin = dp(20)
        root.addView(statusCard, statusParams)

        root.addView(text("منطقة الزر", 16, Color.rgb(34, 45, 67), true).apply {
            setPadding(2, dp(20), 0, dp(8))
        })
        workspace = FrameLayout(this).apply {
            background = rounded(Color.rgb(232, 238, 248), 20)
            clipChildren = true
            clipToPadding = true
        }
        val workspaceParams = LinearLayout.LayoutParams(-1, 0, 1f)
        workspaceParams.bottomMargin = dp(14)
        root.addView(workspace, workspaceParams)

        target = TextView(this).apply {
            gravity = Gravity.CENTER
            text = targetLabel
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(35, 91, 220), 100)
            elevation = dp(8).toFloat()
            isClickable = true
            isFocusable = true
        }
        workspace.addView(target, FrameLayout.LayoutParams(dp(targetSizeDp), dp(targetSizeDp)))
        target.setOnTouchListener { view, event -> handleTargetTouch(view, event) }

        workspace.post { placeTarget(targetXFraction, targetYFraction) }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 18)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            elevation = dp(2).toFloat()
        }
        controls.addView(text("تخصيص الزر", 15, Color.rgb(34, 45, 67), true))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val editButton = smallButton("تغيير النص") { editTargetLabel() }
        val minusButton = smallButton("−") { resizeTarget(-8) }
        val plusButton = smallButton("+") { resizeTarget(8) }
        row.addView(editButton, weightedParams())
        row.addView(minusButton, weightedParams(dp(6)))
        row.addView(plusButton, weightedParams(dp(6)))
        controls.addView(row)
        sizeLabel = text("حجم الزر: ${targetSizeDp} dp  •  اسحب الزر لتغيير موقعه", 12, Color.rgb(105, 116, 137))
        sizeLabel.setPadding(0, dp(9), 0, 0)
        controls.addView(sizeLabel)
        val reset = smallButton("إرجاع الزر إلى الوسط") {
            targetXFraction = 0.5f
            targetYFraction = 0.5f
            placeTarget(0.5f, 0.5f)
            saveSettings()
        }
        val resetParams = LinearLayout.LayoutParams(-1, dp(42))
        resetParams.topMargin = dp(8)
        controls.addView(reset, resetParams)
        root.addView(controls)

        count = text("عدد النقرات: 0", 15, Color.rgb(55, 67, 90), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(count)
        val note = text("اسحب الدائرة لتحديد مكانها، واضغط عليها للتشغيل أو الإيقاف.\nالنقر التلقائي يعمل داخل هذه الشاشة فقط.", 11, Color.rgb(125, 134, 151))
        note.gravity = Gravity.CENTER
        root.addView(note)

        setContentView(root)
        prefs.getString("photo_uri", null)?.let {
            try { avatar.setImageURI(Uri.parse(it)) } catch (_: Exception) { }
        }
    }

    private fun handleTargetTouch(view: View, event: MotionEvent): Boolean {
        val params = view.layoutParams as FrameLayout.LayoutParams
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragged = false
                view.tag = floatArrayOf(event.rawX - params.leftMargin, event.rawY - params.topMargin)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val origin = view.tag as? FloatArray ?: return true
                val dx = event.rawX - origin[0] - params.leftMargin
                val dy = event.rawY - origin[1] - params.topMargin
                if (kotlin.math.abs(dx) > dp(4) || kotlin.math.abs(dy) > dp(4)) dragged = true
                if (dragged) {
                    val newLeft = (event.rawX - origin[0]).toInt()
                    val newTop = (event.rawY - origin[1]).toInt()
                    params.leftMargin = newLeft.coerceIn(0, max(0, workspace.width - view.width))
                    params.topMargin = newTop.coerceIn(0, max(0, workspace.height - view.height))
                    params.gravity = Gravity.TOP or Gravity.LEFT
                    view.layoutParams = params
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragged) {
                    val maxX = max(1, workspace.width - view.width)
                    val maxY = max(1, workspace.height - view.height)
                    targetXFraction = params.leftMargin.toFloat() / maxX
                    targetYFraction = params.topMargin.toFloat() / maxY
                    saveSettings()
                } else {
                    toggle()
                }
                view.performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    private fun placeTarget(xFraction: Float, yFraction: Float) {
        if (!::workspace.isInitialized || !::target.isInitialized || workspace.width == 0) return
        val params = target.layoutParams as FrameLayout.LayoutParams
        params.width = dp(targetSizeDp)
        params.height = dp(targetSizeDp)
        params.gravity = Gravity.TOP or Gravity.LEFT
        params.leftMargin = (xFraction.coerceIn(0f, 1f) * max(0, workspace.width - params.width)).toInt()
        params.topMargin = (yFraction.coerceIn(0f, 1f) * max(0, workspace.height - params.height)).toInt()
        target.layoutParams = params
    }

    private fun resizeTarget(delta: Int) {
        targetSizeDp = (targetSizeDp + delta).coerceIn(76, 160)
        target.layoutParams = (target.layoutParams as FrameLayout.LayoutParams).apply {
            width = dp(targetSizeDp); height = dp(targetSizeDp)
        }
        placeTarget(targetXFraction, targetYFraction)
        sizeLabel.text = "حجم الزر: ${targetSizeDp} dp  •  اسحب الزر لتغيير موقعه"
        saveSettings()
    }

    private fun editTargetLabel() {
        val field = EditText(this).apply {
            setText(targetLabel)
            setSelection(text.length)
            hint = "اكتب النص الذي يظهر على الزر"
        }
        AlertDialog.Builder(this)
            .setTitle("تغيير نص الزر")
            .setView(field)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val value = field.text.toString().trim()
                if (value.isNotEmpty()) {
                    targetLabel = value.take(16)
                    if (!running) target.text = targetLabel
                    saveSettings()
                }
            }.show()
    }

    private fun toggle() {
        running = !running
        val dot = (status.parent as? LinearLayout)?.findViewWithTag<View>("status_dot")
        if (running) {
            clickCount = 0
            status.text = "يعمل الآن"
            status.setTextColor(Color.rgb(26, 145, 91))
            dot?.background = rounded(Color.rgb(32, 180, 112), 10)
            target.text = "إيقاف"
            target.background = rounded(Color.rgb(220, 65, 75), 100)
            count.text = "عدد النقرات: 0"
            handler.post(clickTask)
        } else {
            handler.removeCallbacks(clickTask)
            status.text = "متوقف"
            status.setTextColor(Color.rgb(65, 75, 95))
            dot?.background = rounded(Color.rgb(220, 75, 75), 10)
            target.text = targetLabel
            target.background = rounded(Color.rgb(35, 91, 220), 100)
        }
    }

    private fun performInAppClick() {
        clickCount++
        count.text = "عدد النقرات: $clickCount"
        // This is an app-local action counter, not an injected Android touch event.
    }

    private fun chooseProfilePhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(intent, REQUEST_PROFILE_PHOTO) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح معرض الصور", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Uses Android document picker for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PROFILE_PHOTO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val flags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
                contentResolver.takePersistableUriPermission(uri, flags)
                avatar.setImageURI(uri)
                prefs.edit().putString("photo_uri", uri.toString()).apply()
            } catch (_: Exception) {
                Toast.makeText(this, "لم نتمكن من حفظ الصورة المختارة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveSettings() {
        prefs.edit()
            .putInt("target_size", targetSizeDp)
            .putString("target_label", targetLabel)
            .putFloat("target_x", targetXFraction)
            .putFloat("target_y", targetYFraction)
            .apply()
    }

    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.rgb(39, 61, 101))
        background = rounded(Color.rgb(235, 241, 251), 12)
        setOnClickListener { action() }
    }

    private fun weightedParams(margin: Int = 0) = LinearLayout.LayoutParams(0, dp(42), 1f).apply {
        if (margin > 0) marginStart = margin
        marginEnd = dp(2)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(clickTask)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PROFILE_PHOTO = 2001
        private const val CLICK_INTERVAL_MS = 100L
    }
}
