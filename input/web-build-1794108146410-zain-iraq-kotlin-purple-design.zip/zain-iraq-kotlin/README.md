# Zain Iraq Native Android App

Native Android application built with Kotlin and Jetpack Compose. The user interface and application behavior are Kotlin-native; offer/service catalogue content is stored as bundled JSON data in `app/src/main/assets/content.json`.

Build with JDK 17, Android SDK 35 and Gradle 8.9+:

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

See `README-AR.md` for Arabic setup and feature notes.


## Purple visual refresh
The UI now uses a Zain-inspired purple / magenta gradient with aqua accents, a five-second branded splash screen, larger Arabic labels, improved contrast, and a matching launcher icon. The reward flow and catalog data remain in place. The independent-app disclaimer remains visible.
