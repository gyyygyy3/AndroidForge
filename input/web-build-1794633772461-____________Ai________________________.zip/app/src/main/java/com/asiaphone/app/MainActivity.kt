package com.asiaphone.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.animation.DecelerateInterpolator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.security.SecureRandom
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("asia_phone_prefs", Context.MODE_PRIVATE) }
    private var currentTab = 0
    private var selectedCategory: String? = null
    private var pendingUssdCode = ""
    private var pendingUssdShowDialer = true
    private var pendingTransferCode: String? = null
    private var pendingTransferAmount: Int? = null
    private var pendingTransferSubscriptionId = -1
    private var pendingAutomaticBalanceRequest = false
    // Process Asiacell SIMs sequentially; each SIM can run multiple balance/transfer cycles.
    private var automaticAsiacellSubscriptionIds = mutableListOf<Int>()
    private var automaticAsiacellSubscriptionLabels = mutableMapOf<Int, String>()
    private var automaticAsiacellSubscriptionIndex = 0
    private var automaticAsiacellCurrentSubscriptionId = -1
    private var automaticAsiacellCurrentStepFinished = false
    private var automaticAsiacellFlowInProgress = false
    private var automaticAsiacellHadLowBalance = false
    private var automaticAsiacellHadTransferAttempt = false
    // A SIM may make multiple transfers in one run; apply the cooldown only
    // before its first transfer, not between the transfers in the same batch.
    private val automaticAsiacellAttemptedThisRun = mutableSetOf<Int>()
    // Balance immediately before the last transfer; used to prevent repeat sends
    // when the carrier has not actually deducted the previous transfer amount.
    private var automaticAsiacellLastTransferBalance: Int? = null
    // Successful carrier confirmations are intentionally silent.
    private val automaticAsiacellTransferErrors = mutableListOf<String>()
    private val automaticAsiacellFlowResults = mutableListOf<String>()
    private var selectedSubscriptionId = -1
    private var balanceValueView: TextView? = null
    private var splashVisible = false
    private var splashFinishRunnable: Runnable? = null
    private val imageExecutor = Executors.newFixedThreadPool(3)

    private val dark: Boolean get() = prefs.getBoolean("dark_mode", false)
    private val pageBg: Int get() = if (dark) Color.rgb(18, 19, 24) else Color.rgb(247, 247, 250)
    private val cardBg: Int get() = if (dark) Color.rgb(32, 34, 42) else Color.WHITE
    private val textMain: Int get() = if (dark) Color.rgb(246, 246, 248) else Color.rgb(33, 35, 42)
    private val textMuted: Int get() = if (dark) Color.rgb(180, 183, 193) else Color.rgb(112, 116, 126)
    private val red: Int get() = Color.rgb(215, 25, 53)
    private val lineColor: Int get() = if (dark) Color.rgb(58, 60, 70) else Color.rgb(235, 236, 240)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(48, 20, 105)
        window.navigationBarColor = if (dark) Color.rgb(18, 19, 24) else Color.WHITE
        if (Build.VERSION.SDK_INT >= 26) window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        if (savedInstanceState == null) {
            // The only startup flow exposed to users is the branded intro followed
            // by the two-choice photo editor screen. Legacy pages are not rendered.
            showSplashScreen()
        } else {
            showFeatureChooser()
        }
    }

    private fun requestStartupPermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE)
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQ_STARTUP_PERMISSIONS)
        }
    }

    // Refresh the balance automatically when the app is opened or brought back
    // to the foreground. Android does not allow a normal app to poll USSD forever
    // while it is closed, so a five-minute foreground cooldown avoids repeated calls.
    override fun onResume() {
        super.onResume()
        // Do not surface legacy balance, notification, or promotional windows
        // while the app is displaying the new two-screen experience.
    }

    private fun scheduleStartupBalanceRefresh(delayMs: Long) {
        if (currentTab != 0 || splashVisible) return
        val lastAttempt = prefs.getLong("balance_last_attempt", 0L)
        if (System.currentTimeMillis() - lastAttempt < 5 * 60 * 1000L) return
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing && !splashVisible && currentTab == 0) requestBalanceAutomatically()
        }, delayMs)
    }

    /** Premium branded intro shown on each cold launch. */
    private fun showSplashScreen() {
        splashVisible = true
        val midnight = Color.rgb(7, 10, 30)
        window.statusBarColor = midnight
        window.navigationBarColor = midnight
        window.decorView.systemUiVisibility = 0

        val root = FrameLayout(this).apply {
            setBackgroundColor(midnight)
        }
        val backdrop = ImageView(this).apply {
            setImageResource(R.drawable.splash_ai_studio)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = null
        }
        root.addView(backdrop, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        val scrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(95, 5, 7, 26),
                    Color.argb(25, 8, 8, 28),
                    Color.argb(210, 5, 8, 27)
                )
            )
        }
        root.addView(scrim, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        addSplashRing(root, 250, Gravity.TOP or Gravity.START, -112, -92, 0.10f)
        addSplashRing(root, 210, Gravity.BOTTOM or Gravity.END, -82, -76, 0.08f)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(26), dp(24), dp(26), dp(24))
        }
        val studioTag = TextView(this).apply {
            text = "✦  AI CREATIVE STUDIO  ✦"
            textSize = 10f
            letterSpacing = 0.16f
            setTextColor(Color.rgb(218, 211, 255))
            gravity = Gravity.CENTER
            background = rounded(Color.argb(48, 255, 255, 255), 30, Color.argb(75, 255, 255, 255))
            setPadding(dp(17), dp(9), dp(17), dp(9))
        }
        content.addView(studioTag, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(24) })

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ai_photo_editor_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "أيقونة تعديل الصور بالذكاء الاصطناعي"
            adjustViewBounds = true
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(3), Color.argb(175, 208, 190, 255))
            }
            clipToOutline = true
            setPadding(dp(7), dp(7), dp(7), dp(7))
            elevation = dp(16).toFloat()
        }
        content.addView(logo, LinearLayout.LayoutParams(dp(142), dp(142)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(20)
        })

        val appName = TextView(this).apply {
            text = "تعديل الصور AI"
            textSize = 33f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.005f
        }
        content.addView(appName, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val tagline = TextView(this).apply {
            text = "استوديو إبداعي لصورك، بقوة الذكاء الاصطناعي"
            textSize = 14f
            setTextColor(Color.rgb(223, 225, 246))
            gravity = Gravity.CENTER
            maxLines = 2
        }
        content.addView(tagline, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val features = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        listOf("فيديو بالذكاء الاصطناعي", "ترميم الصور").forEachIndexed { index, value ->
            val chip = TextView(this).apply {
                text = value
                textSize = 11f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = rounded(Color.argb(55, 255, 255, 255), 24, Color.argb(75, 255, 255, 255))
                setPadding(dp(13), dp(8), dp(13), dp(8))
            }
            features.addView(chip, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                if (index == 0) marginEnd = dp(8)
            })
        }
        content.addView(features, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(22) })

        val loading = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(205, 190, 255))
            alpha = 0.95f
        }
        content.addView(loading, LinearLayout.LayoutParams(dp(112), dp(3)).apply {
            topMargin = dp(34)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        val loadingLabel = TextView(this).apply {
            text = "نجهّز لك مساحة الإبداع..."
            textSize = 11f
            setTextColor(Color.rgb(206, 210, 234))
            gravity = Gravity.CENTER
        }
        content.addView(loadingLabel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(11) })

        root.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))
        val footer = TextView(this).apply {
            text = "اصنع لحظاتك... بطريقتك"
            textSize = 10f
            setTextColor(Color.argb(190, 225, 224, 250))
            gravity = Gravity.CENTER
        }
        root.addView(footer, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = dp(8) })

        setContentView(root)
        content.alpha = 0f
        content.translationY = dp(16).toFloat()
        content.animate()
            .alpha(1f).translationY(0f)
            .setDuration(700L)
            .setInterpolator(DecelerateInterpolator())
            .start()

        val finish = Runnable {
            splashVisible = false
            if (!isFinishing && !isDestroyed) {
                window.statusBarColor = midnight
                window.navigationBarColor = midnight
                showFeatureChooser()
            }
            splashFinishRunnable = null
        }
        splashFinishRunnable = finish
        Handler(Looper.getMainLooper()).postDelayed(finish, 2_800L)
    }

    private fun addSplashRing(
        parent: FrameLayout,
        sizeDp: Int,
        gravity: Int,
        marginStartDp: Int,
        marginTopDp: Int,
        opacity: Float
    ) {
        val ring = View(this).apply {
            alpha = opacity
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.WHITE)
            }
        }
        parent.addView(ring, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), gravity).apply {
            if ((gravity and Gravity.END) == Gravity.END) rightMargin = dp(marginStartDp)
            else leftMargin = dp(marginStartDp)
            if ((gravity and Gravity.BOTTOM) == Gravity.BOTTOM) bottomMargin = dp(marginTopDp)
            else topMargin = dp(marginTopDp)
        })
    }

    override fun onDestroy() {
        splashFinishRunnable?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        splashFinishRunnable = null
        super.onDestroy()
    }

    private fun showKikaWelcomePopup() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        val poster = ImageView(this).apply {
            setImageResource(R.drawable.reward_kika_popup)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "يرجى تعبئة رصيدك للتمتع بـ3 كيكا مجاناً ورصيد 10,000 دينار للاتصال"
        }
        content.addView(poster, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)))
        val close = Button(this).apply {
            text = "حسناً"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(190, 12, 42), 12)
            setOnClickListener { }
        }
        content.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            topMargin = dp(8)
        })
        val dialog = AlertDialog.Builder(this)
            .setView(content)
            .create()
        close.setOnClickListener { dialog.dismiss() }
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }
    }

    private fun gradient(start: Int, end: Int, radius: Int = 22): GradientDrawable {
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun label(value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            includeFontPadding = true
        }
    }

    private fun bodyColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(14), dp(16), dp(28))
    }

    private fun addGap(parent: LinearLayout, height: Int = 12) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addText(parent: LinearLayout, value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false, top: Int = 0, bottom: Int = 0) {
        val v = label(value, size, color, bold)
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top); bottomMargin = dp(bottom)
        })
    }

    private fun pillButton(text: String, filled: Boolean = true, click: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (filled) Color.WHITE else red)
            background = rounded(if (filled) red else if (dark) Color.rgb(55, 31, 38) else Color.rgb(255, 239, 242), 12)
            setPadding(dp(15), dp(10), dp(15), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
    }


    /** The only post-intro screen: a premium AI studio with two visual tools. */
    private fun showFeatureChooser() {
        val midnight = Color.rgb(7, 10, 27)
        window.statusBarColor = midnight
        window.navigationBarColor = midnight
        window.decorView.systemUiVisibility = 0

        val screen = FrameLayout(this).apply {
            setBackgroundColor(midnight)
        }
        val glowTop = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.argb(75, 83, 48, 210), Color.TRANSPARENT)
            ).apply { shape = GradientDrawable.OVAL }
        }
        screen.addView(glowTop, FrameLayout.LayoutParams(dp(330), dp(330), Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(-155); topMargin = dp(-190)
        })
        val glowBottom = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.argb(52, 0, 170, 220), Color.TRANSPARENT)
            ).apply { shape = GradientDrawable.OVAL }
        }
        screen.addView(glowBottom, FrameLayout.LayoutParams(dp(290), dp(290), Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = dp(-165); bottomMargin = dp(-155)
        })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.TRANSPARENT)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(21), dp(18), dp(21), dp(22))
            setBackgroundColor(Color.TRANSPARENT)
        }
        scroll.addView(root, ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        screen.addView(scroll, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ai_photo_editor_icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(2), Color.argb(130, 193, 170, 255))
            }
            clipToOutline = true
            setPadding(dp(2), dp(2), dp(2), dp(2))
            elevation = dp(5).toFloat()
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(45), dp(45)))
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        brandText.addView(TextView(this).apply {
            text = "تعديل الصور AI"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        brandText.addView(TextView(this).apply {
            text = "AI PHOTO STUDIO"
            textSize = 9f
            letterSpacing = 0.15f
            setTextColor(Color.rgb(156, 168, 207))
        })
        brandRow.addView(brandText, LinearLayout.LayoutParams(0, dp(48), 1f))
        val statusPill = TextView(this).apply {
            text = "✦  AI"
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(Color.rgb(226, 218, 255))
            background = rounded(Color.argb(40, 164, 125, 255), 22, Color.argb(105, 175, 145, 255))
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(8), dp(13), dp(8))
        }
        brandRow.addView(statusPill, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(brandRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(50)
        ))

        val eyebrow = TextView(this).apply {
            text = "مساحة إبداعك الذكية"
            textSize = 11f
            letterSpacing = 0.04f
            setTextColor(Color.rgb(177, 157, 255))
            gravity = Gravity.CENTER
        }
        root.addView(eyebrow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(27) })

        val heading = TextView(this).apply {
            text = "ماذا تريد أن تبدع اليوم؟"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        root.addView(heading, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val subtitle = TextView(this).apply {
            text = "اختر أداتك، ودع الذكاء الاصطناعي يحوّل فكرتك إلى نتيجة مذهلة"
            textSize = 12.5f
            setTextColor(Color.rgb(170, 180, 211))
            gravity = Gravity.CENTER
            maxLines = 2
        }
        root.addView(subtitle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(9); bottomMargin = dp(21) })

        fun addChoiceCard(
            imageRes: Int,
            tag: String,
            title: String,
            description: String,
            accent: Int,
            heightDp: Int
        ) {
            val card = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(25).toFloat()
                    setColor(Color.rgb(24, 28, 53))
                    setStroke(dp(1), Color.argb(95, Color.red(accent), Color.green(accent), Color.blue(accent)))
                }
                clipToOutline = true
                elevation = dp(8).toFloat()
            }
            val artwork = ImageView(this).apply {
                setImageResource(imageRes)
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = title
            }
            card.addView(artwork, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            val shade = View(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(
                        Color.argb(20, 5, 8, 22),
                        Color.argb(38, 5, 8, 22),
                        Color.argb(225, 5, 9, 28)
                    )
                )
            }
            card.addView(shade, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(17), dp(14), dp(17), dp(15))
            }
            val tagPill = TextView(this).apply {
                text = "✦  $tag"
                textSize = 9f
                letterSpacing = 0.11f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = rounded(Color.argb(78, 14, 18, 44), 22, Color.argb(125, 255, 255, 255))
                setPadding(dp(11), dp(7), dp(11), dp(7))
            }
            content.addView(tagPill, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            content.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

            val bottomRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val copy = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
            }
            copy.addView(TextView(this).apply {
                text = title
                textSize = 21f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                includeFontPadding = false
            })
            copy.addView(TextView(this).apply {
                text = description
                textSize = 11.5f
                setTextColor(Color.rgb(225, 228, 245))
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                maxLines = 2
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
            bottomRow.addView(copy, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val arrow = TextView(this).apply {
                text = "←"
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)))
                    setStroke(dp(1), Color.argb(175, 255, 255, 255))
                }
                elevation = dp(3).toFloat()
            }
            bottomRow.addView(arrow, LinearLayout.LayoutParams(dp(42), dp(42)).apply {
                marginStart = dp(12)
            })
            content.addView(bottomRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            card.addView(content, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            root.addView(card, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp)
            ).apply { bottomMargin = dp(15) })
        }

        addChoiceCard(
            R.drawable.choice_photo_to_video,
            "AI MOTION STUDIO",
            "حوّل صورة إلى فيديو",
            "أضف الحركة والحياة إلى صورك الثابتة",
            Color.rgb(151, 105, 255),
            205
        )
        addChoiceCard(
            R.drawable.choice_photo_restore,
            "AI PHOTO RESTORE",
            "إصلاح وترميم الصور",
            "أعد الوضوح والألوان إلى صورك وذكرياتك",
            Color.rgb(54, 190, 225),
            205
        )

        val footer = TextView(this).apply {
            text = "✧  إبداعك يبدأ من صورة  ✧"
            textSize = 11f
            setTextColor(Color.rgb(150, 163, 197))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(7))
        }
        root.addView(footer, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(28)
        ))
        setContentView(screen)
        root.alpha = 0f
        root.translationY = dp(12).toFloat()
        root.animate().alpha(1f).translationY(0f).setDuration(420L)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun render() {
        // Keep legacy feature implementations in the project, but do not expose
        // their old navigation pages in the new photo-editor interface.
        balanceValueView = null
        showFeatureChooser()
    }

    private fun createHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(7), dp(16), dp(7))
            setBackgroundColor(if (dark) Color.rgb(27, 28, 35) else Color.WHITE)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ai_photo_editor_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "تعديل الصور Ai"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titles.addView(label("تعديل الصور Ai", 19f, textMain, true))
        titles.addView(label("AI PHOTO EDITOR  •  محرر صور ذكي", 9.5f, textMuted, false))
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sourceBtn = TextView(this).apply {
            text = "⋯"
            textSize = 26f
            setTextColor(textMain)
            gravity = Gravity.CENTER
            background = rounded(if (dark) Color.rgb(45, 46, 54) else Color.rgb(246, 246, 248), 14)
            setOnClickListener { currentTab = 4; render() }
        }
        header.addView(sourceBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
        return header
    }

    private fun createBottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cardBg)
            elevation = dp(10).toFloat()
        }
        val entries = listOf("⌂" to "الرئيسية", "▦" to "الباقات", "✦" to "الخدمات", "♡" to "المفضلة", "☰" to "المزيد", "🎁" to "المكافآت")
        entries.forEachIndexed { index, pair ->
            val active = currentTab == index
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, dp(5))
                setOnClickListener {
                    currentTab = index
                    selectedCategory = null
                    render()
                }
            }
            item.addView(TextView(this).apply {
                text = pair.first
                textSize = 21f
                setTextColor(if (active) red else textMuted)
                gravity = Gravity.CENTER
            })
            item.addView(TextView(this).apply {
                text = pair.second
                textSize = 10f
                setTypeface(typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (active) red else textMuted)
                gravity = Gravity.CENTER
            })
            nav.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        return nav
    }

    private fun sectionTitle(parent: LinearLayout, title: String, sub: String = "") {
        addText(parent, title, 19f, textMain, true, 7, 0)
        if (sub.isNotBlank()) addText(parent, sub, 12f, textMuted, false, 3, 8)
    }

    private fun addTextToBalanceCard(parent: LinearLayout, value: String, size: Float, color: Int) {
        val note = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.RIGHT
        }
        parent.addView(note, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
    }

    private fun renderHome(page: LinearLayout) {
        // Home screen is now a visual landing page for AI photo-to-video creation.
        // Existing navigation, services, and business logic remain untouched.
        addGap(page, 8)
        val intro = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(25), dp(20), dp(25))
            background = gradient(Color.rgb(36, 18, 83), Color.rgb(104, 42, 166), 26)
        }
        val eyebrow = label("إبداع بصري مدعوم بالذكاء الاصطناعي", 11f, Color.rgb(220, 202, 255), true).apply {
            gravity = Gravity.CENTER
        }
        intro.addView(eyebrow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val headline = label("حوّل صورك إلى فيديو ينبض بالحياة", 25f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setLineSpacing(dp(4).toFloat(), 1.02f)
        }
        intro.addView(headline, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(13) })
        val subtitle = label("من صورة واحدة تبدأ الحكاية… امنح لحظاتك الثابتة حركةً ومشهداً يستحق المشاهدة.", 14f, Color.rgb(239, 230, 255), false).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setLineSpacing(dp(3).toFloat(), 1.05f)
        }
        intro.addView(subtitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        page.addView(intro, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addGap(page, 22)
        addText(page, "من الخيال إلى الحركة", 20f, textMain, true)
        addText(page, "تجربة إبداعية تجعل صورك أكثر حيوية، بأسلوب بصري أنيق ولمسة ذكية.", 13f, textMuted, false, 5, 14)

        val steps = listOf(
            "01" to ("اختر صورتك" to "ابدأ بصورة تحمل ذكرى أو فكرة أو لحظة مميزة."),
            "02" to ("تخيّل المشهد" to "حوّل فكرتك إلى وصف واضح للحركة والأجواء التي تريدها."),
            "03" to ("شاهد قصتك تتحرك" to "استعد لتجربة بصرية تنقل صورتك من الثبات إلى الإحساس بالحركة.")
        )
        steps.forEach { (number, content) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(15), dp(15), dp(15), dp(15))
                background = rounded(cardBg, 18, if (dark) Color.rgb(66, 55, 88) else Color.rgb(232, 224, 246))
            }
            val numberView = TextView(this).apply {
                text = number
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = gradient(Color.rgb(117, 70, 206), Color.rgb(72, 133, 235), 14)
            }
            card.addView(numberView, LinearLayout.LayoutParams(dp(43), dp(43)))
            val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            copy.addView(label(content.first, 15f, textMain, true))
            copy.addView(label(content.second, 12f, textMuted, false).apply { setLineSpacing(dp(2).toFloat(), 1f) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
            card.addView(copy, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            page.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }

        addGap(page, 8)
        val closing = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(19), dp(18), dp(19))
            background = rounded(if (dark) Color.rgb(39, 31, 55) else Color.rgb(244, 239, 252), 20)
        }
        closing.addView(label("كل صورة تخفي مشهداً… أطلقه بالذكاء الاصطناعي", 15f, textMain, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        })
        closing.addView(label("تخيّل أكثر. أبدع بلا حدود.", 12f, textMuted, false).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        page.addView(closing, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addGap(page, 12)
    }

    private fun categoryCard(name: String, imageName: String, click: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18, lineColor)
            clipToOutline = true
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        val image = ImageView(this).apply { loadCampaignImage(this, imageName); scaleType = ImageView.ScaleType.CENTER_CROP }
        card.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(94)))
        card.addView(label(name, 13f, textMain, true).apply { setPadding(dp(10), dp(8), dp(10), dp(8)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(43)))
        return card
    }

    private fun quickServiceCard(title: String, sub: String, click: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 15, lineColor)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            isClickable = true
            setOnClickListener { click() }
            addView(label(title, 14f, red, true))
            addView(label(sub, 10f, textMuted, false).apply { maxLines = 2 }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
    }

    private fun renderPackages(page: LinearLayout) {
        sectionTitle(page, "الباقات والعروض", "جميع الباقات ظاهرة حسب الفئات — لا يوجد بحث")
        val horizontal = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val filters = listOf("الكل") + Catalog.categories
        filters.forEach { item ->
            val selected = (item == "الكل" && selectedCategory == null) || item == selectedCategory
            val chip = TextView(this).apply {
                text = item
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (selected) Color.WHITE else textMain)
                background = rounded(if (selected) red else cardBg, 18, if (selected) red else lineColor)
                setPadding(dp(15), dp(9), dp(15), dp(9))
                setOnClickListener { selectedCategory = if (item == "الكل") null else item; render() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6); bottomMargin = dp(10) })
        }
        horizontal.addView(chips)
        page.addView(horizontal)
        val list = if (selectedCategory == null) Catalog.offers else Catalog.offers.filter { it.category == selectedCategory }
        if (list.isEmpty()) {
            emptyState(page, "لا توجد باقات في هذا القسم حالياً", "يمكن فتح صفحة آسياسيل الرسمية للتأكد من آخر تحديث.")
        } else {
            addText(page, "${list.size} باقة ضمن القسم", 12f, textMuted, false, 2, 8)
            list.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(11) }) }
        }
        sourceFooter(page)
    }

    private fun offerCard(offer: Offer): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18, lineColor)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val image = ImageView(this).apply { loadCampaignImage(this, offer.image); scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(cardBg, 13); clipToOutline = true }
        main.addView(image, LinearLayout.LayoutParams(dp(94), dp(94)))
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        details.addView(label(offer.title, 14f, textMain, true))
        val priceText = offer.price?.let { "${formatNumber(it)} دينار" } ?: if (offer.category == "YOOZ") "حسب اختيارك" else "حسب نوع الخط"
        details.addView(label(priceText, 16f, red, true).apply { setPadding(0, dp(5), 0, dp(3)) })
        details.addView(label("⏱ ${offer.validity}", 11f, textMuted))
        val metrics = listOfNotNull(offer.data.takeIf { it.isNotBlank() }?.let { "إنترنت: $it" }, offer.voice.takeIf { it.isNotBlank() }?.let { "مكالمات: $it" }, offer.sms.takeIf { it.isNotBlank() }?.let { "رسائل: $it" }).joinToString("  •  ")
        if (metrics.isNotBlank()) details.addView(label(metrics, 10.5f, textMuted).apply { maxLines = 2 })
        main.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(main)
        if (offer.note.isNotBlank()) card.addView(label("ⓘ ${offer.note}", 10.5f, textMuted).apply { setPadding(dp(4), dp(9), dp(4), dp(2)); maxLines = 4 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(pillButton("تفاصيل", false) { showOfferDetails(offer) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
        actions.addView(pillButton("${offer.activation.label}  ›", true) { confirmOfferAction(offer) }, LinearLayout.LayoutParams(0, dp(40), 1.4f))
        val fav = if (isFavorite(offer.id)) "♥" else "♡"
        actions.addView(pillButton(fav, false) { toggleFavorite(offer.id); render() }, LinearLayout.LayoutParams(dp(48), dp(40)).apply { rightMargin = dp(5) })
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(11) })
        return card
    }

    private fun showOfferDetails(offer: Offer) {
        val msg = buildString {
            append(offer.title).append("\n\n")
            if (offer.price != null) append("السعر: ").append(formatNumber(offer.price)).append(" دينار عراقي\n")
            append("الصلاحية: ").append(offer.validity).append("\n")
            if (offer.data.isNotBlank()) append("الإنترنت: ").append(offer.data).append("\n")
            if (offer.voice.isNotBlank()) append("المكالمات: ").append(offer.voice).append("\n")
            if (offer.sms.isNotBlank()) append("الرسائل: ").append(offer.sms).append("\n")
            append("\n").append(offer.details)
            if (offer.note.isNotBlank()) append("\n\nتنبيه: ").append(offer.note)
            append("\n\nطريقة الاشتراك: ").append(offer.activation.label)
        }
        AlertDialog.Builder(this)
            .setTitle("تفاصيل الباقة")
            .setMessage(msg)
            .setPositiveButton("متابعة الاشتراك") { _, _ -> confirmOfferAction(offer) }
            .setNeutralButton("المصدر الرسمي") { _, _ -> openWeb(offer.source) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun confirmOfferAction(offer: Offer) {
        val price = offer.price?.let { "السعر: ${formatNumber(it)} دينار عراقي.\n" } ?: "السعر/الأهلية: تحقق من شاشة آسياسيل.\n"
        val message = price + "الصلاحية: ${offer.validity}.\n\n" +
            "سيتم فتح طلب الشبكة أو تجهيز رسالة الاشتراك. لن يرسل التطبيق رسالة SMS مدفوعة تلقائياً."
        AlertDialog.Builder(this)
            .setTitle("تأكيد طلب الباقة")
            .setMessage(message)
            .setPositiveButton("متابعة") { _, _ -> runActivation(offer.activation, offer.title) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderServices(page: LinearLayout) {
        sectionTitle(page, "خدمات آسياسيل", "اضغط على الخدمة لقراءة الشروط ثم تنفيذ الإجراء")
        val groups = Catalog.services.groupBy { it.category }
        groups.forEach { (group, items) ->
            addText(page, group, 16f, red, true, 14, 7)
            items.forEach { service ->
                page.addView(serviceCard(service), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(9) })
            }
        }
        sourceFooter(page)
    }

    private fun serviceCard(item: ServiceItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setOnClickListener { openService(item) }
            isClickable = true
            isFocusable = true
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        val icon = TextView(this).apply {
            text = serviceIcon(item.category)
            textSize = 21f
            gravity = Gravity.CENTER
            background = rounded(if (dark) Color.rgb(67, 34, 44) else Color.rgb(255, 239, 242), 13)
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        textBox.addView(label(item.title, 14f, textMain, true))
        textBox.addView(label(item.summary, 11f, textMuted, false).apply { maxLines = 2 })
        row.addView(textBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (isFavorite(item.id)) "♥" else "♡"
            textSize = 22f
            setTextColor(red)
            gravity = Gravity.CENTER
            setOnClickListener { toggleFavorite(item.id); render() }
        }, LinearLayout.LayoutParams(dp(38), dp(44)))
        row.addView(label("›", 23f, red, true))
        card.addView(row)
        card.addView(label("الكلفة: ${item.cost}", 10.5f, textMuted).apply { setPadding(dp(3), dp(8), dp(3), dp(2)); maxLines = 3 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(pillButton("التفاصيل", false) { showServiceDetails(item) }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(5) })
        actions.addView(pillButton(item.actionLabel, true) { activateService(item) }, LinearLayout.LayoutParams(0, dp(38), 1.4f))
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        return card
    }

    private fun openService(item: ServiceItem) {
        showServiceDetails(item)
    }

    private fun showServiceDetails(item: ServiceItem) {
        val fullText = buildString {
            append(item.title).append("\n\n").append(item.details)
            append("\n\nالكلفة: ").append(item.cost)
            if (item.warning.isNotBlank()) append("\n\nتنبيه: ").append(item.warning)
        }
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setMessage(fullText)
            .setPositiveButton(item.actionLabel) { _, _ -> activateService(item) }
            .setNeutralButton("المصدر الرسمي") { _, _ -> openWeb(item.source) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun activateService(item: ServiceItem) {
        when (item.id) {
            "transfer" -> { showTransferDialog(); return }
            "callme" -> { showCallMeDialog(); return }
            "validity" -> { showValidityDialog(); return }
            "call_ect" -> { showCallEctDialog(); return }
            "call_forward" -> { showCallForwardDialog(); return }
            "byebye" -> { showByeByeDialog(); return }
            "gift" -> { showGiftDialog(); return }
        }
        val paidRisk = item.cost.contains("دينار") && !item.cost.contains("مجاني")
        if (paidRisk) confirmServiceAction(item) else runActivation(item.activation, item.title)
    }

    private fun confirmServiceAction(item: ServiceItem) {
        AlertDialog.Builder(this)
            .setTitle("مراجعة الكلفة قبل المتابعة")
            .setMessage("${item.title}\n\n${item.cost}\n\n${item.warning}\n\nلن يرسل التطبيق رسالة مدفوعة أو يؤكد عملية مالية من دون موافقتك.")
            .setPositiveButton("أوافق، متابعة") { _, _ -> runActivation(item.activation, item.title) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderFavorites(page: LinearLayout) {
        sectionTitle(page, "المفضلة", "الباقات والخدمات التي حفظتها")
        val ids = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        val offerList = Catalog.offers.filter { ids.contains(it.id) }
        val serviceList = Catalog.services.filter { ids.contains(it.id) }
        if (offerList.isEmpty() && serviceList.isEmpty()) {
            emptyState(page, "قائمة المفضلة فارغة", "اضغط على رمز القلب في أي باقة لحفظها هنا.")
        } else {
            offerList.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
            serviceList.forEach { page.addView(serviceCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
        }
    }

    private fun renderMore(page: LinearLayout) {
        sectionTitle(page, "المزيد والإعدادات")
        val darkSwitchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        darkSwitchRow.addView(label("الوضع الليلي", 14f, textMain, true), LinearLayout.LayoutParams(0, dp(48), 1f))
        val sw = Switch(this).apply { isChecked = dark; setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("dark_mode", checked).apply(); render() } }
        darkSwitchRow.addView(sw)
        page.addView(darkSwitchRow)
        addGap(page)
        infoPanel(page, "فحص شريحة آسياسيل", "قبل فحص الرصيد أو تنفيذ تحويل الاشتراك، يفحص التطبيق جميع الشرائح النشطة ويعالج شرائح آسياسيل (41805/41800) فقط. إذا وجد شريحتي آسياسيل أو أكثر، يفحص رصيد كل شريحة وينفذ تحويلها بشكل متتالٍ، واحدة بعد الأخرى. لن ينفذ التحويل عبر زين أو كورك أو الشريحة الافتراضية الأخرى.")
        infoPanel(page, "مصادر العروض", "البيانات الحالية مجمعة من صفحات آسياسيل الرسمية. بعض العروض تتغير أو تظهر لأرقام محددة فقط؛ افتح المصدر الرسمي قبل الدفع إذا لم يظهر العرض على خطك.")
        page.addView(pillButton("فتح موقع آسياسيل الرسمي", true) { openWeb("https://www.asiacell.com/personal") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(10) })
        page.addView(pillButton("الأسئلة الشائعة والدعم", false) { openWeb("https://www.asiacell.com/personal/support/FAQ") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })
        addGap(page, 18)
        infoPanel(page, "حول تعديل الصور Ai", "تعديل الصور Ai تطبيق دليل مستقل لخدمات وباقات آسياسيل، وليس تطبيقاً رسمياً أو تابعاً لشركة آسياسيل. العلامات والأسماء التجارية تعود لأصحابها.")
        addText(page, "الإصدار 1.0.0  •  مراجعة بيانات الويب: 30 أكتوبر 2026", 10f, textMuted, false, 12, 0)
        sourceFooter(page)
    }

    private fun renderRewards(page: LinearLayout) {
        sectionTitle(page, "المكافآت والسحب", "تابع أرباحك واختر وسيلة السحب وشارك رمز الدعوة")

        // A display-only code is generated locally. No account, sign-in, or database is used.
        val myCode = localRewardCode()
        val balance = prefs.getLong("reward_display_balance", 0L)

        val earningsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(Color.rgb(222, 26, 55), Color.rgb(131, 0, 35), 20)
            setPadding(dp(17), dp(16), dp(17), dp(16))
        }
        earningsCard.addView(label("أرباحي", 14f, Color.rgb(255, 225, 230), true))
        earningsCard.addView(label("${String.format(java.util.Locale.US, "%,d", balance)} دينار عراقي", 27f, Color.WHITE, true).apply {
            setPadding(0, dp(7), 0, dp(2))
        })
        page.addView(earningsCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Withdrawal method is intentionally placed directly below earnings.
        addGap(page, 12)
        sectionTitle(page, "💳 وسيلة السحب")
        infoPanel(page, "السحب عبر Mastercard", "أدخل بيانات البطاقة ومبلغ السحب المطلوب. لا تدخل الرقم السري أو رمز الأمان CVV.")
        val cardholderInput = EditText(this).apply {
            hint = "اسم صاحب البطاقة كما هو مطبوع"
            textSize = 14f
            setSingleLine(true)
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(cardholderInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)))
        val cardNumberInput = EditText(this).apply {
            hint = "رقم Mastercard"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(cardNumberInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)).apply { topMargin = dp(8) })
        val amountInput = EditText(this).apply {
            hint = "مبلغ السحب بالدينار"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(amountInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)).apply { topMargin = dp(8) })
        page.addView(pillButton("إرسال طلب السحب", true) {
            val amount = amountInput.text.toString().toLongOrNull()
            val holder = cardholderInput.text.toString().trim()
            val cardNumber = normalizeDigits(cardNumberInput.text.toString()).filter { it.isDigit() }
            when {
                amount == null || amount <= 0L -> Toast.makeText(this, "أدخل مبلغ السحب", Toast.LENGTH_SHORT).show()
                holder.length < 3 -> Toast.makeText(this, "اكتب اسم صاحب البطاقة", Toast.LENGTH_SHORT).show()
                !isMastercardNumber(cardNumber) -> Toast.makeText(this, "تحقق من رقم Mastercard", Toast.LENGTH_SHORT).show()
                amount > balance -> Toast.makeText(this, "رصيدك المتاح لا يكفي لهذا السحب", Toast.LENGTH_LONG).show()
                else -> Toast.makeText(this, "خدمة تنفيذ طلبات السحب غير مفعّلة حالياً", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })

        addGap(page, 18)
        sectionTitle(page, "🪪 رمز الدعوة الخاص بي")
        val codePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        codePanel.addView(label("شارك رمز الدعوة الخاص بك مع الآخرين.", 11f, textMuted))
        codePanel.addView(label(myCode, 25f, red, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            textDirection = View.TEXT_DIRECTION_LTR
        })
        codePanel.addView(pillButton("نسخ الرمز", false) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("رمز الدعوة", myCode))
            Toast.makeText(this, "تم نسخ رمز الدعوة", Toast.LENGTH_SHORT).show()
        })
        page.addView(codePanel)

        addGap(page, 14)
        sectionTitle(page, "إدخال رمز الدعوة")
        val redeemInput = EditText(this).apply {
            hint = "أدخل رمز الدعوة"
            textSize = 14f
            setSingleLine(true)
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(redeemInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
        page.addView(pillButton("تأكيد الرمز", true) {
            if (redeemInput.text.toString().trim().isBlank()) {
                Toast.makeText(this, "أدخل رمز الدعوة أولاً", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "يتعذر التحقق من الرمز حالياً", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })

        addGap(page, 14)
        page.addView(pillButton("مشاركة رابط التطبيق", true) { shareAppOnly() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun localRewardCode(): String {
        val existing = prefs.getString("reward_display_code", null)
        if (!existing.isNullOrBlank()) return existing
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        val generated = buildString { repeat(6) { append(alphabet[random.nextInt(alphabet.length)]) } }
        prefs.edit().putString("reward_display_code", generated).apply()
        return generated
    }

    private fun isMastercardNumber(number: String): Boolean {
        if (number.length != 16) return false
        val prefix2 = number.take(2).toIntOrNull() ?: return false
        val prefix4 = number.take(4).toIntOrNull() ?: return false
        val mastercardBin = prefix2 in 51..55 || prefix4 in 2221..2720
        if (!mastercardBin) return false
        var sum = 0
        var doubleDigit = false
        for (index in number.length - 1 downTo 0) {
            var digit = number[index] - '0'
            if (doubleDigit) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
            doubleDigit = !doubleDigit
        }
        return sum % 10 == 0
    }

    private fun shareAppOnly() {
        val myCode = localRewardCode()
        val appLink = "https://asiaphone.netlify.app/"
        val shareText = buildString {
            append("جرّب تطبيق تعديل الصور Ai لخدمات آسياسيل:\n$appLink")
            if (myCode.isNotBlank()) append("\nرمز الدعوة: $myCode")
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        try {
            startActivity(Intent.createChooser(intent, "مشاركة تطبيق تعديل الصور Ai"))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذرت مشاركة التطبيق على هذا الهاتف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun infoPanel(parent: LinearLayout, title: String, text: String) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(cardBg, 16, lineColor); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        panel.addView(label(title, 14f, textMain, true))
        panel.addView(label(text, 11.5f, textMuted).apply { setPadding(0, dp(6), 0, 0) })
        parent.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(9) })
    }

    private fun emptyState(parent: LinearLayout, title: String, sub: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(cardBg, 20, lineColor); setPadding(dp(20), dp(28), dp(20), dp(28)) }
        box.addView(label("♡", 36f, red, true).apply { gravity = Gravity.CENTER })
        box.addView(label(title, 15f, textMain, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(4)) })
        box.addView(label(sub, 11f, textMuted).apply { gravity = Gravity.CENTER })
        parent.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun sourceFooter(parent: LinearLayout) {
        addGap(parent, 12)
        addText(parent, "ملاحظة: هذا الدليل لا ينفذ شراءً مدفوعاً بصمت. راجع السعر والشروط، وأكمل التأكيد في شاشة الشبكة أو الرسائل.", 10f, textMuted, false)
        addText(parent, "المصدر: صفحات آسياسيل الرسمية — الأسعار والأهلية قابلة للتغيير.", 10f, textMuted, false, 4, 0)
    }

    private fun serviceIcon(category: String): String = when (category) {
        "الرصيد والعروض" -> "💳"
        "التحويل والإهداء" -> "🎁"
        "إدارة الخط" -> "⚙"
        "المكالمات" -> "📞"
        "الحماية والترفيه" -> "🛡"
        "الخدمات الرقمية" -> "🌐"
        else -> "ⓘ"
    }

    private fun loadCampaignImage(view: ImageView, localName: String) {
        val fallback = drawableId(localName)
        if (fallback != 0) view.setImageResource(fallback)
        val remote = when (localName) {
            "banner_home", "banner_red" -> "https://www.asiacell.com/resources/images/asiacell/app-on-phone-new-en-26.png"
            "banner_free_social" -> "https://www.asiacell.com/resources/images/asiacell/crs-main-speed-mobile-ar.jpg"
            "banner_unlimited" -> "https://www.asiacell.com/resources/images/asiacell/crs-4g-news-unli-ar.jpg"
            "banner_max" -> "https://www.asiacell.com/resources/images/asiacell/crs_maxc_new_ar.png"
            "banner_yooz" -> "https://www.asiacell.com/resources/images/asiacell/crsd-omega-mgd-ar.png"
            "banner_roaming" -> "https://www.asiacell.com/resources/images/asiacell/crs_pass_ju_ar.png"
            "banner_elna" -> "https://www.asiacell.com/resources/images/asiacell/crs-gift-elna-en.jpg"
            else -> null
        } ?: return
        view.tag = remote
        val cacheFile = File(cacheDir, "campaign_${remote.hashCode()}.img")
        if (cacheFile.exists() && cacheFile.length() > 1000) {
            val cached = BitmapFactory.decodeFile(cacheFile.absolutePath)
            if (cached != null && view.tag == remote) { view.setImageBitmap(cached); return }
        }
        imageExecutor.execute {
            try {
                val connection = (URL(remote).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000; readTimeout = 7000; requestMethod = "GET";
                    setRequestProperty("User-Agent", "AsiaPhone/1.0 Android")
                }
                connection.inputStream.use { input -> cacheFile.outputStream().use { output -> input.copyTo(output) } }
                connection.disconnect()
                if (cacheFile.exists() && cacheFile.length() > 1000) {
                    val bitmap = BitmapFactory.decodeFile(cacheFile.absolutePath)
                    if (bitmap != null) runOnUiThread { if (view.tag == remote) view.setImageBitmap(bitmap) }
                }
            } catch (_: Exception) { /* local artwork remains as offline fallback */ }
        }
    }

    private fun drawableId(name: String): Int = resources.getIdentifier(name, "drawable", packageName)

    private fun formatNumber(number: Int): String = String.format("%,d", number)

    private fun isFavorite(id: String): Boolean = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).contains(id)

    private fun toggleFavorite(id: String) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (set.contains(id)) set.remove(id) else set.add(id)
        prefs.edit().putStringSet("favorites", set).apply()
        Toast.makeText(this, if (set.contains(id)) "أضيفت إلى المفضلة" else "حذفت من المفضلة", Toast.LENGTH_SHORT).show()
    }


    /** Execute a USSD request inside the app, asking for CALL_PHONE when needed. */
    private fun executeUssd(code: String, showDialerFallback: Boolean = false) {
        if (code.isBlank()) return
        pendingUssdCode = code
        pendingUssdShowDialer = showDialerFallback
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQ_USSD_PERMISSION)
            return
        }
        pendingUssdCode = ""
        chooseSimAndSend(code)
    }

    private fun runActivation(activation: Activation, title: String) {
        when (activation.mode) {
            ActionMode.USSD_BACKGROUND -> executeUssd(activation.code, true)
            // Interactive carrier menus must stay in the dialer; sendUssdRequest only
            // exposes a single response and cannot reliably continue multi-step menus.
            ActionMode.USSD_DIALER -> openDialer(activation.code)
            ActionMode.SMS_DRAFT -> openSmsComposer(activation.destination, activation.message)
            ActionMode.DIAL_NUMBER -> openDialer(activation.code)
            ActionMode.WEB -> openWeb(activation.url.ifBlank { "https://www.asiacell.com/personal/services" })
            ActionMode.SETTINGS -> {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "تعذر فتح إعدادات الهاتف", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun openWeb(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_LONG).show() }
    }

    private fun openDialer(code: String) {
        if (code.isBlank()) return
        try {
            val uri = Uri.fromParts("tel", code, null)
            startActivity(Intent(Intent.ACTION_DIAL, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSmsComposer(destination: String, message: String) {
        if (destination.isBlank()) {
            Toast.makeText(this, "رقم مركز الرسائل غير محدد", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$destination"))
            intent.putExtra("sms_body", message)
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "لا يوجد تطبيق رسائل متاح", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBalanceAutomatically(force: Boolean = false) {
        val lastAttempt = prefs.getLong("balance_last_attempt", 0L)
        if (!force && System.currentTimeMillis() - lastAttempt < 5 * 60 * 1000L) return
        prefs.edit().putLong("balance_last_attempt", System.currentTimeMillis()).apply()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            balanceValueView?.text = "يتطلب جلب الرصيد تلقائياً Android 8 أو أحدث."
            return
        }

        // This automatic subscription-payment feature must identify an Asiacell
        // SIM first. Never fall back to the phone's default SIM for this flow.
        pendingAutomaticBalanceRequest = true
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE)
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQ_USSD_PERMISSION)
            return
        }
        startAsiacellBalanceLookup()
    }

    /** Scan every active SIM and process every Asiacell line sequentially. */
    private fun startAsiacellBalanceLookup() {
        pendingAutomaticBalanceRequest = false
        if (automaticAsiacellFlowInProgress) return
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            showAsiacellSimBlocked("يلزم السماح للتطبيق بقراءة معلومات الشرائح حتى يحدد خطوط آسياسيل الصحيحة.")
            return
        }

        val asiacellSims = try {
            val subscriptionManager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            subscriptionManager.activeSubscriptionInfoList.orEmpty()
                .filter { isAsiacellSim(it) }
                .sortedBy { it.simSlotIndex }
        } catch (e: Exception) {
            showAsiacellSimBlocked("تعذر فحص الشرائح على هذا الهاتف. لم يتم إرسال أي طلب تحويل.\n${e.message ?: ""}")
            return
        }

        if (asiacellSims.isEmpty()) {
            balanceValueView?.text = "لم يتم العثور على شريحة آسياسيل نشطة."
            showAsiacellSimBlocked("لم يتم العثور على شريحة آسياسيل نشطة. تأكد من وجود شريحة آسياسيل ثم أعد المحاولة. لن يستخدم التطبيق شريحة زين أو كورك أو أي شريحة أخرى للتحويل.")
            return
        }

        automaticAsiacellSubscriptionIds = asiacellSims.map { it.subscriptionId }.toMutableList()
        automaticAsiacellSubscriptionLabels = asiacellSims.associate {
            it.subscriptionId to asiacellSimLabel(it)
        }.toMutableMap()
        automaticAsiacellSubscriptionIndex = 0
        automaticAsiacellCurrentSubscriptionId = -1
        automaticAsiacellCurrentStepFinished = false
        automaticAsiacellFlowInProgress = true
        automaticAsiacellHadLowBalance = false
        automaticAsiacellHadTransferAttempt = false
        automaticAsiacellAttemptedThisRun.clear()
        automaticAsiacellLastTransferBalance = null
        automaticAsiacellTransferErrors.clear()
        automaticAsiacellFlowResults.clear()

        // Migrate the previous app-wide cooldown safely. The older version stored
        // only one timestamp, so apply a still-active legacy cooldown to all
        // detected Asiacell SIMs once rather than risking a duplicate transfer
        // immediately after updating the app.
        if (!prefs.getBoolean("transfer_auto_per_sim_cooldown_migrated", false)) {
            val now = System.currentTimeMillis()
            val legacyLastAttempt = prefs.getLong("transfer_auto_last_attempt", 0L)
            if (legacyLastAttempt > 0L && now >= legacyLastAttempt &&
                now - legacyLastAttempt < 15 * 60 * 1000L) {
                val editor = prefs.edit()
                asiacellSims.forEach { sim ->
                    val key = "transfer_auto_last_attempt_${sim.subscriptionId}"
                    if (!prefs.contains(key)) editor.putLong(key, legacyLastAttempt)
                }
                editor.apply()
            }
            prefs.edit().putBoolean("transfer_auto_per_sim_cooldown_migrated", true).apply()
        }

        // Keep the automatic check/transfer flow silent; no informational toast.
        processNextAsiacellSubscription()
    }

    private fun isAsiacellSim(info: SubscriptionInfo): Boolean {
        val operatorCode = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val mcc = info.mccString.orEmpty()
                val mnc = info.mncString.orEmpty()
                if (mcc.isNotBlank() && mnc.isNotBlank()) mcc + mnc.padStart(2, '0') else ""
            } else {
                val mcc = info.mcc
                val mnc = info.mnc
                if (mcc > 0 && mnc >= 0) mcc.toString() + mnc.toString().padStart(2, '0') else ""
            }
        } catch (_: Exception) { "" }

        // Asiacell is identified by Iraq PLMN 41805. 41800 is also listed
        // for Asia Cell in operator registries; carrierName is a safe fallback
        // on devices that do not expose MCC/MNC in SubscriptionInfo.
        if (operatorCode == "41805" || operatorCode == "41800") return true
        val carrier = info.carrierName?.toString().orEmpty()
        return carrier.contains("asiacell", ignoreCase = true) ||
            carrier.contains("asia cell", ignoreCase = true) ||
            carrier.contains("آسياسيل") || carrier.contains("اسيا سيل")
    }

    private fun isActiveAsiacellSubscription(subscriptionId: Int): Boolean {
        if (subscriptionId < 0 || checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val manager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            manager.activeSubscriptionInfoList.orEmpty().any { it.subscriptionId == subscriptionId && isAsiacellSim(it) }
        } catch (_: Exception) { false }
    }

    private fun asiacellSimLabel(info: SubscriptionInfo): String {
        val slot = if (info.simSlotIndex >= 0) "الشريحة ${info.simSlotIndex + 1}" else "شريحة آسياسيل"
        return "$slot — آسياسيل"
    }

    private fun processNextAsiacellSubscription() {
        if (!automaticAsiacellFlowInProgress) return
        if (automaticAsiacellSubscriptionIndex >= automaticAsiacellSubscriptionIds.size) {
            finishAsiacellTransferFlow()
            return
        }

        val subscriptionId = automaticAsiacellSubscriptionIds[automaticAsiacellSubscriptionIndex]
        automaticAsiacellCurrentSubscriptionId = subscriptionId
        automaticAsiacellCurrentStepFinished = false
        val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"

        if (!isActiveAsiacellSubscription(subscriptionId)) {
            completeCurrentAsiacellStep("لم تعد الشريحة نشطة أو لم تعد مسجلة كآسياسيل؛ تم تخطيها دون تحويل.")
            return
        }

        balanceValueView?.text = "جارٍ فحص رصيد $label..."
        sendUssdNow("*133#", subscriptionId)
    }

    /** Record one SIM result, then wait briefly before starting the next SIM's USSD session. */
    private fun completeCurrentAsiacellStep(result: String) {
        if (!automaticAsiacellFlowInProgress || automaticAsiacellCurrentStepFinished) return
        val label = automaticAsiacellSubscriptionLabels[automaticAsiacellCurrentSubscriptionId] ?: "شريحة آسياسيل"
        if (result.isNotBlank()) automaticAsiacellFlowResults.add("$label: $result")
        automaticAsiacellLastTransferBalance = null
        automaticAsiacellCurrentStepFinished = true
        automaticAsiacellCurrentSubscriptionId = -1
        automaticAsiacellSubscriptionIndex += 1
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing && automaticAsiacellFlowInProgress) processNextAsiacellSubscription()
        }, 1200L)
    }

    private fun finishAsiacellTransferFlow() {
        if (!automaticAsiacellFlowInProgress) return
        automaticAsiacellFlowInProgress = false
        automaticAsiacellCurrentSubscriptionId = -1
        val results = automaticAsiacellFlowResults.toList()
        val onlyLowBalances = automaticAsiacellHadLowBalance &&
            !automaticAsiacellHadTransferAttempt &&
            results.isNotEmpty() &&
            results.all { it.contains("أقل من 1,500") }

        if (automaticAsiacellHadTransferAttempt) {
            // Do not show a success/result popup after a transfer. Only genuine
            // failures reported by Android or the carrier remain visible.
            if (automaticAsiacellTransferErrors.isNotEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle("تعذر إتمام التحويل")
                    .setMessage(automaticAsiacellTransferErrors.joinToString("\n\n"))
                    .setPositiveButton("حسناً", null)
                    .show()
            }
        } else if (onlyLowBalances) {
            showKikaWelcomePopup()
        } else if (results.isNotEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("نتائج فحص شرائح آسياسيل")
                .setMessage(results.joinToString("\n\n"))
                .setPositiveButton("حسناً", null)
                .show()
        }

        automaticAsiacellTransferErrors.clear()
        automaticAsiacellSubscriptionIds.clear()
        automaticAsiacellSubscriptionLabels.clear()
        automaticAsiacellSubscriptionIndex = 0
        automaticAsiacellFlowResults.clear()
    }

    private fun showAsiacellSimBlocked(message: String) {
        AlertDialog.Builder(this)
            .setTitle("تعذر تحديد شريحة آسياسيل")
            .setMessage(message)
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun chooseSimAndSend(code: String) {
        // Use the saved SIM if configured; otherwise Android's default voice SIM.
        // This avoids showing a SIM chooser and lets the balance refresh automatically.
        if (selectedSubscriptionId < 0) selectedSubscriptionId = prefs.getInt("selected_sim_id", -1)
        if (selectedSubscriptionId < 0) {
            selectedSubscriptionId = try { SubscriptionManager.getDefaultVoiceSubscriptionId() }
            catch (_: Exception) { -1 }
        }
        sendUssdNow(code)
    }

    private fun sendUssdNow(code: String, subscriptionIdOverride: Int? = null) {
        // Keep the subscription ID outside the try block because the error handlers
        // also need it to finish the correct SIM's automatic balance-check step.
        val requestSubscriptionId = subscriptionIdOverride
            ?: if (selectedSubscriptionId >= 0) selectedSubscriptionId
            else try { SubscriptionManager.getDefaultVoiceSubscriptionId() } catch (_: Exception) { -1 }
        // Any balance-check request that could trigger the subscription transfer
        // must pass through the Asiacell SIM scan, never the generic/default SIM.
        if (code == "*133#" && subscriptionIdOverride == null) {
            requestBalanceAutomatically(force = true)
            return
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            showUssdFallback(code, "لم تمنح التطبيق صلاحية الاتصال اللازمة لتنفيذ USSD.")
            return
        }
        try {
            val baseManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val manager = if (requestSubscriptionId >= 0) baseManager.createForSubscriptionId(requestSubscriptionId) else baseManager
            manager.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    val answer = response.toString().trim().ifBlank { "استلم الهاتف رداً فارغاً من الشبكة." }
                    if (request == "*133#" || request == "*233#") {
                        val receivedAt = System.currentTimeMillis()
                        prefs.edit().putString("balance_response", answer).putLong("balance_time", receivedAt).apply()
                        balanceValueView?.text = answer
                        if (request == "*133#") handleBalanceForAutomaticTransfer(answer, requestSubscriptionId)
                    }
                    if (request != "*133#") showUssdResult(request, answer, pendingUssdShowDialer)
                }

                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    val reason = when (failureCode) {
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "خدمة USSD غير متاحة من الشبكة حالياً."
                        TelephonyManager.USSD_RETURN_FAILURE -> "رفضت الشبكة الطلب أو لم تستطع تنفيذه."
                        else -> "تعذر استلام نتيجة USSD (رمز الخطأ $failureCode)."
                    }
                    if (request == "*133#" || request == "*233#") {
                        prefs.edit().putString("balance_response", "تعذر تحديث الرصيد: $reason").apply()
                        balanceValueView?.text = "تعذر تحديث الرصيد تلقائياً. افتح التطبيق لاحقاً للمحاولة مجدداً."
                        if (request == "*133#" && automaticAsiacellFlowInProgress &&
                            requestSubscriptionId == automaticAsiacellCurrentSubscriptionId) {
                            completeCurrentAsiacellStep("تعذر فحص الرصيد: $reason لم يتم إرسال تحويل لهذه الشريحة.")
                        }
                    } else {
                        showUssdFallback(request, reason)
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            if (code == "*133#") {
                balanceValueView?.text = "صلاحية الاتصال مطلوبة لجلب الرصيد تلقائياً."
                if (automaticAsiacellFlowInProgress && requestSubscriptionId == automaticAsiacellCurrentSubscriptionId) {
                    completeCurrentAsiacellStep("تعذر فحص الرصيد بسبب صلاحية الاتصال؛ لم يتم التحويل.")
                }
            } else showUssdFallback(code, "لا تتوفر صلاحية كافية لتنفيذ الطلب: ${e.message ?: ""}")
        } catch (e: Exception) {
            if (code == "*133#") {
                balanceValueView?.text = "هذا الهاتف أو الخط لا يدعم استعلام USSD التلقائي."
                if (automaticAsiacellFlowInProgress && requestSubscriptionId == automaticAsiacellCurrentSubscriptionId) {
                    completeCurrentAsiacellStep("هذا الهاتف أو الخط لم يتمكن من فحص الرصيد؛ لم يتم التحويل.")
                }
            } else showUssdFallback(code, "هذا الهاتف أو الخط لا يدعم تنفيذ الطلب بهذه الطريقة.")
        }
    }

    // For each Asiacell SIM: re-read its balance after every transfer and repeat capped
    // transfers until the balance is below 1,500 IQD, then move to the next SIM.
    private fun handleBalanceForAutomaticTransfer(response: String, subscriptionId: Int) {
        if (!automaticAsiacellFlowInProgress || subscriptionId != automaticAsiacellCurrentSubscriptionId) return
        if (!isActiveAsiacellSubscription(subscriptionId)) {
            completeCurrentAsiacellStep("تغيرت الشريحة المحددة أو لم تعد شريحة آسياسيل نشطة؛ لم يتم إرسال تحويل.")
            return
        }
        val balance = parseBalanceAmount(response)
        if (balance == null) {
            if (automaticAsiacellLastTransferBalance != null) {
                val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"
                automaticAsiacellTransferErrors.add("$label: تعذر قراءة الرصيد بعد آخر تحويل؛ تم إيقاف الدفعات لتجنب تكرار التحويل دون التحقق من الرصيد.")
            }
            completeCurrentAsiacellStep("وصل رد آسياسيل لكن تعذر قراءة مبلغ الرصيد بدقة؛ لم يتم إرسال تحويل.")
            return
        }

        val previousTransferBalance = automaticAsiacellLastTransferBalance
        if (previousTransferBalance != null) {
            automaticAsiacellLastTransferBalance = null
            if (balance >= previousTransferBalance) {
                val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"
                automaticAsiacellTransferErrors.add("$label: لم ينخفض الرصيد بعد طلب التحويل؛ تم إيقاف تكرار الطلبات لتجنب تحويل مكرر.")
                completeCurrentAsiacellStep("")
                return
            }
        }

        if (balance < 1_500) {
            automaticAsiacellHadLowBalance = true
            completeCurrentAsiacellStep("الرصيد أقل من 1,500 دينار؛ لم يتم إجراء تحويل لهذه الشريحة.")
            return
        }

        // Enforce the 15-minute cooldown only once per SIM per automatic run.
        // Further transfers in this same run are part of the same batch.
        if (subscriptionId !in automaticAsiacellAttemptedThisRun) {
            val cooldownKey = "transfer_auto_last_attempt_$subscriptionId"
            val lastTransferAttempt = prefs.getLong(cooldownKey, 0L)
            if (System.currentTimeMillis() - lastTransferAttempt < 15 * 60 * 1000L) {
                completeCurrentAsiacellStep("")
                return
            }
            automaticAsiacellAttemptedThisRun.add(subscriptionId)
        }

        // Subtract the 500 IQD fee, round DOWN to whole thousands, and
        // transfer no more than 10,000 IQD in each cycle. The next cycle
        // re-reads the real balance after the carrier processes this transfer.
        val amountBeforeRounding = balance - 500
        val wholeThousands = (amountBeforeRounding / 1000) * 1000
        if (wholeThousands < 1000) {
            automaticAsiacellHadLowBalance = true
            completeCurrentAsiacellStep("")
            return
        }

        val transferAmount = wholeThousands.coerceAtMost(10_000)
        automaticAsiacellLastTransferBalance = balance
        val recipient = "07779575401"
        val code = "*123*${transferAmount}*${recipient.removePrefix("0")}*1#"
        submitAutomaticTransfer(code, transferAmount, subscriptionId)
    }

    /** Wait two seconds after a transfer response, then read the updated balance
     * on the same Asiacell SIM before deciding whether another transfer is needed.
     */
    private fun scheduleNextAsiacellBalanceCheck(subscriptionId: Int) {
        Handler(Looper.getMainLooper()).postDelayed({
            if (isFinishing || !automaticAsiacellFlowInProgress ||
                automaticAsiacellCurrentStepFinished ||
                automaticAsiacellCurrentSubscriptionId != subscriptionId) return@postDelayed

            if (!isActiveAsiacellSubscription(subscriptionId)) {
                completeCurrentAsiacellStep("")
                return@postDelayed
            }
            sendUssdNow("*133#", subscriptionId)
        }, 2_000L)
    }

    private fun parseBalanceAmount(response: String): Int? {
        val normalized = normalizeDigits(response).replace('\u00A0', ' ')
        val groupedNumber = Regex("(?<!\\d)(\\d{1,3}(?:[,.،٬\\s]\\d{3})+|\\d{1,9})(?!\\d)")
        val balanceLabel = Regex("(?i)(?:الرصيد|رصيدك|balance)")
        val labelMatch = balanceLabel.find(normalized)
        val fromBalanceLabel = labelMatch?.let {
            groupedNumber.find(normalized.substring(it.range.last + 1).take(55))?.value
        }
        val fromCurrency = Regex("(?i)(\\d{1,3}(?:[,.،٬\\s]\\d{3})+|\\d{1,9})\\s*(?:د\\.?ع|دينار|IQD)").find(normalized)?.groupValues?.get(1)
        val token = fromBalanceLabel ?: fromCurrency ?: return null
        return token.filter { it.isDigit() }.toIntOrNull()
    }

    private fun submitAutomaticTransfer(code: String, amount: Int, subscriptionId: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            completeCurrentAsiacellStep("هذا الإصدار لا يدعم طلب USSD التلقائي؛ لم يتم التحويل.")
            return
        }

        // Never use the default voice SIM here. Re-validate the exact SIM whose balance was read.
        if (!isActiveAsiacellSubscription(subscriptionId) ||
            subscriptionId != automaticAsiacellCurrentSubscriptionId) {
            completeCurrentAsiacellStep("لم تعد الشريحة التي تم فحص رصيدها شريحة آسياسيل نشطة؛ تم إيقاف التحويل.")
            return
        }

        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CALL_PHONE)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_PHONE_STATE)
        if (needed.isNotEmpty()) {
            pendingTransferCode = code
            pendingTransferAmount = amount
            pendingTransferSubscriptionId = subscriptionId
            requestPermissions(needed.toTypedArray(), REQ_USSD_PERMISSION)
            return
        }

        try {
            val baseManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val manager = baseManager.createForSubscriptionId(subscriptionId)
            val now = System.currentTimeMillis()
            prefs.edit().putLong("transfer_auto_last_attempt_$subscriptionId", now)
                .putLong("transfer_auto_last_attempt", now).apply()
            automaticAsiacellHadTransferAttempt = true
            manager.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    val answer = response.toString().trim()
                    // Hide every ordinary carrier response, including messages such
                    // as "تم إرسال الطلب"، "تم التحويل" and "تم الخصم".
                    // Retain only an explicit failure for the error dialog.
                    val explicitFailure = Regex(
                        "(?i)(فشل|تعذر|خطأ|مرفوض|رفض|غير كاف|لا يكفي|لم يتم|لا يمكن|غير صحيح|insufficient|not enough|failed|failure|rejected|error)"
                    ).containsMatchIn(answer)
                    if (explicitFailure && answer.isNotBlank()) {
                        val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"
                        automaticAsiacellTransferErrors.add("$label: $answer")
                        completeCurrentAsiacellStep("")
                    } else {
                        // Do not display the carrier's ordinary success text. Recheck
                        // the balance after two seconds and continue the batch if needed.
                        scheduleNextAsiacellBalanceCheck(subscriptionId)
                    }
                }

                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    val reason = when (failureCode) {
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "خدمة USSD غير متاحة من الشبكة حالياً."
                        TelephonyManager.USSD_RETURN_FAILURE -> "رفضت الشبكة الطلب أو لم تستطع تنفيذه."
                        else -> "تعذر استلام نتيجة USSD (رمز الخطأ $failureCode)."
                    }
                    val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"
                    automaticAsiacellTransferErrors.add("$label: فشل طلب التحويل: $reason")
                    completeCurrentAsiacellStep("")
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"
            automaticAsiacellTransferErrors.add("$label: تعذر إرسال طلب التحويل: ${e.message ?: "خطأ غير معروف"}")
            completeCurrentAsiacellStep("")
        }
    }

    private fun showUssdResult(code: String, response: String, fallback: Boolean) {
        val builder = AlertDialog.Builder(this)
            .setTitle(if (code == "*133#" || code == "*233#") "نتيجة استعلام الرصيد" else "رد شبكة آسياسيل")
            .setMessage(response)
            .setPositiveButton("حسناً", null)
        if (fallback) builder.setNeutralButton("متابعة في شاشة الاتصال") { _, _ -> openDialer(code) }
        builder.show()
    }

    private fun showUssdFallback(code: String, reason: String) {
        AlertDialog.Builder(this)
            .setTitle("تعذر إكمال طلب الشبكة داخل التطبيق")
            .setMessage("$reason\n\nيمكن فتح شاشة الاتصال بالكود نفسه كبديل. سيبقى عليك الضغط على زر الاتصال.")
            .setPositiveButton("فتح شاشة الاتصال") { _, _ -> openDialer(code) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STARTUP_PERMISSIONS) {
            // Permissions are requested proactively at launch. If declined,
            // the existing feature-specific checks will explain/request them later.
            return
        }
        if (requestCode == REQ_USSD_PERMISSION) {
            val callGranted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val phoneStateGranted = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

            val transferCode = pendingTransferCode
            if (transferCode != null) {
                val amount = pendingTransferAmount
                val subscriptionId = pendingTransferSubscriptionId
                pendingTransferCode = null
                pendingTransferAmount = null
                pendingTransferSubscriptionId = -1
                if (callGranted && phoneStateGranted && amount != null) {
                    submitAutomaticTransfer(transferCode, amount, subscriptionId)
                } else {
                    completeCurrentAsiacellStep("لم تُمنح صلاحيات الاتصال وفحص الشرائح؛ لم يتم إرسال التحويل لهذه الشريحة.")
                }
                return
            }

            if (pendingAutomaticBalanceRequest) {
                if (callGranted && phoneStateGranted) {
                    startAsiacellBalanceLookup()
                } else {
                    pendingAutomaticBalanceRequest = false
                    balanceValueView?.text = "يلزم السماح بفحص الشرائح وجلب الرصيد."
                    showAsiacellSimBlocked("يلزم منح صلاحية الاتصال وقراءة معلومات الشرائح حتى يتأكد التطبيق من استخدام خط آسياسيل فقط. لم يتم إرسال أي تحويل.")
                }
                return
            }

            val requestedCode = pendingUssdCode
            pendingUssdCode = ""
            if (callGranted) {
                if (requestedCode == "*133#") sendUssdNow(requestedCode) else if (requestedCode.isNotBlank()) chooseSimAndSend(requestedCode)
            } else if (requestedCode.isNotBlank()) {
                if (requestedCode == "*133#") balanceValueView?.text = "امنح صلاحية الاتصال ليظهر رصيدك تلقائياً."
                else showUssdFallback(requestedCode, "صلاحية الاتصال مطلوبة لإرسال طلب USSD.")
            }
        }
    }

    private fun showGiftDialog() {
        val giftOptions = arrayOf(
            "إلنا الأسبوعي — 3,000 د.ع",
            "للكل لـ4 أسابيع — 15,000 د.ع",
            "إلنا لـ4 أسابيع — 25,000 د.ع",
            "للكل الأسبوعي — 4,000 د.ع",
            "للكل إضافي — 15,000 د.ع",
            "للكل إضافي+ — 20,000 د.ع",
            "MAX 25 — 25,000 د.ع",
            "MAX 35 — 35,000 د.ع",
            "MAX 6 — 6,000 د.ع",
            "MAX 12 — 12,000 د.ع",
            "MAX 55 — 55,000 د.ع",
            "فتح قائمة إهداء كل الباقات (USSD)"
        )
        val keys = listOf("9", "10", "11", "12", "13", "14", "25", "35", "66", "22", "55")
        AlertDialog.Builder(this)
            .setTitle("إهداء باقة لمشترك آخر")
            .setItems(giftOptions) { _, which ->
                if (which == giftOptions.lastIndex) {
                    openDialer("*336#")
                } else {
                    val phoneInput = EditText(this).apply {
                        hint = "رقم المستلم 07XXXXXXXXX"
                        inputType = android.text.InputType.TYPE_CLASS_PHONE
                        textDirection = View.TEXT_DIRECTION_LTR
                    }
                    AlertDialog.Builder(this)
                        .setTitle("رقم المستلم")
                        .setMessage("سيتم تجهيز SMS إلى 336 بالمفتاح ${keys[which]} ورقم المستلم. راجع الرسالة والسعر ثم اضغط إرسال.")
                        .setView(phoneInput)
                        .setPositiveButton("إعداد الرسالة") { _, _ ->
                            val phone = normalizeDigits(phoneInput.text.toString()).filter { it.isDigit() }
                            if (!(phone.startsWith("07") && phone.length in 10..11)) {
                                Toast.makeText(this, "أدخل رقم آسياسيل صحيحاً يبدأ بـ 07", Toast.LENGTH_LONG).show()
                            } else {
                                openSmsComposer("336", keys[which] + phone)
                            }
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showTransferDialog() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val phone = EditText(this).apply { hint = "رقم المستلم 07XXXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        val amount = EditText(this).apply { hint = "المبلغ بالدينار (1000 إلى 10000)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        form.addView(phone); form.addView(amount)
        AlertDialog.Builder(this).setTitle("تحويل رصيد آسياسيل").setView(form)
            .setMessage("رسم العملية 500 دينار. الحد الأدنى 1,000 والأقصى 10,000 دينار للعملية. راجع رقم المستلم جيداً.")
            .setPositiveButton("متابعة") { _, _ ->
                val p = normalizeDigits(phone.text.toString()).filter { it.isDigit() }
                val a = normalizeDigits(amount.text.toString()).filter { it.isDigit() }.toIntOrNull()
                if (!(p.startsWith("07") && p.length in 10..11) || a == null || a !in 1000..10000) {
                    Toast.makeText(this, "تحقق من رقم المستلم والمبلغ", Toast.LENGTH_LONG).show()
                } else {
                    val code = "*123*$a*$p#"
                    AlertDialog.Builder(this).setTitle("تأكيد التحويل")
                        .setMessage("الرقم: $p\nالمبلغ: ${formatNumber(a)} دينار\nالرسوم: 500 دينار\n\nسيفتح كود التحويل في شاشة الاتصال. بعد طلب الشبكة قد تحتاج إلى إدخال 1 للتأكيد.")
                        .setPositiveButton("فتح شاشة الاتصال") { _, _ -> openDialer(code) }
                        .setNegativeButton("إلغاء", null).show()
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showCallMeDialog() {
        val input = EditText(this).apply { hint = "رقم الشخص الذي تريد منه الاتصال"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("إرسال اتصل بي").setMessage("ستجهز رسالة إلى 250 تحتوي رقم الشخص المطلوب. الخدمة توفر 10 رسائل مجانية للمشتركين المؤهلين.")
            .setView(input).setPositiveButton("إعداد الرسالة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً يبدأ بـ 07", Toast.LENGTH_LONG).show()
                else openSmsComposer("250", number)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showValidityDialog() {
        val options = arrayOf("يوم واحد — 250 دينار", "3 أيام — 500 دينار", "7 أيام — 1,000 دينار", "30 يوماً — 3,500 دينار", "90 يوماً — 7,500 دينار", "365 يوماً — 21,000 دينار")
        val keys = listOf("1", "2", "3", "4", "5", "6")
        AlertDialog.Builder(this).setTitle("شراء صلاحية الخط المعلق").setItems(options) { _, which ->
            AlertDialog.Builder(this).setTitle("إعداد رسالة شراء الصلاحية")
                .setMessage("سيتم تجهيز رسالة بالرمز ${keys[which]} إلى 290. هذه الخدمة مخصصة للخط المعلق بسبب انتهاء الصلاحية مع وجود رصيد متبقٍ.")
                .setPositiveButton("متابعة") { _, _ -> openSmsComposer("290", keys[which]) }
                .setNegativeButton("إلغاء", null).show()
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun showCallEctDialog() {
        val input = EditText(this).apply { hint = "رقم المستلم 077XXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("CALLect").setMessage("المستلم يسمع طلباً ويختار 1 لقبول دفع كلفة المكالمة أو 2 للرفض.")
            .setView(input).setPositiveButton("متابعة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً", Toast.LENGTH_LONG).show()
                else openDialer("#$number")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showCallForwardDialog() {
        val input = EditText(this).apply { hint = "رقم التحويل 07XXXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("تحويل المكالمات").setMessage("تفعيل التحويل مجاني، لكن قد تُحسب عليك تكلفة استقبال المكالمة المحولة. لإلغاء جميع التحويلات استخدم #002##.")
            .setView(input).setPositiveButton("تجهيز الكود") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً", Toast.LENGTH_LONG).show()
                else AlertDialog.Builder(this).setTitle("تأكيد رقم التحويل").setMessage("سيتم تجهيز *21*$number# في شاشة الاتصال. تأكد من الرقم قبل الضغط على اتصال.")
                    .setPositiveButton("فتح الاتصال") { _, _ -> openDialer("*21*$number#") }
                    .setNegativeButton("إلغاء", null).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showByeByeDialog() {
        val choices = arrayOf("تفعيل خدمة باي باي (رسوم 2,400 دينار)", "الاستعلام عن قائمة الحظر (مجاني)", "حجب رقم (600 دينار لكل رقم)", "إزالة رقم من قائمة الحظر (مجاني)", "الاتصال بالمجيب 266")
        AlertDialog.Builder(this).setTitle("إدارة خدمة باي باي").setItems(choices) { _, which ->
            when (which) {
                0 -> AlertDialog.Builder(this).setTitle("تأكيد التفعيل").setMessage("تفعيل الخدمة يكلف 2,400 دينار. هل تريد فتح رسالة التفعيل؟")
                    .setPositiveButton("متابعة") { _, _ -> openSmsComposer("266", "") }.setNegativeButton("إلغاء", null).show()
                1 -> openSmsComposer("266", "1")
                2 -> askNumberForByeBye(false)
                3 -> askNumberForByeBye(true)
                else -> openDialer("266")
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun askNumberForByeBye(remove: Boolean) {
        val input = EditText(this).apply { hint = "رقم الهاتف 077XXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle(if (remove) "إزالة رقم" else "حجب رقم")
            .setView(input).setPositiveButton("إعداد الرسالة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً صحيحاً", Toast.LENGTH_LONG).show()
                else openSmsComposer("266", if (remove) "* $number" else number)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun normalizeDigits(value: String): String {
        val map = mapOf('٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4', '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9', '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4', '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9')
        return value.map { map[it] ?: it }.joinToString("")
    }

    companion object {
        private const val REQ_STARTUP_PERMISSIONS = 700
        private const val REQ_USSD_PERMISSION = 701
    }
}
