package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Gesture-only service.
 * It deliberately does not inspect accessibility events or retrieve window content.
 */
class AutoClickService : AccessibilityService() {
    companion object {
        const val PREFS = "auto_clicker_settings"
        const val KEY_X = "x"
        const val KEY_Y = "y"
        const val KEY_INTERVAL = "interval"
        const val KEY_RUNNING = "running"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var nextClickAt = 0L

    private val clickLoop = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
            if (!prefs.getBoolean(KEY_RUNNING, false)) {
                nextClickAt = 0L
                handler.postDelayed(this, 200L)
                return
            }

            val x = prefs.getInt(KEY_X, 500).toFloat()
            val y = prefs.getInt(KEY_Y, 800).toFloat()
            val interval = prefs.getLong(KEY_INTERVAL, 1000L).coerceAtLeast(50L)

            val metrics = resources.displayMetrics
            if (x >= 0f && y >= 0f && x < metrics.widthPixels && y < metrics.heightPixels) {
                val path = Path().apply { moveTo(x, y) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
                    .build()
                dispatchGesture(gesture, null, null)
            } else {
                prefs.edit().putBoolean(KEY_RUNNING, false).apply()
                return
            }

            handler.postDelayed(this, interval)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(clickLoop)
        handler.post(clickLoop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty: no event monitoring or screen-content access.
    }

    override fun onInterrupt() {
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit().putBoolean(KEY_RUNNING, false).apply()
        handler.removeCallbacks(clickLoop)
    }

    override fun onDestroy() {
        handler.removeCallbacks(clickLoop)
        super.onDestroy()
    }
}
