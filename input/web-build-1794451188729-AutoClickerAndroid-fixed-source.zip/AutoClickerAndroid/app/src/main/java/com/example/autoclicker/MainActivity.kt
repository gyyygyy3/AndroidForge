package com.example.autoclicker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var status: TextView

    private val prefs by lazy {
        getSharedPreferences(AutoClickService.PREFS, Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        fun label(value: String) {
            layout.addView(TextView(this).apply {
                text = value
                textSize = 16f
                setPadding(0, 14, 0, 4)
            })
        }

        layout.addView(TextView(this).apply {
            text = "النقر التلقائي"
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        })

        label("إحداثي X")
        xInput = field(prefs.getInt(AutoClickService.KEY_X, 500).toString(), "مثال: 500")
        layout.addView(xInput)

        label("إحداثي Y")
        yInput = field(prefs.getInt(AutoClickService.KEY_Y, 800).toString(), "مثال: 800")
        layout.addView(yInput)

        label("الفاصل بين النقرات بالمللي ثانية")
        intervalInput = field(prefs.getLong(AutoClickService.KEY_INTERVAL, 1000L).toString(), "1000")
        layout.addView(intervalInput)

        val permissionButton = Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(permissionButton)

        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 14, 0, 14)
        }
        layout.addView(status)

        layout.addView(Button(this).apply {
            text = "بدء النقر"
            setOnClickListener { startClicking() }
        })

        layout.addView(Button(this).apply {
            text = "إيقاف النقر"
            setOnClickListener {
                prefs.edit().putBoolean(AutoClickService.KEY_RUNNING, false).apply()
                status.text = "الحالة: متوقف"
            }
        })

        layout.addView(TextView(this).apply {
            text = "ملاحظة: أدخل إحداثيات النقطة على الشاشة. ابدأ النقر ثم انتقل إلى التطبيق المطلوب. يجب تفعيل خدمة النقر من إعدادات إمكانية الوصول أولاً."
            textSize = 13f
            setPadding(0, 20, 0, 0)
        })

        setContentView(layout)
        updateStatus()
    }

    private fun field(value: String, hintText: String) = EditText(this).apply {
        setText(value)
        hint = hintText
        textSize = 16f
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        singleLine = true
    }

    private fun startClicking() {
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "فعّل خدمة النقر من إعدادات إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val x = xInput.text.toString().toIntOrNull()
        val y = yInput.text.toString().toIntOrNull()
        val interval = intervalInput.text.toString().toLongOrNull()

        if (x == null || y == null || interval == null || x < 0 || y < 0 || interval < 50L) {
            Toast.makeText(this, "تحقق من الإحداثيات والفاصل (50 مللي ثانية على الأقل)", Toast.LENGTH_LONG).show()
            return
        }

        prefs.edit()
            .putInt(AutoClickService.KEY_X, x)
            .putInt(AutoClickService.KEY_Y, y)
            .putLong(AutoClickService.KEY_INTERVAL, interval)
            .putBoolean(AutoClickService.KEY_RUNNING, true)
            .apply()

        status.text = "الحالة: يعمل — X=$x ، Y=$y"
        Toast.makeText(this, "تم تشغيل النقر التلقائي", Toast.LENGTH_SHORT).show()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = "$packageName/${AutoClickService::class.java.name}"
        return manager.getEnabledAccessibilityServiceList(
            android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        ).any { it.id.equals(expected, ignoreCase = true) }
    }

    private fun updateStatus() {
        status.text = if (prefs.getBoolean(AutoClickService.KEY_RUNNING, false))
            "الحالة: تم طلب التشغيل" else "الحالة: متوقف"
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }
}
