package com.example.autoscreencapture

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "التقاط الشاشة تلقائياً كل 10 ثوانٍ"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "بعد الموافقة على تسجيل الشاشة، سيحفظ التطبيق لقطة كل 10 ثوانٍ من الشاشة كاملة، بغض النظر عن التطبيق المفتوح. أوقف الالتقاط من الزر أدناه."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "بدء الالتقاط"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف الالتقاط"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                Toast.makeText(this@MainActivity, "تم طلب إيقاف الالتقاط", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                }
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service)
                else startService(service)
                Toast.makeText(this, "بدأ الالتقاط كل 10 ثوانٍ", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "لم تتم الموافقة على تسجيل الشاشة", Toast.LENGTH_LONG).show()
            }
        }
    }
}
