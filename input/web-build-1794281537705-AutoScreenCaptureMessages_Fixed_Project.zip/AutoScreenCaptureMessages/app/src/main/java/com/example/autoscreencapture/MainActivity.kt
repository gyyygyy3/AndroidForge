package com.example.autoscreencapture

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.app.ActivityManager
import android.app.AlertDialog
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "التقاط تلقائي عند فتح تطبيق الرسائل فقط"
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "امنح الوصول إلى بيانات الاستخدام، ثم وافق على تسجيل الشاشة. ستظهر خدمة مراقبة بإشعار واضح أثناء عملها."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val usage = Button(this).apply {
            text = "منح صلاحية الوصول إلى بيانات الاستخدام"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        val start = Button(this).apply {
            text = "بدء الالتقاط التلقائي"
            setOnClickListener { beginCaptureSetup() }
        }
        val stop = Button(this).apply {
            text = "إيقاف الالتقاط"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                Toast.makeText(this@MainActivity, "تم طلب إيقاف الخدمة", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(usage)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow(
            "android:get_usage_stats",
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun beginCaptureSetup() {
        if (!hasUsageAccess()) {
            AlertDialog.Builder(this)
                .setTitle("صلاحية مطلوبة")
                .setMessage("فعّل «الوصول إلى بيانات الاستخدام» لهذا التطبيق، ثم ارجع واضغط بدء الالتقاط.")
                .setPositiveButton("فتح الإعدادات") { _, _ ->
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
                .setNegativeButton("إلغاء", null)
                .show()
            return
        }

        val smsPackage = android.provider.Telephony.Sms.getDefaultSmsPackage(this)
        if (smsPackage.isNullOrBlank()) {
            AlertDialog.Builder(this)
                .setTitle("تطبيق الرسائل الافتراضي")
                .setMessage("لم يتم تعيين تطبيق رسائل SMS افتراضي. عيّن تطبيق الرسائل الافتراضي في إعدادات الهاتف ثم أعد المحاولة.")
                .setPositiveButton("حسناً", null)
                .show()
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                }
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service)
                else startService(service)
                Toast.makeText(this, "بدأت خدمة الالتقاط", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "لم تتم الموافقة على تسجيل الشاشة", Toast.LENGTH_LONG).show()
            }
        }
    }
}
