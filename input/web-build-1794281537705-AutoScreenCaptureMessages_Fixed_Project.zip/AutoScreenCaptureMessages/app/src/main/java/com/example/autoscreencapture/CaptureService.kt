package com.example.autoscreencapture

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "screen_capture_service"
        private const val NOTIFICATION_ID = 41
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private var targetPackage: String? = null
    private var wasInTarget = false
    private var capturePending = false
    private var stopped = false
    // Keep the last observed foreground package when a poll contains no new events.
    private var currentForegroundPackage: String? = null

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("التقاط رسائل الشاشة")
            .setContentText("مراقبة تطبيق الرسائل الافتراضي — اضغط إيقاف من التطبيق لإنهاء الخدمة")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        targetPackage = android.provider.Telephony.Sms.getDefaultSmsPackage(this)
        if (targetPackage.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, handler)
            startVirtualDisplay()
            handler.post(pollTask)
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startVirtualDisplay() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 3)
        reader?.setOnImageAvailableListener({ imageReader ->
            val image = try { imageReader.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) {
                if (capturePending) {
                    capturePending = false
                    saveImage(image)
                }
                image.close()
            }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "MessagesAutoCapture",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }

    private val pollTask = object : Runnable {
        override fun run() {
            if (stopped) return
            val now = System.currentTimeMillis()
            val usage = getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
            val events = usage.queryEvents(now - 5000, now)
            val event = android.app.usage.UsageEvents.Event()
            var latestForeground: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val isForeground = if (Build.VERSION.SDK_INT >= 29) {
                    event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED
                } else {
                    @Suppress("DEPRECATION")
                    event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND
                }
                if (isForeground) latestForeground = event.packageName
            }
            // Do not reset the foreground package simply because this poll had no new event.
            if (latestForeground != null) currentForegroundPackage = latestForeground

            val inTarget = currentForegroundPackage == targetPackage
            if (inTarget && !wasInTarget) {
                // Request one screenshot on entry; ImageReader supplies the next available frame.
                capturePending = true
            }
            wasInTarget = inTarget
            handler.postDelayed(this, 650)
        }
    }

    private fun saveImage(image: Image) {
        try {
            val plane = image.planes[0]
            val buffer: ByteBuffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val fullBitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            fullBitmap.copyPixelsFromBuffer(buffer)
            val bitmap = Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height)
            fullBitmap.recycle()

            val dir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "MessagesCaptures")
            if (!dir.exists()) dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
            FileOutputStream(File(dir, "messages_$stamp.png")).use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            bitmap.recycle()
        } catch (_: Exception) {
            // A capture can fail if Android or the target app blocks screen capture.
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "خدمة التقاط الشاشة", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopped = true
        handler.removeCallbacks(pollTask)
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
