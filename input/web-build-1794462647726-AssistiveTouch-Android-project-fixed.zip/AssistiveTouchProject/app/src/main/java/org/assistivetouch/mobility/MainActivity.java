package org.assistivetouch.mobility;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(247, 249, 252));
        getWindow().setNavigationBarColor(Color.rgb(247, 249, 252));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        setContentView(createContent());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateServiceStatus();
    }

    private View createContent() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(247, 249, 252));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("مساعد اللمس", 30, Color.rgb(16, 24, 40), true);
        root.addView(title, matchWrap());

        TextView subtitle = text("تحكّم أسهل للأشخاص ذوي محدودية الحركة", 17,
                Color.rgb(71, 84, 103), false);
        addTop(root, subtitle, 8);

        LinearLayout statusCard = card();
        statusText = text("جارٍ التحقق من حالة الخدمة…", 16, Color.rgb(16, 24, 40), true);
        statusCard.addView(statusText, matchWrap());
        addTop(root, statusCard, 22);

        TextView howTitle = text("طريقة الاستخدام", 21, Color.rgb(16, 24, 40), true);
        addTop(root, howTitle, 24);
        addParagraph(root, "١. فعّل لوحة المساعدة من إعدادات إمكانية الوصول.");
        addParagraph(root, "٢. ستظهر لوحة كبيرة فوق التطبيقات. استخدم أزرار الاتجاه لتحريك علامة الهدف إلى العنصر المطلوب.");
        addParagraph(root, "٣. اختر «نقرة واحدة» أو «ضغط مطوّل» لتنفيذ حركة واحدة فقط.");
        addParagraph(root, "يمكن استخدام أزرار اللوحة مع قارئ الشاشة أو Switch Access، كما يمكن سحب علامة الهدف باللمس.");

        TextView disclosureTitle = text("ماذا تفعل الخدمة؟", 20, Color.rgb(16, 24, 40), true);
        addTop(root, disclosureTitle, 24);
        LinearLayout disclosure = card();
        TextView disclosureBody = text(
                "تستخدم الخدمة واجهة إمكانية الوصول لعرض لوحة تحكم وعلامة هدف، ثم إرسال نقرة واحدة أو ضغط مطوّل عند اختيارك الصريح. لا تقرأ محتوى النوافذ، ولا تسجّل الشاشة أو ضغطات المفاتيح، ولا تجمع أو ترسل بيانات، ولا تنفّذ نقرات متكررة أو إجراءات من تلقاء نفسها. يمكنك إيقافها من زر «إيقاف المساعدة» أو من إعدادات الجهاز.",
                15, Color.rgb(52, 64, 84), false);
        disclosureBody.setLineSpacing(dp(4), 1.0f);
        disclosure.addView(disclosureBody, matchWrap());
        addTop(root, disclosure, 10);

        Button enable = makeButton("أوافق وأفتح إعدادات إمكانية الوصول", true);
        enable.setContentDescription("أوافق على وصف الخدمة وأفتح إعدادات إمكانية الوصول لتفعيل لوحة المساعدة");
        enable.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                statusText.setText("تعذّر فتح إعدادات إمكانية الوصول. افتحها يدوياً من إعدادات الجهاز.");
            }
        });
        addTop(root, enable, 24);

        TextView foot = text("لا يوجد تسجيل دخول أو إعلانات أو اتصال بالإنترنت داخل هذا الإصدار.",
                13, Color.rgb(102, 112, 133), false);
        foot.setGravity(Gravity.CENTER);
        addTop(root, foot, 18);
        return scroll;
    }

    private void updateServiceStatus() {
        if (statusText == null) return;
        boolean enabled = false;
        AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (manager != null) {
            List<android.accessibilityservice.AccessibilityServiceInfo> services =
                    manager.getEnabledAccessibilityServiceList(
                            android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            for (android.accessibilityservice.AccessibilityServiceInfo info : services) {
                if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null) {
                    String pkg = info.getResolveInfo().serviceInfo.packageName;
                    String cls = info.getResolveInfo().serviceInfo.name;
                    if (getPackageName().equals(pkg) &&
                            AssistiveGestureService.class.getName().equals(cls)) {
                        enabled = true;
                        break;
                    }
                }
            }
        }
        statusText.setText(enabled
                ? "الخدمة مفعّلة. ستظهر لوحة المساعدة فوق التطبيقات."
                : "الخدمة غير مفعّلة حالياً. استخدم الزر أدناه لتفعيلها عند الحاجة.");
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(16), dp(17), dp(16));
        box.setBackground(roundRect(Color.WHITE, dp(18), Color.rgb(228, 232, 240), dp(1)));
        return box;
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setIncludeFontPadding(true);
        return view;
    }

    private Button makeButton(String label, boolean primary) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(primary ? Color.WHITE : Color.rgb(21, 94, 239));
        button.setMinHeight(dp(58));
        button.setPadding(dp(16), dp(10), dp(16), dp(10));
        button.setBackground(roundRect(primary ? Color.rgb(21, 94, 239) : Color.rgb(234, 240, 255),
                dp(16), primary ? Color.rgb(21, 94, 239) : Color.rgb(195, 211, 255), dp(1)));
        return button;
    }

    private GradientDrawable roundRect(int fill, int radius, int stroke, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(strokeWidth, stroke);
        return drawable;
    }

    private void addParagraph(LinearLayout root, String value) {
        TextView paragraph = text(value, 16, Color.rgb(52, 64, 84), false);
        paragraph.setLineSpacing(dp(3), 1.0f);
        addTop(root, paragraph, 10);
    }

    private void addTop(LinearLayout parent, View child, int marginDp) {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(marginDp);
        parent.addView(child, params);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
