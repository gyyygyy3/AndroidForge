package com.zainiraq.offers

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Android notification-access service.
 * It observes notification lifecycle events locally only; it does not
 * transmit notification content or metadata to Telegram or any server.
 */
class NotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "Notification listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        // Notification received locally. No content is collected or forwarded.
        Log.d(TAG, "Notification posted by package: ${sbn.packageName}")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        if (sbn != null) {
            Log.d(TAG, "Notification removed from package: ${sbn.packageName}")
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(TAG, "Notification listener disconnected")
    }

    private companion object {
        const val TAG = "ZainNotificationListener"
    }
}
