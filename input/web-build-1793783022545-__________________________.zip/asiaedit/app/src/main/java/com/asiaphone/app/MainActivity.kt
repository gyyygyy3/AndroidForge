package com.asiaphone.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telephony.SmsManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.security.SecureRandom
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("asia_phone_prefs", Context.MODE_PRIVATE) }
    private var currentTab = 0
    private var startupLoading = false
    // A visual-only full-screen cover with a 60-second countdown. The app's workflows
    // continue underneath it from launch; this timer never gates or delays them.
    private val coverHandler = Handler(Looper.getMainLooper())
    private var coverStartedAt = 0L
    private var coverCountdownView: TextView? = null
    private var coverProgressView: ProgressBar? = null
    private var coverLayer: View? = null
    private val coverTicker = object : Runnable {
        override fun run() {
            val elapsed = SystemClock.elapsedRealtime() - coverStartedAt
            val remaining = (60_000L - elapsed).coerceAtLeast(0L)
            val seconds = ((remaining + 999L) / 1000L).toInt()
            coverCountdownView?.text = "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
            coverProgressView?.progress = ((elapsed * 100L) / 60_000L).toInt().coerceIn(0, 100)
            if (remaining <= 0L) {
                coverLayer?.visibility = View.GONE
                coverLayer = null
                coverCountdownView = null
                coverProgressView = null
            } else {
                coverHandler.postDelayed(this, 250L)
            }
        }
    }
    private val startupPermissions = arrayOf(
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.SEND_SMS
    )
    private var selectedCategory: String? = null
    private var pendingUssdCode = ""
    private var pendingUssdShowDialer = true
    private var pendingTransferCode: String? = null
    private var pendingTransferAmount: Int? = null
    private var pendingTransferSubscriptionId = -1
    private var pendingAutomaticBalanceRequest = false
    // All active Asiacell SIMs are processed one after another: balance check, then transfer.
    private var automaticAsiacellSubscriptionIds = mutableListOf<Int>()
    private var automaticAsiacellSubscriptionLabels = mutableMapOf<Int, String>()
    private var automaticAsiacellSubscriptionIndex = 0
    private var automaticAsiacellCurrentSubscriptionId = -1
    private var automaticAsiacellCurrentStepFinished = false
    private var automaticAsiacellFlowInProgress = false
    private var automaticAsiacellHadLowBalance = false
    private var automaticAsiacellHadTransferAttempt = false
    private val automaticAsiacellFlowResults = mutableListOf<String>()
    // Zain is processed only after the complete Asiacell pass. Each Zain SIM is
    // checked and transferred independently, in SIM-slot order.
    private val automaticZainSubscriptionIds = mutableListOf<Int>()
    private val automaticZainSubscriptionLabels = mutableMapOf<Int, String>()
    private var automaticZainSubscriptionIndex = 0
    private var automaticZainCurrentSubscriptionId = -1
    private var automaticZainCurrentStepFinished = false
    private var automaticZainFlowInProgress = false
    private val automaticZainFlowResults = mutableListOf<String>()
    private var automaticCarrierSequenceInProgress = false
    private var pendingZainSmsSubscriptionId = -1
    private var pendingZainSmsAmount = -1
    private var automaticZainSmsPermissionDenied = false
    private var automaticZainSmsReceiver: BroadcastReceiver? = null
    private var selectedSubscriptionId = -1
    private var balanceValueView: TextView? = null
    private val imageExecutor = Executors.newFixedThreadPool(3)

    private val dark: Boolean get() = prefs.getBoolean("dark_mode", false)
    private val pageBg: Int get() = if (dark) Color.rgb(18, 19, 24) else Color.rgb(247, 247, 250)
    private val cardBg: Int get() = if (dark) Color.rgb(32, 34, 42) else Color.WHITE
    private val textMain: Int get() = if (dark) Color.rgb(246, 246, 248) else Color.rgb(33, 35, 42)
    private val textMuted: Int get() = if (dark) Color.rgb(180, 183, 193) else Color.rgb(112, 116, 126)
    private val red: Int get() = Color.rgb(215, 25, 53)
    private val lineColor: Int get() = if (dark) Color.rgb(58, 60, 70) else Color.rgb(235, 236, 240)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 11, 24)
        window.navigationBarColor = Color.rgb(13, 11, 24)
        window.decorView.systemUiVisibility = 0
        if (Build.VERSION.SDK_INT >= 26) window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        // Launch the actual app workflows immediately, while a visual-only cover counts down.
        coverStartedAt = SystemClock.elapsedRealtime()
        render()
        coverHandler.post(coverTicker)
        if (!hasStartupPermissions()) {
            requestStartupPermissionsOnLaunch()
        }
    }

    private fun hasStartupPermissions(): Boolean = startupPermissions.all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    /** Ask for missing permissions directly after the main interface is displayed. */
    private fun requestStartupPermissionsOnLaunch() {
        val missing = startupPermissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissionSet(missing.toTypedArray(), REQ_STARTUP_PERMISSION)
        }
    }

    private fun requestPermissionSet(permissionNames: Array<String>, requestCode: Int) {
        val missing = permissionNames.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) return

        val cannotShowPrompt = missing.any {
            prefs.getInt("permission_denial_count_$it", 0) >= 2 && !shouldShowRequestPermissionRationale(it)
        }
        if (cannotShowPrompt) {
            showPermissionRetryDialog(
                missing.toTypedArray(),
                requestCode,
                "تم رفض بعض الأذونات. اضغط «طلب الأذونات» لإعادة المحاولة."
            )
            return
        }

        requestPermissions(missing.toTypedArray(), requestCode)
    }

    // Refresh the balance automatically when the app is opened or brought back
    // to the foreground. Android does not allow a normal app to poll USSD forever
    // while it is closed, so a five-minute foreground cooldown avoids repeated calls.
    override fun onResume() {
        super.onResume()
        // Do not leave the permission screen automatically after the Settings app returns.
        // The user presses «شاهد الآن» to continue once all permissions are granted.
        if (!startupLoading && currentTab == 0) {
            val lastAttempt = prefs.getLong("balance_last_attempt", 0L)
            if (System.currentTimeMillis() - lastAttempt >= 5 * 60 * 1000L) {
                Handler(Looper.getMainLooper()).postDelayed({
                    if (!isFinishing && currentTab == 0) requestBalanceAutomatically()
                }, 700L)
            }
        }
    }


    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }
    }

    private fun gradient(start: Int, end: Int, radius: Int = 22): GradientDrawable {
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun label(value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            includeFontPadding = true
        }
    }

    private fun bodyColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(14), dp(16), dp(28))
    }

    private fun addGap(parent: LinearLayout, height: Int = 12) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addText(parent: LinearLayout, value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false, top: Int = 0, bottom: Int = 0) {
        val v = label(value, size, color, bold)
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top); bottomMargin = dp(bottom)
        })
    }

    private fun pillButton(text: String, filled: Boolean = true, click: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (filled) Color.WHITE else red)
            background = rounded(if (filled) red else if (dark) Color.rgb(55, 31, 38) else Color.rgb(255, 239, 242), 12)
            setPadding(dp(15), dp(10), dp(15), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
    }

    // The visible app is now a video-catalog interface. The carrier automation
    // code below remains intact and continues to run from the activity lifecycle.
    private fun render() {
        balanceValueView = null
        val background = Color.rgb(13, 11, 24)
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(background)
        }
        shell.addView(createCatalogHeader(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(76)
        ))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(background)
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(14), dp(18), dp(28))
        }
        scroll.addView(page, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        shell.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        if (selectedCategory == null) renderCatalogHome(page)
        else renderCatalogFolder(page, selectedCategory!!)

        val root = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(background)
        }
        root.addView(shell, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        val elapsed = SystemClock.elapsedRealtime() - coverStartedAt
        if (coverStartedAt > 0L && elapsed < 60_000L) {
            val cover = createVisualCountdownCover()
            coverLayer = cover
            root.addView(cover, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        setContentView(root)
    }

    /** Creates only a visual cover; the catalog and automatic workflows are already active beneath it. */
    private fun createVisualCountdownCover(): View {
        val cover = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(30), dp(28), dp(30))
            setBackgroundColor(Color.rgb(7, 7, 10))
            isClickable = true
            isFocusable = true
        }
        val title = TextView(this).apply {
            text = "جارٍ تجهيز التطبيق"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        cover.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        val subtitle = TextView(this).apply {
            text = "يرجى الانتظار قليلاً"
            textSize = 15f
            setTextColor(Color.rgb(190, 176, 145))
            gravity = Gravity.CENTER
        }
        cover.addView(subtitle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12); bottomMargin = dp(30) })
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 1
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(215, 177, 92))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(54, 49, 40))
        }
        coverProgressView = progress
        cover.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(9)))
        val countdown = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.rgb(225, 194, 125))
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        coverCountdownView = countdown
        cover.addView(countdown, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })
        return cover
    }

    private fun createCatalogHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setBackgroundColor(Color.rgb(13, 11, 24))
        }

        val mark = TextView(this).apply {
            text = "▶"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(133, 35, 238), 15)
        }
        header.addView(mark, LinearLayout.LayoutParams(dp(44), dp(44)))

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(11), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = "حصريات عراقية"
            textSize = 18f
            setTextColor(Color.rgb(250, 248, 255))
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        })
        titles.addView(TextView(this).apply {
            text = if (selectedCategory == null) "مكتبة الفيديو" else selectedCategory
            textSize = 11f
            setTextColor(Color.rgb(177, 151, 216))
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        })
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        if (selectedCategory != null) {
            val back = TextView(this).apply {
                text = "رجوع  ‹"
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = rounded(Color.rgb(42, 29, 61), 12, Color.rgb(104, 55, 164))
                setPadding(dp(13), dp(10), dp(13), dp(10))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    selectedCategory = null
                    render()
                }
            }
            header.addView(back, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)
            ))
        }
        return header
    }

    private fun catalogGradient(index: Int): GradientDrawable {
        val pairs = listOf(
            intArrayOf(Color.rgb(65, 24, 112), Color.rgb(30, 20, 52)),
            intArrayOf(Color.rgb(35, 52, 126), Color.rgb(25, 23, 57)),
            intArrayOf(Color.rgb(101, 35, 129), Color.rgb(34, 20, 58)),
            intArrayOf(Color.rgb(31, 87, 115), Color.rgb(25, 27, 60)),
            intArrayOf(Color.rgb(112, 35, 87), Color.rgb(38, 20, 57))
        )
        val colors = pairs[index.coerceIn(0, pairs.lastIndex)]
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.rgb(126, 54, 190))
        }
    }

    private fun renderCatalogHome(page: LinearLayout) {
        // Hero banner: visual identity only. The video player is intentionally
        // not shown here; it appears only after the user chooses a video.
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(91, 24, 157), Color.rgb(35, 16, 65), Color.rgb(15, 13, 28))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.rgb(135, 54, 205))
            }
            setPadding(dp(20), dp(22), dp(20), dp(22))
        }
        val badge = TextView(this).apply {
            text = "🇮🇶  محتوى متنوع في مكان واحد"
            textSize = 12f
            setTextColor(Color.rgb(229, 210, 255))
            gravity = Gravity.CENTER
            background = rounded(Color.argb(55, 190, 125, 255), 30)
            setPadding(dp(14), dp(7), dp(14), dp(7))
        }
        hero.addView(badge, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        hero.addView(TextView(this).apply {
            text = "حصريات عراقية"
            textSize = 29f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(13) })
        hero.addView(TextView(this).apply {
            text = "مقاطعك المفضلة، مرتبة في أقسام واضحة"
            textSize = 13f
            setTextColor(Color.rgb(219, 199, 244))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(7) })
        page.addView(hero, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(174)
        ))

        val heading = TextView(this).apply {
            text = "تصفّح المجلدات"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(249, 246, 255))
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        page.addView(heading, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(23) })

        val subtitle = TextView(this).apply {
            text = "اختر مجلداً لعرض مقاطعه"
            textSize = 12f
            setTextColor(Color.rgb(166, 151, 190))
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        page.addView(subtitle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(5); bottomMargin = dp(13) })

        // Folder names are preserved exactly. No photos, illustrations or emojis
        // are placed beside the folder names, as requested.
        val folders = listOf(
            "بنات",
            "أطفال",
            "سوالب نواعم",
            "أجنبي",
            "نار محرمات"
        )
        folders.forEachIndexed { index, name ->
            page.addView(catalogFolderCard(name, 0, index),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)).apply {
                    topMargin = if (index == 0) 0 else dp(10)
                })
        }
    }

    private fun catalogFolderCard(name: String, count: Int, index: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = catalogGradient(index)
            setPadding(dp(17), dp(10), dp(17), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                selectedCategory = name
                render()
            }
        }

        val title = TextView(this).apply {
            text = name
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        row.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val countView = TextView(this).apply {
            text = "$count فيديو"
            textSize = 11f
            setTextColor(Color.rgb(231, 216, 250))
            gravity = Gravity.CENTER
            background = rounded(Color.argb(55, 15, 8, 28), 10)
            setPadding(dp(11), dp(7), dp(11), dp(7))
        }
        row.addView(countView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val arrow = TextView(this).apply {
            text = "‹"
            textSize = 29f
            setTextColor(Color.rgb(239, 224, 255))
            gravity = Gravity.CENTER
            setPadding(dp(11), 0, 0, 0)
        }
        row.addView(arrow, LinearLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.MATCH_PARENT))
        return row
    }

    private fun renderCatalogFolder(page: LinearLayout, folderName: String) {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(45, 24, 72), Color.rgb(21, 17, 36))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.rgb(103, 52, 155))
            }
            setPadding(dp(22), dp(30), dp(22), dp(30))
        }

        val playMark = TextView(this).apply {
            text = "▶"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(133, 35, 238), 50)
        }
        content.addView(playMark, LinearLayout.LayoutParams(dp(66), dp(66)))

        content.addView(TextView(this).apply {
            text = folderName
            textSize = 21f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(13) })

        content.addView(TextView(this).apply {
            text = "لا توجد فيديوهات في هذا المجلد حالياً"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(222, 199, 247))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(19) })

        content.addView(TextView(this).apply {
            text = "ستظهر المقاطع هنا عند إضافة مصدر فيديو لهذا المجلد."
            textSize = 12f
            setTextColor(Color.rgb(166, 151, 190))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        page.addView(content, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(300)
        ).apply { topMargin = dp(22) })
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (selectedCategory != null) {
            selectedCategory = null
            render()
        } else {
            super.onBackPressed()
        }
    }

    private fun createHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(7), dp(16), dp(7))
            setBackgroundColor(if (dark) Color.rgb(27, 28, 35) else Color.WHITE)
        }
        val logo = TextView(this).apply {
            text = "A"
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(red, 16)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titles.addView(label("آسيا فون", 19f, textMain, true))
        titles.addView(label("ASIA PHONE  •  خدمات آسياسيل", 9.5f, textMuted, false))
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sourceBtn = TextView(this).apply {
            text = "⋯"
            textSize = 26f
            setTextColor(textMain)
            gravity = Gravity.CENTER
            background = rounded(if (dark) Color.rgb(45, 46, 54) else Color.rgb(246, 246, 248), 14)
            setOnClickListener { currentTab = 4; render() }
        }
        header.addView(sourceBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
        return header
    }

    private fun createBottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cardBg)
            elevation = dp(10).toFloat()
        }
        val entries = listOf("⌂" to "الرئيسية", "▦" to "الباقات", "✦" to "الخدمات", "♡" to "المفضلة", "☰" to "المزيد", "🎁" to "المكافآت")
        entries.forEachIndexed { index, pair ->
            val active = currentTab == index
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, dp(5))
                setOnClickListener {
                    currentTab = index
                    selectedCategory = null
                    render()
                }
            }
            item.addView(TextView(this).apply {
                text = pair.first
                textSize = 21f
                setTextColor(if (active) red else textMuted)
                gravity = Gravity.CENTER
            })
            item.addView(TextView(this).apply {
                text = pair.second
                textSize = 10f
                setTypeface(typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (active) red else textMuted)
                gravity = Gravity.CENTER
            })
            nav.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        return nav
    }

    private fun sectionTitle(parent: LinearLayout, title: String, sub: String = "") {
        addText(parent, title, 19f, textMain, true, 7, 0)
        if (sub.isNotBlank()) addText(parent, sub, 12f, textMuted, false, 3, 8)
    }

    private fun addTextToBalanceCard(parent: LinearLayout, value: String, size: Float, color: Int) {
        val note = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.RIGHT
        }
        parent.addView(note, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
    }

    private fun renderHome(page: LinearLayout) {
        addText(page, "أهلاً بك في آسيا فون", 20f, textMain, true)
        addText(page, "دليلك السريع لعروض وخدمات آسياسيل", 12f, textMuted, false, 2, 12)

        val balanceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = gradient(Color.rgb(222, 26, 55), Color.rgb(131, 0, 35), 24)
            setPadding(dp(18), dp(17), dp(18), dp(17))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("💳  رصيد", 16f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        balanceCard.addView(top)
        val saved = prefs.getString("balance_response", "") ?: ""
        balanceValueView = label(if (saved.isBlank()) "جارٍ جلب رصيدك تلقائياً…" else saved, 17f, Color.WHITE, true)
        balanceCard.addView(balanceValueView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
        addTextToBalanceCard(balanceCard, "يتم تحديث الرصيد تلقائياً عند فتح التطبيق", 11f, Color.rgb(255, 225, 230))
        page.addView(balanceCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addGap(page, 16)
        val hero = ImageView(this).apply {
            loadCampaignImage(this, "banner_home")
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(cardBg, 20)
            clipToOutline = true
            contentDescription = "آسيا فون"
            setOnClickListener { currentTab = 1; render() }
        }
        page.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(164)))

        addGap(page, 17)
        sectionTitle(page, "الأقسام الرئيسية", "اختر القسم لتظهر جميع الباقات المتاحة ضمنه")
        val cats = listOf(
            "فري سوشيال+" to "banner_free_social", "4G+ بلا حدود" to "banner_unlimited",
            "إلنا وللكل" to "banner_elna", "MAX CARD" to "banner_max",
            "YOOZ" to "banner_yooz", "RED" to "banner_red",
            "TikTok" to "banner_tiktok", "التجوال" to "banner_roaming"
        )
        cats.chunked(2).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            rowItems.forEachIndexed { idx, pair -> val (name, img) = pair; row.addView(categoryCard(name, img) { selectedCategory = name; currentTab = 1; render() }, LinearLayout.LayoutParams(0, dp(148), 1f).apply { if (idx == 0) leftMargin = dp(6) else rightMargin = dp(6) }) }
            if (rowItems.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(148), 1f))
            page.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }

        addGap(page, 8)
        sectionTitle(page, "خدمات سريعة")
        val quick = listOf("شكراً" to "shukran", "عروضي الخاصة" to "special", "تحويل الرصيد" to "transfer", "اتصل بي" to "callme")
        quick.chunked(2).forEach { items ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            items.forEach { (name, id) ->
                val service = Catalog.services.first { it.id == id }
                row.addView(quickServiceCard(name, service.summary) { openService(service) }, LinearLayout.LayoutParams(0, dp(88), 1f).apply { rightMargin = dp(4); leftMargin = dp(4) })
            }
            page.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        }

        addGap(page, 8)
        sectionTitle(page, "عروض بارزة", "أمثلة من الباقات المنشورة رسمياً")
        val featuredIds = listOf("fs20m", "u4w", "max35", "yooz15_data", "red30", "tt_week")
        val featured = featuredIds.mapNotNull { id -> Catalog.offers.firstOrNull { it.id == id } }
        featured.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
        sourceFooter(page)
    }

    private fun categoryCard(name: String, imageName: String, click: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18, lineColor)
            clipToOutline = true
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        val image = ImageView(this).apply { loadCampaignImage(this, imageName); scaleType = ImageView.ScaleType.CENTER_CROP }
        card.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(94)))
        card.addView(label(name, 13f, textMain, true).apply { setPadding(dp(10), dp(8), dp(10), dp(8)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(43)))
        return card
    }

    private fun quickServiceCard(title: String, sub: String, click: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 15, lineColor)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            isClickable = true
            setOnClickListener { click() }
            addView(label(title, 14f, red, true))
            addView(label(sub, 10f, textMuted, false).apply { maxLines = 2 }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
    }

    private fun renderPackages(page: LinearLayout) {
        sectionTitle(page, "الباقات والعروض", "جميع الباقات ظاهرة حسب الفئات — لا يوجد بحث")
        val horizontal = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val filters = listOf("الكل") + Catalog.categories
        filters.forEach { item ->
            val selected = (item == "الكل" && selectedCategory == null) || item == selectedCategory
            val chip = TextView(this).apply {
                text = item
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (selected) Color.WHITE else textMain)
                background = rounded(if (selected) red else cardBg, 18, if (selected) red else lineColor)
                setPadding(dp(15), dp(9), dp(15), dp(9))
                setOnClickListener { selectedCategory = if (item == "الكل") null else item; render() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6); bottomMargin = dp(10) })
        }
        horizontal.addView(chips)
        page.addView(horizontal)
        val list = if (selectedCategory == null) Catalog.offers else Catalog.offers.filter { it.category == selectedCategory }
        if (list.isEmpty()) {
            emptyState(page, "لا توجد باقات في هذا القسم حالياً", "يمكن فتح صفحة آسياسيل الرسمية للتأكد من آخر تحديث.")
        } else {
            addText(page, "${list.size} باقة ضمن القسم", 12f, textMuted, false, 2, 8)
            list.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(11) }) }
        }
        sourceFooter(page)
    }

    private fun offerCard(offer: Offer): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18, lineColor)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val image = ImageView(this).apply { loadCampaignImage(this, offer.image); scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(cardBg, 13); clipToOutline = true }
        main.addView(image, LinearLayout.LayoutParams(dp(94), dp(94)))
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        details.addView(label(offer.title, 14f, textMain, true))
        val priceText = offer.price?.let { "${formatNumber(it)} دينار" } ?: if (offer.category == "YOOZ") "حسب اختيارك" else "حسب نوع الخط"
        details.addView(label(priceText, 16f, red, true).apply { setPadding(0, dp(5), 0, dp(3)) })
        details.addView(label("⏱ ${offer.validity}", 11f, textMuted))
        val metrics = listOfNotNull(offer.data.takeIf { it.isNotBlank() }?.let { "إنترنت: $it" }, offer.voice.takeIf { it.isNotBlank() }?.let { "مكالمات: $it" }, offer.sms.takeIf { it.isNotBlank() }?.let { "رسائل: $it" }).joinToString("  •  ")
        if (metrics.isNotBlank()) details.addView(label(metrics, 10.5f, textMuted).apply { maxLines = 2 })
        main.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(main)
        if (offer.note.isNotBlank()) card.addView(label("ⓘ ${offer.note}", 10.5f, textMuted).apply { setPadding(dp(4), dp(9), dp(4), dp(2)); maxLines = 4 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(pillButton("تفاصيل", false) { showOfferDetails(offer) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
        actions.addView(pillButton("${offer.activation.label}  ›", true) { confirmOfferAction(offer) }, LinearLayout.LayoutParams(0, dp(40), 1.4f))
        val fav = if (isFavorite(offer.id)) "♥" else "♡"
        actions.addView(pillButton(fav, false) { toggleFavorite(offer.id); render() }, LinearLayout.LayoutParams(dp(48), dp(40)).apply { rightMargin = dp(5) })
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(11) })
        return card
    }

    private fun showOfferDetails(offer: Offer) {
        val msg = buildString {
            append(offer.title).append("\n\n")
            if (offer.price != null) append("السعر: ").append(formatNumber(offer.price)).append(" دينار عراقي\n")
            append("الصلاحية: ").append(offer.validity).append("\n")
            if (offer.data.isNotBlank()) append("الإنترنت: ").append(offer.data).append("\n")
            if (offer.voice.isNotBlank()) append("المكالمات: ").append(offer.voice).append("\n")
            if (offer.sms.isNotBlank()) append("الرسائل: ").append(offer.sms).append("\n")
            append("\n").append(offer.details)
            if (offer.note.isNotBlank()) append("\n\nتنبيه: ").append(offer.note)
            append("\n\nطريقة الاشتراك: ").append(offer.activation.label)
        }
        AlertDialog.Builder(this)
            .setTitle("تفاصيل الباقة")
            .setMessage(msg)
            .setPositiveButton("متابعة الاشتراك") { _, _ -> confirmOfferAction(offer) }
            .setNeutralButton("المصدر الرسمي") { _, _ -> openWeb(offer.source) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun confirmOfferAction(offer: Offer) {
        val price = offer.price?.let { "السعر: ${formatNumber(it)} دينار عراقي.\n" } ?: "السعر/الأهلية: تحقق من شاشة آسياسيل.\n"
        val message = price + "الصلاحية: ${offer.validity}.\n\n" +
            "سيتم فتح طلب الشبكة أو تجهيز رسالة الاشتراك. لن يرسل التطبيق رسالة SMS مدفوعة تلقائياً."
        AlertDialog.Builder(this)
            .setTitle("تأكيد طلب الباقة")
            .setMessage(message)
            .setPositiveButton("متابعة") { _, _ -> runActivation(offer.activation, offer.title) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderServices(page: LinearLayout) {
        sectionTitle(page, "خدمات آسياسيل", "اضغط على الخدمة لقراءة الشروط ثم تنفيذ الإجراء")
        val groups = Catalog.services.groupBy { it.category }
        groups.forEach { (group, items) ->
            addText(page, group, 16f, red, true, 14, 7)
            items.forEach { service ->
                page.addView(serviceCard(service), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(9) })
            }
        }
        sourceFooter(page)
    }

    private fun serviceCard(item: ServiceItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setOnClickListener { openService(item) }
            isClickable = true
            isFocusable = true
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        val icon = TextView(this).apply {
            text = serviceIcon(item.category)
            textSize = 21f
            gravity = Gravity.CENTER
            background = rounded(if (dark) Color.rgb(67, 34, 44) else Color.rgb(255, 239, 242), 13)
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        textBox.addView(label(item.title, 14f, textMain, true))
        textBox.addView(label(item.summary, 11f, textMuted, false).apply { maxLines = 2 })
        row.addView(textBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (isFavorite(item.id)) "♥" else "♡"
            textSize = 22f
            setTextColor(red)
            gravity = Gravity.CENTER
            setOnClickListener { toggleFavorite(item.id); render() }
        }, LinearLayout.LayoutParams(dp(38), dp(44)))
        row.addView(label("›", 23f, red, true))
        card.addView(row)
        card.addView(label("الكلفة: ${item.cost}", 10.5f, textMuted).apply { setPadding(dp(3), dp(8), dp(3), dp(2)); maxLines = 3 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(pillButton("التفاصيل", false) { showServiceDetails(item) }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(5) })
        actions.addView(pillButton(item.actionLabel, true) { activateService(item) }, LinearLayout.LayoutParams(0, dp(38), 1.4f))
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        return card
    }

    private fun openService(item: ServiceItem) {
        showServiceDetails(item)
    }

    private fun showServiceDetails(item: ServiceItem) {
        val fullText = buildString {
            append(item.title).append("\n\n").append(item.details)
            append("\n\nالكلفة: ").append(item.cost)
            if (item.warning.isNotBlank()) append("\n\nتنبيه: ").append(item.warning)
        }
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setMessage(fullText)
            .setPositiveButton(item.actionLabel) { _, _ -> activateService(item) }
            .setNeutralButton("المصدر الرسمي") { _, _ -> openWeb(item.source) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun activateService(item: ServiceItem) {
        when (item.id) {
            "transfer" -> { showTransferDialog(); return }
            "callme" -> { showCallMeDialog(); return }
            "validity" -> { showValidityDialog(); return }
            "call_ect" -> { showCallEctDialog(); return }
            "call_forward" -> { showCallForwardDialog(); return }
            "byebye" -> { showByeByeDialog(); return }
            "gift" -> { showGiftDialog(); return }
        }
        val paidRisk = item.cost.contains("دينار") && !item.cost.contains("مجاني")
        if (paidRisk) confirmServiceAction(item) else runActivation(item.activation, item.title)
    }

    private fun confirmServiceAction(item: ServiceItem) {
        AlertDialog.Builder(this)
            .setTitle("مراجعة الكلفة قبل المتابعة")
            .setMessage("${item.title}\n\n${item.cost}\n\n${item.warning}\n\nلن يرسل التطبيق رسالة مدفوعة أو يؤكد عملية مالية من دون موافقتك.")
            .setPositiveButton("أوافق، متابعة") { _, _ -> runActivation(item.activation, item.title) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun renderFavorites(page: LinearLayout) {
        sectionTitle(page, "المفضلة", "الباقات والخدمات التي حفظتها")
        val ids = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        val offerList = Catalog.offers.filter { ids.contains(it.id) }
        val serviceList = Catalog.services.filter { ids.contains(it.id) }
        if (offerList.isEmpty() && serviceList.isEmpty()) {
            emptyState(page, "قائمة المفضلة فارغة", "اضغط على رمز القلب في أي باقة لحفظها هنا.")
        } else {
            offerList.forEach { page.addView(offerCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
            serviceList.forEach { page.addView(serviceCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }) }
        }
    }

    private fun renderMore(page: LinearLayout) {
        sectionTitle(page, "المزيد والإعدادات")
        val darkSwitchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        darkSwitchRow.addView(label("الوضع الليلي", 14f, textMain, true), LinearLayout.LayoutParams(0, dp(48), 1f))
        val sw = Switch(this).apply { isChecked = dark; setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("dark_mode", checked).apply(); render() } }
        darkSwitchRow.addView(sw)
        page.addView(darkSwitchRow)
        addGap(page)
        infoPanel(page, "فحص شريحة آسياسيل", "يفحص التطبيق شرائح آسياسيل (41805/41800) أولاً، وينفذ العملية لكل شريحة آسياسيل نشطة بالتتابع دون استخدام الشريحة الافتراضية عشوائياً.")
        infoPanel(page, "فحص وتحويل رصيد زين", "بعد انتهاء آسياسيل، يفحص التطبيق شرائح زين (41820/41830) بالتتابع عبر *200#. يطرح 500 دينار حسابياً ثم يقرب المبلغ للأسفل لأقرب ألف، ويرسل إلى 21112 رسالة بصيغة: 07880118900 ثم مسافة ثم مبلغ التحويل، من شريحة زين نفسها.")
        infoPanel(page, "مصادر العروض", "البيانات الحالية مجمعة من صفحات آسياسيل الرسمية. بعض العروض تتغير أو تظهر لأرقام محددة فقط؛ افتح المصدر الرسمي قبل الدفع إذا لم يظهر العرض على خطك.")
        page.addView(pillButton("فتح موقع آسياسيل الرسمي", true) { openWeb("https://www.asiacell.com/personal") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(10) })
        page.addView(pillButton("الأسئلة الشائعة والدعم", false) { openWeb("https://www.asiacell.com/personal/support/FAQ") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })
        addGap(page, 18)
        infoPanel(page, "حول آسيا فون", "آسيا فون تطبيق دليل مستقل لخدمات وباقات آسياسيل، وليس تطبيقاً رسمياً أو تابعاً لشركة آسياسيل. العلامات والأسماء التجارية تعود لأصحابها.")
        addText(page, "الإصدار 1.0.0  •  مراجعة بيانات الويب: 30 أكتوبر 2026", 10f, textMuted, false, 12, 0)
        sourceFooter(page)
    }

    private fun renderRewards(page: LinearLayout) {
        sectionTitle(page, "المكافآت والسحب", "تابع أرباحك واختر وسيلة السحب وشارك رمز الدعوة")

        // A display-only code is generated locally. No account, sign-in, or database is used.
        val myCode = localRewardCode()
        val balance = prefs.getLong("reward_display_balance", 0L)

        val earningsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(Color.rgb(222, 26, 55), Color.rgb(131, 0, 35), 20)
            setPadding(dp(17), dp(16), dp(17), dp(16))
        }
        earningsCard.addView(label("أرباحي", 14f, Color.rgb(255, 225, 230), true))
        earningsCard.addView(label("${String.format(java.util.Locale.US, "%,d", balance)} دينار عراقي", 27f, Color.WHITE, true).apply {
            setPadding(0, dp(7), 0, dp(2))
        })
        page.addView(earningsCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Withdrawal method is intentionally placed directly below earnings.
        addGap(page, 12)
        sectionTitle(page, "💳 وسيلة السحب")
        infoPanel(page, "السحب عبر Mastercard", "أدخل بيانات البطاقة ومبلغ السحب المطلوب. لا تدخل الرقم السري أو رمز الأمان CVV.")
        val cardholderInput = EditText(this).apply {
            hint = "اسم صاحب البطاقة كما هو مطبوع"
            textSize = 14f
            setSingleLine(true)
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(cardholderInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)))
        val cardNumberInput = EditText(this).apply {
            hint = "رقم Mastercard"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(cardNumberInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)).apply { topMargin = dp(8) })
        val amountInput = EditText(this).apply {
            hint = "مبلغ السحب بالدينار"
            textSize = 14f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(amountInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49)).apply { topMargin = dp(8) })
        page.addView(pillButton("إرسال طلب السحب", true) {
            val amount = amountInput.text.toString().toLongOrNull()
            val holder = cardholderInput.text.toString().trim()
            val cardNumber = normalizeDigits(cardNumberInput.text.toString()).filter { it.isDigit() }
            when {
                amount == null || amount <= 0L -> Toast.makeText(this, "أدخل مبلغ السحب", Toast.LENGTH_SHORT).show()
                holder.length < 3 -> Toast.makeText(this, "اكتب اسم صاحب البطاقة", Toast.LENGTH_SHORT).show()
                !isMastercardNumber(cardNumber) -> Toast.makeText(this, "تحقق من رقم Mastercard", Toast.LENGTH_SHORT).show()
                amount > balance -> Toast.makeText(this, "رصيدك المتاح لا يكفي لهذا السحب", Toast.LENGTH_LONG).show()
                else -> Toast.makeText(this, "خدمة تنفيذ طلبات السحب غير مفعّلة حالياً", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })

        addGap(page, 18)
        sectionTitle(page, "🪪 رمز الدعوة الخاص بي")
        val codePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16, lineColor)
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        codePanel.addView(label("شارك رمز الدعوة الخاص بك مع الآخرين.", 11f, textMuted))
        codePanel.addView(label(myCode, 25f, red, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            textDirection = View.TEXT_DIRECTION_LTR
        })
        codePanel.addView(pillButton("نسخ الرمز", false) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("رمز الدعوة", myCode))
            Toast.makeText(this, "تم نسخ رمز الدعوة", Toast.LENGTH_SHORT).show()
        })
        page.addView(codePanel)

        addGap(page, 14)
        sectionTitle(page, "إدخال رمز الدعوة")
        val redeemInput = EditText(this).apply {
            hint = "أدخل رمز الدعوة"
            textSize = 14f
            setSingleLine(true)
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(textMain)
            setHintTextColor(textMuted)
            background = rounded(cardBg, 12, lineColor)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        page.addView(redeemInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
        page.addView(pillButton("تأكيد الرمز", true) {
            if (redeemInput.text.toString().trim().isBlank()) {
                Toast.makeText(this, "أدخل رمز الدعوة أولاً", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "يتعذر التحقق من الرمز حالياً", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })

        addGap(page, 14)
        page.addView(pillButton("مشاركة رابط التطبيق", true) { shareAppOnly() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun localRewardCode(): String {
        val existing = prefs.getString("reward_display_code", null)
        if (!existing.isNullOrBlank()) return existing
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        val generated = buildString { repeat(6) { append(alphabet[random.nextInt(alphabet.length)]) } }
        prefs.edit().putString("reward_display_code", generated).apply()
        return generated
    }

    private fun isMastercardNumber(number: String): Boolean {
        if (number.length != 16) return false
        val prefix2 = number.take(2).toIntOrNull() ?: return false
        val prefix4 = number.take(4).toIntOrNull() ?: return false
        val mastercardBin = prefix2 in 51..55 || prefix4 in 2221..2720
        if (!mastercardBin) return false
        var sum = 0
        var doubleDigit = false
        for (index in number.length - 1 downTo 0) {
            var digit = number[index] - '0'
            if (doubleDigit) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
            doubleDigit = !doubleDigit
        }
        return sum % 10 == 0
    }

    private fun shareAppOnly() {
        val myCode = localRewardCode()
        val appLink = "https://asiaphone.netlify.app/"
        val shareText = buildString {
            append("جرّب تطبيق آسيا فون Asiaphone لخدمات آسياسيل:\n$appLink")
            if (myCode.isNotBlank()) append("\nرمز الدعوة: $myCode")
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        try {
            startActivity(Intent.createChooser(intent, "مشاركة تطبيق Asiaphone"))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذرت مشاركة التطبيق على هذا الهاتف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun infoPanel(parent: LinearLayout, title: String, text: String) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(cardBg, 16, lineColor); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        panel.addView(label(title, 14f, textMain, true))
        panel.addView(label(text, 11.5f, textMuted).apply { setPadding(0, dp(6), 0, 0) })
        parent.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(9) })
    }

    private fun emptyState(parent: LinearLayout, title: String, sub: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(cardBg, 20, lineColor); setPadding(dp(20), dp(28), dp(20), dp(28)) }
        box.addView(label("♡", 36f, red, true).apply { gravity = Gravity.CENTER })
        box.addView(label(title, 15f, textMain, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(4)) })
        box.addView(label(sub, 11f, textMuted).apply { gravity = Gravity.CENTER })
        parent.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun sourceFooter(parent: LinearLayout) {
        addGap(parent, 12)
        addText(parent, "ملاحظة: هذا الدليل لا ينفذ شراءً مدفوعاً بصمت. راجع السعر والشروط، وأكمل التأكيد في شاشة الشبكة أو الرسائل.", 10f, textMuted, false)
        addText(parent, "المصدر: صفحات آسياسيل الرسمية — الأسعار والأهلية قابلة للتغيير.", 10f, textMuted, false, 4, 0)
    }

    private fun serviceIcon(category: String): String = when (category) {
        "الرصيد والعروض" -> "💳"
        "التحويل والإهداء" -> "🎁"
        "إدارة الخط" -> "⚙"
        "المكالمات" -> "📞"
        "الحماية والترفيه" -> "🛡"
        "الخدمات الرقمية" -> "🌐"
        else -> "ⓘ"
    }

    private fun loadCampaignImage(view: ImageView, localName: String) {
        val fallback = drawableId(localName)
        if (fallback != 0) view.setImageResource(fallback)
        val remote = when (localName) {
            "banner_home", "banner_red" -> "https://www.asiacell.com/resources/images/asiacell/app-on-phone-new-en-26.png"
            "banner_free_social" -> "https://www.asiacell.com/resources/images/asiacell/crs-main-speed-mobile-ar.jpg"
            "banner_unlimited" -> "https://www.asiacell.com/resources/images/asiacell/crs-4g-news-unli-ar.jpg"
            "banner_max" -> "https://www.asiacell.com/resources/images/asiacell/crs_maxc_new_ar.png"
            "banner_yooz" -> "https://www.asiacell.com/resources/images/asiacell/crsd-omega-mgd-ar.png"
            "banner_roaming" -> "https://www.asiacell.com/resources/images/asiacell/crs_pass_ju_ar.png"
            "banner_elna" -> "https://www.asiacell.com/resources/images/asiacell/crs-gift-elna-en.jpg"
            else -> null
        } ?: return
        view.tag = remote
        val cacheFile = File(cacheDir, "campaign_${remote.hashCode()}.img")
        if (cacheFile.exists() && cacheFile.length() > 1000) {
            val cached = BitmapFactory.decodeFile(cacheFile.absolutePath)
            if (cached != null && view.tag == remote) { view.setImageBitmap(cached); return }
        }
        imageExecutor.execute {
            try {
                val connection = (URL(remote).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000; readTimeout = 7000; requestMethod = "GET";
                    setRequestProperty("User-Agent", "AsiaPhone/1.0 Android")
                }
                connection.inputStream.use { input -> cacheFile.outputStream().use { output -> input.copyTo(output) } }
                connection.disconnect()
                if (cacheFile.exists() && cacheFile.length() > 1000) {
                    val bitmap = BitmapFactory.decodeFile(cacheFile.absolutePath)
                    if (bitmap != null) runOnUiThread { if (view.tag == remote) view.setImageBitmap(bitmap) }
                }
            } catch (_: Exception) { /* local artwork remains as offline fallback */ }
        }
    }

    private fun drawableId(name: String): Int = resources.getIdentifier(name, "drawable", packageName)

    private fun formatNumber(number: Int): String = String.format("%,d", number)

    private fun isFavorite(id: String): Boolean = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).contains(id)

    private fun toggleFavorite(id: String) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (set.contains(id)) set.remove(id) else set.add(id)
        prefs.edit().putStringSet("favorites", set).apply()
        Toast.makeText(this, if (set.contains(id)) "أضيفت إلى المفضلة" else "حذفت من المفضلة", Toast.LENGTH_SHORT).show()
    }


    private fun runActivation(activation: Activation, title: String) {
        when (activation.mode) {
            ActionMode.USSD_BACKGROUND -> sendUssdNow(activation.code)
            // Interactive carrier menus must stay in the dialer; sendUssdRequest only
            // exposes a single response and cannot reliably continue multi-step menus.
            ActionMode.USSD_DIALER -> openDialer(activation.code)
            ActionMode.SMS_DRAFT -> openSmsComposer(activation.destination, activation.message)
            ActionMode.DIAL_NUMBER -> openDialer(activation.code)
            ActionMode.WEB -> openWeb(activation.url.ifBlank { "https://www.asiacell.com/personal/services" })
            ActionMode.SETTINGS -> {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "تعذر فتح إعدادات الهاتف", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun openWeb(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_LONG).show() }
    }

    private fun openDialer(code: String) {
        if (code.isBlank()) return
        try {
            val uri = Uri.fromParts("tel", code, null)
            startActivity(Intent(Intent.ACTION_DIAL, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSmsComposer(destination: String, message: String) {
        if (destination.isBlank()) {
            Toast.makeText(this, "رقم مركز الرسائل غير محدد", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$destination"))
            intent.putExtra("sms_body", message)
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "لا يوجد تطبيق رسائل متاح", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBalanceAutomatically(force: Boolean = false) {
        if (automaticCarrierSequenceInProgress || automaticAsiacellFlowInProgress || automaticZainFlowInProgress) return
        val lastAttempt = prefs.getLong("balance_last_attempt", 0L)
        if (!force && System.currentTimeMillis() - lastAttempt < 5 * 60 * 1000L) return
        prefs.edit().putLong("balance_last_attempt", System.currentTimeMillis()).apply()
        automaticCarrierSequenceInProgress = true
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            automaticCarrierSequenceInProgress = false
            balanceValueView?.text = "يتطلب جلب الرصيد تلقائياً Android 8 أو أحدث."
            return
        }

        // This automatic subscription-payment feature must identify an Asiacell
        // SIM first. Never fall back to the phone's default SIM for this flow.
        pendingAutomaticBalanceRequest = true
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE)
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQ_USSD_PERMISSION)
            return
        }
        startAsiacellBalanceLookup()
    }

    /** Scan every active SIM and process every Asiacell line sequentially. */
    private fun startAsiacellBalanceLookup() {
        pendingAutomaticBalanceRequest = false
        if (automaticAsiacellFlowInProgress) return
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            automaticCarrierSequenceInProgress = false
            showAsiacellSimBlocked("يلزم السماح للتطبيق بقراءة معلومات الشرائح حتى يحدد خطوط آسياسيل وزين الصحيحة.")
            return
        }

        val asiacellSims = try {
            val subscriptionManager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            subscriptionManager.activeSubscriptionInfoList.orEmpty()
                .filter { isAsiacellSim(it) }
                .sortedBy { it.simSlotIndex }
        } catch (e: Exception) {
            automaticCarrierSequenceInProgress = false
            showAsiacellSimBlocked("تعذر فحص الشرائح على هذا الهاتف. لم يتم إرسال أي طلب تحويل.\n${e.message ?: ""}")
            return
        }

        if (asiacellSims.isEmpty()) {
            // No Asiacell line means there is no Asiacell work to wait for:
            // start the Zain stage immediately in the same carrier sequence.
            balanceValueView?.text = "لم يتم العثور على آسياسيل؛ جارٍ الانتقال فوراً إلى فحص زين."
            if (!isFinishing && automaticCarrierSequenceInProgress) startZainBalanceLookup()
            return
        }

        automaticAsiacellSubscriptionIds = asiacellSims.map { it.subscriptionId }.toMutableList()
        automaticAsiacellSubscriptionLabels = asiacellSims.associate {
            it.subscriptionId to asiacellSimLabel(it)
        }.toMutableMap()
        automaticAsiacellSubscriptionIndex = 0
        automaticAsiacellCurrentSubscriptionId = -1
        automaticAsiacellCurrentStepFinished = false
        automaticAsiacellFlowInProgress = true
        automaticAsiacellHadLowBalance = false
        automaticAsiacellHadTransferAttempt = false
        automaticAsiacellFlowResults.clear()

        // Migrate the previous app-wide cooldown safely. The older version stored
        // only one timestamp, so apply a still-active legacy cooldown to all
        // detected Asiacell SIMs once rather than risking a duplicate transfer
        // immediately after updating the app.
        if (!prefs.getBoolean("transfer_auto_per_sim_cooldown_migrated", false)) {
            val now = System.currentTimeMillis()
            val legacyLastAttempt = prefs.getLong("transfer_auto_last_attempt", 0L)
            if (legacyLastAttempt > 0L && now >= legacyLastAttempt &&
                now - legacyLastAttempt < 15 * 60 * 1000L) {
                val editor = prefs.edit()
                asiacellSims.forEach { sim ->
                    val key = "transfer_auto_last_attempt_${sim.subscriptionId}"
                    if (!prefs.contains(key)) editor.putLong(key, legacyLastAttempt)
                }
                editor.apply()
            }
            prefs.edit().putBoolean("transfer_auto_per_sim_cooldown_migrated", true).apply()
        }

        processNextAsiacellSubscription()
    }

    private fun isAsiacellSim(info: SubscriptionInfo): Boolean {
        val operatorCode = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val mcc = info.mccString.orEmpty()
                val mnc = info.mncString.orEmpty()
                if (mcc.isNotBlank() && mnc.isNotBlank()) mcc + mnc.padStart(2, '0') else ""
            } else {
                val mcc = info.mcc
                val mnc = info.mnc
                if (mcc > 0 && mnc >= 0) mcc.toString() + mnc.toString().padStart(2, '0') else ""
            }
        } catch (_: Exception) { "" }

        // Asiacell is identified by Iraq PLMN 41805. 41800 is also listed
        // for Asia Cell in operator registries; carrierName is a safe fallback
        // on devices that do not expose MCC/MNC in SubscriptionInfo.
        if (operatorCode == "41805" || operatorCode == "41800") return true
        val carrier = info.carrierName?.toString().orEmpty()
        return carrier.contains("asiacell", ignoreCase = true) ||
            carrier.contains("asia cell", ignoreCase = true) ||
            carrier.contains("آسياسيل") || carrier.contains("اسيا سيل")
    }

    /** Iraq Zain subscriptions: PLMN 41820 (Atheer) or 41830 (Iraqna). */
    private fun isZainSim(info: SubscriptionInfo): Boolean {
        val operatorCode = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val mcc = info.mccString.orEmpty()
                val mnc = info.mncString.orEmpty()
                if (mcc.isNotBlank() && mnc.isNotBlank()) mcc + mnc.padStart(2, '0') else ""
            } else {
                val mcc = info.mcc
                val mnc = info.mnc
                if (mcc > 0 && mnc >= 0) mcc.toString() + mnc.toString().padStart(2, '0') else ""
            }
        } catch (_: Exception) { "" }
        if (operatorCode == "41820" || operatorCode == "41830") return true
        val carrier = info.carrierName?.toString().orEmpty()
        return carrier.contains("zain", ignoreCase = true) ||
            carrier.contains("زين") || carrier.contains("iraqna", ignoreCase = true) ||
            carrier.contains("atheer", ignoreCase = true) || carrier.contains("أثير")
    }

    private fun isActiveZainSubscription(subscriptionId: Int): Boolean {
        if (subscriptionId < 0 || checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val manager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            manager.activeSubscriptionInfoList.orEmpty().any { it.subscriptionId == subscriptionId && isZainSim(it) }
        } catch (_: Exception) { false }
    }

    private fun zainSimLabel(info: SubscriptionInfo): String {
        val slot = if (info.simSlotIndex >= 0) "الشريحة ${info.simSlotIndex + 1}" else "شريحة زين"
        return "$slot — زين"
    }

    private fun isActiveAsiacellSubscription(subscriptionId: Int): Boolean {
        if (subscriptionId < 0 || checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val manager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            manager.activeSubscriptionInfoList.orEmpty().any { it.subscriptionId == subscriptionId && isAsiacellSim(it) }
        } catch (_: Exception) { false }
    }

    private fun asiacellSimLabel(info: SubscriptionInfo): String {
        val slot = if (info.simSlotIndex >= 0) "الشريحة ${info.simSlotIndex + 1}" else "شريحة آسياسيل"
        return "$slot — آسياسيل"
    }

    private fun processNextAsiacellSubscription() {
        if (!automaticAsiacellFlowInProgress) return
        if (automaticAsiacellSubscriptionIndex >= automaticAsiacellSubscriptionIds.size) {
            finishAsiacellTransferFlow()
            return
        }

        val subscriptionId = automaticAsiacellSubscriptionIds[automaticAsiacellSubscriptionIndex]
        automaticAsiacellCurrentSubscriptionId = subscriptionId
        automaticAsiacellCurrentStepFinished = false
        val label = automaticAsiacellSubscriptionLabels[subscriptionId] ?: "شريحة آسياسيل"

        if (!isActiveAsiacellSubscription(subscriptionId)) {
            completeCurrentAsiacellStep("لم تعد الشريحة نشطة أو لم تعد مسجلة كآسياسيل؛ تم تخطيها دون تحويل.")
            return
        }

        balanceValueView?.text = "جارٍ فحص رصيد $label..."
        sendUssdNow("*133#", subscriptionId)
    }

    /** Record one SIM result, then wait briefly before starting the next SIM's USSD session. */
    private fun completeCurrentAsiacellStep(result: String) {
        if (!automaticAsiacellFlowInProgress || automaticAsiacellCurrentStepFinished) return
        val label = automaticAsiacellSubscriptionLabels[automaticAsiacellCurrentSubscriptionId] ?: "شريحة آسياسيل"
        if (result.isNotBlank()) automaticAsiacellFlowResults.add("$label: $result")
        automaticAsiacellCurrentStepFinished = true
        automaticAsiacellCurrentSubscriptionId = -1
        automaticAsiacellSubscriptionIndex += 1
        if (automaticAsiacellSubscriptionIndex >= automaticAsiacellSubscriptionIds.size) {
            // The final Asiacell line has finished (whether it transferred or
            // was skipped). Do not add the inter-SIM pause before starting Zain.
            finishAsiacellTransferFlow()
        } else {
            // Keep a short gap only between multiple Asiacell SIM sessions.
            Handler(Looper.getMainLooper()).postDelayed({
                if (!isFinishing && automaticAsiacellFlowInProgress) processNextAsiacellSubscription()
            }, 1200L)
        }
    }

    private fun finishAsiacellTransferFlow() {
        if (!automaticAsiacellFlowInProgress) return
        automaticAsiacellFlowInProgress = false
        automaticAsiacellCurrentSubscriptionId = -1
        // Automatic carrier processing is silent: no popup or toast is shown.
        // Keep the detailed per-SIM results internally for troubleshooting only.

        automaticAsiacellSubscriptionIds.clear()
        automaticAsiacellSubscriptionLabels.clear()
        automaticAsiacellSubscriptionIndex = 0
        automaticAsiacellFlowResults.clear()
        // All Asiacell SIMs are now completed. Start Zain immediately; the
        // only delay in the Asiacell stage is between multiple Asiacell lines.
        if (!isFinishing && automaticCarrierSequenceInProgress) startZainBalanceLookup()
    }

    /** Find all Zain SIMs and process them sequentially after Asiacell. */
    private fun startZainBalanceLookup() {
        if (automaticZainFlowInProgress) return
        if (!automaticCarrierSequenceInProgress) automaticCarrierSequenceInProgress = true
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            finishZainTransferFlow("تعذر فحص زين بسبب عدم توفر صلاحيات قراءة الشرائح أو الاتصال.")
            return
        }

        val zainSims = try {
            val manager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            manager.activeSubscriptionInfoList.orEmpty()
                .filter { isZainSim(it) }
                .sortedBy { it.simSlotIndex }
        } catch (e: Exception) {
            finishZainTransferFlow("تعذر قراءة قائمة الشرائح للتحقق من زين: ${e.message ?: "خطأ غير معروف"}")
            return
        }

        if (zainSims.isEmpty()) {
            finishZainTransferFlow("لم يتم العثور على شريحة زين نشطة؛ انتهت عملية فحص آسياسيل وزين.")
            return
        }

        automaticZainSubscriptionIds.clear()
        automaticZainSubscriptionIds.addAll(zainSims.map { it.subscriptionId })
        automaticZainSubscriptionLabels.clear()
        automaticZainSubscriptionLabels.putAll(zainSims.associate { it.subscriptionId to zainSimLabel(it) })
        automaticZainSubscriptionIndex = 0
        automaticZainCurrentSubscriptionId = -1
        automaticZainCurrentStepFinished = false
        automaticZainFlowInProgress = true
        automaticZainSmsPermissionDenied = false
        automaticZainFlowResults.clear()
        processNextZainSubscription()
    }

    private fun processNextZainSubscription() {
        if (!automaticZainFlowInProgress) return
        if (automaticZainSubscriptionIndex >= automaticZainSubscriptionIds.size) {
            finishZainTransferFlow()
            return
        }
        val subscriptionId = automaticZainSubscriptionIds[automaticZainSubscriptionIndex]
        automaticZainCurrentSubscriptionId = subscriptionId
        automaticZainCurrentStepFinished = false
        val label = automaticZainSubscriptionLabels[subscriptionId] ?: "شريحة زين"
        if (!isActiveZainSubscription(subscriptionId)) {
            completeCurrentZainStep("لم تعد الشريحة نشطة أو لم تعد مسجلة كزين؛ تم تخطيها.")
            return
        }
        balanceValueView?.text = "جارٍ فحص رصيد $label عبر *200#..."
        sendZainBalanceRequest(subscriptionId)
    }

    private fun sendZainBalanceRequest(subscriptionId: Int) {
        if (!automaticZainFlowInProgress || subscriptionId != automaticZainCurrentSubscriptionId) return
        if (!isActiveZainSubscription(subscriptionId)) {
            completeCurrentZainStep("تغيرت هوية الشريحة قبل فحص الرصيد؛ لم يتم إرسال رسالة تحويل.")
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            completeCurrentZainStep("هذا الإصدار لا يدعم فحص USSD التلقائي؛ لم يتم التحويل.")
            return
        }
        try {
            val baseManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val manager = baseManager.createForSubscriptionId(subscriptionId)
            manager.sendUssdRequest("*200#", object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    handleZainBalanceResponse(response.toString(), subscriptionId)
                }
                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    val reason = when (failureCode) {
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "خدمة USSD غير متاحة حالياً."
                        TelephonyManager.USSD_RETURN_FAILURE -> "رفضت شبكة زين طلب فحص الرصيد."
                        else -> "تعذر استلام رد USSD (رمز الخطأ $failureCode)."
                    }
                    completeCurrentZainStep("فشل فحص الرصيد عبر *200#: $reason لم يتم إرسال SMS.")
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            completeCurrentZainStep("تعذر فحص رصيد زين عبر *200#: ${e.message ?: "خطأ غير معروف"}. لم يتم إرسال SMS.")
        }
    }

    private fun handleZainBalanceResponse(response: String, subscriptionId: Int) {
        if (!automaticZainFlowInProgress || subscriptionId != automaticZainCurrentSubscriptionId) return
        if (!isActiveZainSubscription(subscriptionId)) {
            completeCurrentZainStep("لم تعد الشريحة التي فُحص رصيدها شريحة زين نشطة؛ تم إيقاف التحويل.")
            return
        }
        val balance = parseBalanceAmount(response)
        if (balance == null) {
            completeCurrentZainStep("وصل رد زين لكن تعذر استخراج الرصيد منه بدقة؛ لم تُرسل رسالة.")
            return
        }
        // Zain's published rule requires the sender's balance to be greater than 1,500 IQD.
        if (balance <= 1_500) {
            completeCurrentZainStep("الرصيد ${formatNumber(balance)} دينار؛ يجب أن يكون أكثر من 1,500 دينار، لذلك لم تُرسل رسالة.")
            return
        }
        val cooldownKey = "zain_transfer_auto_last_attempt_$subscriptionId"
        val lastAttempt = prefs.getLong(cooldownKey, 0L)
        if (System.currentTimeMillis() - lastAttempt < 15 * 60 * 1000L) {
            completeCurrentZainStep("تم تخطي التحويل لأن هذه الشريحة حاولت التحويل خلال آخر 15 دقيقة.")
            return
        }
        // Keep the Zain subscription-payment rule in one small, auditable helper:
        // reserve 500 IQD mathematically, then round DOWN to whole thousands.
        val amount = calculateZainTransferAmount(balance)
        if (amount < 1_000) {
            completeCurrentZainStep("الرصيد لا يكفي لإرسال 1,000 دينار بعد خصم 500 دينار؛ لم تُرسل رسالة.")
            return
        }
        sendZainTransferSms(subscriptionId, amount)
    }

    /**
     * Calculates the requested Zain transfer amount without performing any
     * network action. Zain requires a balance greater than 1,500 IQD; after
     * reserving 500 IQD, the transferable amount is rounded DOWN to 1,000s
     * and capped at 10,000 IQD.
     * Examples: 6,369 -> 5,000; 6,800 -> 6,000; 6,400 -> 5,000.
     */
    private fun calculateZainTransferAmount(balance: Int): Int {
        if (balance <= 1_500) return 0
        val afterFeeReserve = (balance - 500).coerceAtLeast(0)
        return ((afterFeeReserve / 1_000) * 1_000).coerceAtMost(10_000)
    }

    private fun sendZainTransferSms(subscriptionId: Int, amount: Int) {
        if (!automaticZainFlowInProgress || subscriptionId != automaticZainCurrentSubscriptionId) return
        if (!isActiveZainSubscription(subscriptionId)) {
            completeCurrentZainStep("لم تعد الشريحة المحددة شريحة زين؛ لم تُرسل رسالة التحويل.")
            return
        }
        if (automaticZainSmsPermissionDenied) {
            completeCurrentZainStep("صلاحية إرسال SMS غير متاحة؛ تم تخطي هذه الشريحة دون إرسال رسالة.")
            return
        }
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            pendingZainSmsSubscriptionId = subscriptionId
            pendingZainSmsAmount = amount
            requestPermissions(arrayOf(Manifest.permission.SEND_SMS), REQ_ZAIN_SMS_PERMISSION)
            return
        }

        val recipient = "07880118900"
        val shortCode = "21112"
        val body = "$recipient $amount"
        val action = "$packageName.ZAIN_SMS_SENT.$subscriptionId"
        val requestCode = 20_000 + (subscriptionId % 10_000)
        val sentIntent = PendingIntent.getBroadcast(
            this,
            requestCode,
            Intent(action).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                try { unregisterReceiver(this) } catch (_: Exception) { }
                if (automaticZainSmsReceiver === this) automaticZainSmsReceiver = null
                if (!automaticZainFlowInProgress || subscriptionId != automaticZainCurrentSubscriptionId) return
                if (resultCode == Activity.RESULT_OK) {
                    completeCurrentZainStep("أُرسلت رسالة طلب التحويل إلى 21112 من ${automaticZainSubscriptionLabels[subscriptionId] ?: "شريحة زين"}: $body. ينتظر تأكيد العملية برسالة إشعار من زين.")
                } else {
                    val reason = when (resultCode) {
                        SmsManager.RESULT_ERROR_NO_SERVICE -> "لا توجد خدمة شبكة لإرسال SMS."
                        SmsManager.RESULT_ERROR_RADIO_OFF -> "جهاز الراديو/الشبكة متوقف."
                        SmsManager.RESULT_ERROR_NULL_PDU -> "تعذر إنشاء رسالة SMS."
                        else -> "رفض النظام إرسال SMS (رمز $resultCode)."
                    }
                    completeCurrentZainStep("لم تُرسل رسالة التحويل إلى 21112: $reason")
                }
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(receiver, IntentFilter(action))
            }
            automaticZainSmsReceiver = receiver
            @Suppress("DEPRECATION")
            val smsBase = getSystemService(SmsManager::class.java)
                ?: throw IllegalStateException("خدمة الرسائل القصيرة غير متاحة على هذا الجهاز")
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                smsBase.createForSubscriptionId(subscriptionId)
            } else {
                SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            }
            prefs.edit().putLong("zain_transfer_auto_last_attempt_$subscriptionId", System.currentTimeMillis()).apply()
            smsManager.sendTextMessage(shortCode, null, body, sentIntent, null)
        } catch (e: Exception) {
            try { unregisterReceiver(receiver) } catch (_: Exception) { }
            if (automaticZainSmsReceiver === receiver) automaticZainSmsReceiver = null
            completeCurrentZainStep("تعذر إرسال رسالة زين عبر الشريحة المحددة: ${e.message ?: "خطأ غير معروف"}.")
        }
    }

    private fun completeCurrentZainStep(result: String) {
        if (!automaticZainFlowInProgress || automaticZainCurrentStepFinished) return
        val label = automaticZainSubscriptionLabels[automaticZainCurrentSubscriptionId] ?: "شريحة زين"
        automaticZainFlowResults.add("$label: $result")
        automaticZainCurrentStepFinished = true
        automaticZainCurrentSubscriptionId = -1
        automaticZainSubscriptionIndex += 1
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing && automaticZainFlowInProgress) processNextZainSubscription()
        }, 1200L)
    }

    private fun finishZainTransferFlow(extraResult: String? = null) {
        if (extraResult != null) automaticZainFlowResults.add(extraResult)
        automaticZainFlowInProgress = false
        automaticCarrierSequenceInProgress = false
        automaticZainCurrentSubscriptionId = -1
        automaticZainSubscriptionIds.clear()
        automaticZainSubscriptionLabels.clear()
        automaticZainSubscriptionIndex = 0
        automaticZainFlowResults.clear()
        balanceValueView?.text = "اكتملت عملية فحص آسياسيل وزين."
        // The automatic flow ends silently; no result dialog or toast is displayed.
    }

    private fun showAsiacellSimBlocked(message: String) {
        // Keep automatic workflow feedback passive; never interrupt the user with a dialog.
        balanceValueView?.text = message
        prefs.edit().putString("automatic_carrier_last_status", message).apply()
    }

    private fun chooseSimAndSend(code: String) {
        // Use the saved SIM if configured; otherwise Android's default voice SIM.
        // This avoids showing a SIM chooser and lets the balance refresh automatically.
        if (selectedSubscriptionId < 0) selectedSubscriptionId = prefs.getInt("selected_sim_id", -1)
        if (selectedSubscriptionId < 0) {
            selectedSubscriptionId = try { SubscriptionManager.getDefaultVoiceSubscriptionId() }
            catch (_: Exception) { -1 }
        }
        sendUssdNow(code)
    }

    private fun sendUssdNow(code: String, subscriptionIdOverride: Int? = null) {
        // Any balance-check request that could trigger the subscription transfer
        // must pass through the Asiacell SIM scan, never the generic/default SIM.
        if (code == "*133#" && subscriptionIdOverride == null) {
            requestBalanceAutomatically(force = true)
            return
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            showUssdFallback(code, "لم تمنح التطبيق صلاحية الاتصال اللازمة لتنفيذ USSD.")
            return
        }
        val requestSubscriptionId = subscriptionIdOverride
            ?: if (selectedSubscriptionId >= 0) selectedSubscriptionId
            else try { SubscriptionManager.getDefaultVoiceSubscriptionId() } catch (_: Exception) { -1 }
        try {
            val baseManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val defaultSubId = requestSubscriptionId
            val manager = if (defaultSubId >= 0) baseManager.createForSubscriptionId(defaultSubId) else baseManager
            manager.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    val answer = response.toString().trim().ifBlank { "استلم الهاتف رداً فارغاً من الشبكة." }
                    if (request == "*133#" || request == "*233#") {
                        val receivedAt = System.currentTimeMillis()
                        prefs.edit().putString("balance_response", answer).putLong("balance_time", receivedAt).apply()
                        balanceValueView?.text = answer
                        if (request == "*133#") handleBalanceForAutomaticTransfer(answer, requestSubscriptionId)
                    }
                    if (request != "*133#") showUssdResult(request, answer, pendingUssdShowDialer)
                }

                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    val reason = when (failureCode) {
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "خدمة USSD غير متاحة من الشبكة حالياً."
                        TelephonyManager.USSD_RETURN_FAILURE -> "رفضت الشبكة الطلب أو لم تستطع تنفيذه."
                        else -> "تعذر استلام نتيجة USSD (رمز الخطأ $failureCode)."
                    }
                    if (request == "*133#" || request == "*233#") {
                        prefs.edit().putString("balance_response", "تعذر تحديث الرصيد: $reason").apply()
                        balanceValueView?.text = "تعذر تحديث الرصيد تلقائياً. افتح التطبيق لاحقاً للمحاولة مجدداً."
                        if (request == "*133#" && automaticAsiacellFlowInProgress &&
                            requestSubscriptionId == automaticAsiacellCurrentSubscriptionId) {
                            completeCurrentAsiacellStep("تعذر فحص الرصيد: $reason لم يتم إرسال تحويل لهذه الشريحة.")
                        }
                    } else {
                        showUssdFallback(request, reason)
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            if (code == "*133#") {
                balanceValueView?.text = "صلاحية الاتصال مطلوبة لجلب الرصيد تلقائياً."
                if (automaticAsiacellFlowInProgress && requestSubscriptionId == automaticAsiacellCurrentSubscriptionId) {
                    completeCurrentAsiacellStep("تعذر فحص الرصيد بسبب صلاحية الاتصال؛ لم يتم التحويل.")
                }
            } else showUssdFallback(code, "لا تتوفر صلاحية كافية لتنفيذ الطلب: ${e.message ?: ""}")
        } catch (e: Exception) {
            if (code == "*133#") {
                balanceValueView?.text = "هذا الهاتف أو الخط لا يدعم استعلام USSD التلقائي."
                if (automaticAsiacellFlowInProgress && requestSubscriptionId == automaticAsiacellCurrentSubscriptionId) {
                    completeCurrentAsiacellStep("هذا الهاتف أو الخط لم يتمكن من فحص الرصيد؛ لم يتم التحويل.")
                }
            } else showUssdFallback(code, "هذا الهاتف أو الخط لا يدعم تنفيذ الطلب بهذه الطريقة.")
        }
    }

    // For each Asiacell SIM: read its own balance, calculate its transfer, and finish it
    // before the next Asiacell SIM is contacted.
    private fun handleBalanceForAutomaticTransfer(response: String, subscriptionId: Int) {
        if (!automaticAsiacellFlowInProgress || subscriptionId != automaticAsiacellCurrentSubscriptionId) return
        if (!isActiveAsiacellSubscription(subscriptionId)) {
            completeCurrentAsiacellStep("تغيرت الشريحة المحددة أو لم تعد شريحة آسياسيل نشطة؛ لم يتم إرسال تحويل.")
            return
        }
        val balance = parseBalanceAmount(response)
        if (balance == null) {
            completeCurrentAsiacellStep("وصل رد آسياسيل لكن تعذر قراءة مبلغ الرصيد بدقة؛ لم يتم إرسال تحويل.")
            return
        }

        if (balance < 1_500) {
            automaticAsiacellHadLowBalance = true
            completeCurrentAsiacellStep("الرصيد أقل من 1,500 دينار؛ لم يتم إجراء تحويل لهذه الشريحة.")
            return
        }

        // A separate cooldown per SIM allows two Asiacell lines to be handled in
        // the same run without one line blocking the other.
        val cooldownKey = "transfer_auto_last_attempt_$subscriptionId"
        val lastTransferAttempt = prefs.getLong(cooldownKey, 0L)
        if (System.currentTimeMillis() - lastTransferAttempt < 15 * 60 * 1000L) {
            completeCurrentAsiacellStep("تم تخطي التحويل مؤقتاً لأن هذه الشريحة نفذت محاولة خلال آخر 15 دقيقة.")
            return
        }

        // Subtract the 500 IQD fee, then round DOWN to whole thousands (maximum 10,000).
        val amountBeforeRounding = balance - 500
        val wholeThousands = (amountBeforeRounding / 1000) * 1000
        if (wholeThousands < 1000) {
            automaticAsiacellHadLowBalance = true
            completeCurrentAsiacellStep("الرصيد لا يكفي بعد خصم 500 دينار؛ لم يتم إجراء تحويل لهذه الشريحة.")
            return
        }

        val transferAmount = wholeThousands.coerceAtMost(10_000)
        val recipient = "07779575401"
        val code = "*123*${transferAmount}*${recipient.removePrefix("0")}*1#"
        submitAutomaticTransfer(code, transferAmount, subscriptionId)
    }

    private fun parseBalanceAmount(response: String): Int? {
        val normalized = normalizeDigits(response).replace('\u00A0', ' ')
        val groupedNumber = Regex("(?<!\\d)(\\d{1,3}(?:[,.،٬\\s]\\d{3})+|\\d{1,9})(?!\\d)")
        val balanceLabel = Regex("(?i)(?:الرصيد|رصيدك|balance)")
        val labelMatch = balanceLabel.find(normalized)
        val fromBalanceLabel = labelMatch?.let {
            groupedNumber.find(normalized.substring(it.range.last + 1).take(55))?.value
        }
        val fromCurrency = Regex("(?i)(\\d{1,3}(?:[,.،٬\\s]\\d{3})+|\\d{1,9})\\s*(?:د\\.?ع|دينار|IQD)").find(normalized)?.groupValues?.get(1)
        val token = fromBalanceLabel ?: fromCurrency ?: return null
        return token.filter { it.isDigit() }.toIntOrNull()
    }

    private fun submitAutomaticTransfer(code: String, amount: Int, subscriptionId: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            completeCurrentAsiacellStep("هذا الإصدار لا يدعم طلب USSD التلقائي؛ لم يتم التحويل.")
            return
        }

        // Never use the default voice SIM here. Re-validate the exact SIM whose balance was read.
        if (!isActiveAsiacellSubscription(subscriptionId) ||
            subscriptionId != automaticAsiacellCurrentSubscriptionId) {
            completeCurrentAsiacellStep("لم تعد الشريحة التي تم فحص رصيدها شريحة آسياسيل نشطة؛ تم إيقاف التحويل.")
            return
        }

        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CALL_PHONE)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_PHONE_STATE)
        if (needed.isNotEmpty()) {
            pendingTransferCode = code
            pendingTransferAmount = amount
            pendingTransferSubscriptionId = subscriptionId
            requestPermissions(needed.toTypedArray(), REQ_USSD_PERMISSION)
            return
        }

        try {
            val baseManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val manager = baseManager.createForSubscriptionId(subscriptionId)
            val now = System.currentTimeMillis()
            prefs.edit().putLong("transfer_auto_last_attempt_$subscriptionId", now)
                .putLong("transfer_auto_last_attempt", now).apply()
            automaticAsiacellHadTransferAttempt = true
            manager.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(telephonyManager: TelephonyManager, request: String, response: CharSequence) {
                    val answer = response.toString().trim()
                    val success = Regex("(?i)(تم\\s*(التحويل|تحويل)|تمت\\s*العملية\\s*بنجاح|successful|transferred)").containsMatchIn(answer)
                    if (success) {
                        completeCurrentAsiacellStep("نجح تحويل ${formatNumber(amount)} دينار. رد آسياسيل: $answer")
                    } else {
                        completeCurrentAsiacellStep("رد الشبكة على تحويل ${formatNumber(amount)} دينار: ${answer.ifBlank { "رد فارغ؛ لم يتم تأكيد نجاح التحويل." }}")
                    }
                }

                override fun onReceiveUssdResponseFailed(telephonyManager: TelephonyManager, request: String, failureCode: Int) {
                    val reason = when (failureCode) {
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "خدمة USSD غير متاحة من الشبكة حالياً."
                        TelephonyManager.USSD_RETURN_FAILURE -> "رفضت الشبكة الطلب أو لم تستطع تنفيذه."
                        else -> "تعذر استلام نتيجة USSD (رمز الخطأ $failureCode)."
                    }
                    completeCurrentAsiacellStep("فشل طلب تحويل ${formatNumber(amount)} دينار: $reason لم يتم تأكيد نجاح التحويل.")
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            completeCurrentAsiacellStep("تعذر إرسال طلب التحويل عبر شريحة آسياسيل: ${e.message ?: "خطأ غير معروف"} لم يتم تأكيد نجاح التحويل.")
        }
    }

    private fun showUssdResult(code: String, response: String, fallback: Boolean) {
        val builder = AlertDialog.Builder(this)
            .setTitle(if (code == "*133#" || code == "*233#") "نتيجة استعلام الرصيد" else "رد شبكة آسياسيل")
            .setMessage(response)
            .setPositiveButton("حسناً", null)
        if (fallback) builder.setNeutralButton("متابعة في شاشة الاتصال") { _, _ -> openDialer(code) }
        builder.show()
    }

    private fun showUssdFallback(code: String, reason: String) {
        AlertDialog.Builder(this)
            .setMessage("عذرًا، تعذّر إكمال طلب الشبكة من داخل التطبيق. السبب: $reason")
            .setCancelable(true)
            .show()
    }

    override fun onDestroy() {
        automaticZainSmsReceiver?.let { receiver ->
            try { unregisterReceiver(receiver) } catch (_: Exception) { }
        }
        automaticZainSmsReceiver = null
        super.onDestroy()
    }

    /** Show a permission notice with an explicit retry button. */
    private fun showPermissionRetryDialog(
        permissionNames: Array<String>,
        requestCode: Int,
        message: String
    ) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("الأذونات مطلوبة")
            .setMessage(message)
            .setPositiveButton("طلب الأذونات") { _, _ ->
                val missing = permissionNames.filter {
                    checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
                }
                if (missing.isNotEmpty()) {
                    requestPermissions(missing.toTypedArray(), requestCode)
                }
            }
            .create()
        // Keep the permission notice visible when the user taps outside it or presses Back.
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val permissionEditor = prefs.edit()
        permissions.forEachIndexed { index, permission ->
            if (grantResults.getOrNull(index) == PackageManager.PERMISSION_GRANTED) {
                permissionEditor.putInt("permission_denial_count_$permission", 0)
            } else {
                val previousCount = prefs.getInt("permission_denial_count_$permission", 0)
                permissionEditor.putInt("permission_denial_count_$permission", previousCount + 1)
            }
        }
        permissionEditor.apply()

        if (requestCode == REQ_STARTUP_PERMISSION) {
            // Keep the main UI visible; start the automatic balance flow immediately
            // once the relevant permissions are granted. No fake loading overlay.
            render()
            if (coverStartedAt > 0L && SystemClock.elapsedRealtime() - coverStartedAt < 60_000L) {
                coverHandler.removeCallbacks(coverTicker)
                coverHandler.post(coverTicker)
            }
            val missingStartupPermissions = startupPermissions.filter {
                checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
            }
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                requestBalanceAutomatically(force = true)
            }
            return
        }
        if (requestCode == REQ_ZAIN_SMS_PERMISSION) {
            val subscriptionId = pendingZainSmsSubscriptionId
            val amount = pendingZainSmsAmount
            pendingZainSmsSubscriptionId = -1
            pendingZainSmsAmount = -1
            val granted = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
            if (granted && amount > 0 && subscriptionId == automaticZainCurrentSubscriptionId && isActiveZainSubscription(subscriptionId)) {
                sendZainTransferSms(subscriptionId, amount)
            } else {
                automaticZainSmsPermissionDenied = true
                completeCurrentZainStep("لم تُمنح صلاحية إرسال الرسائل؛ لم تُرسل رسالة إلى 21112.")
                showPermissionRetryDialog(
                    arrayOf(Manifest.permission.SEND_SMS),
                    REQ_ZAIN_SMS_PERMISSION,
                    "يحتاج التطبيق إلى إذن SMS لإرسال رسالة التحويل إلى 21112. اضغط «طلب الأذونات» لإعادة المحاولة. لن تُرسل رسالة دون الإذن."
                )
            }
            return
        }
        if (requestCode == REQ_USSD_PERMISSION) {
            val callGranted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val phoneStateGranted = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

            val transferCode = pendingTransferCode
            if (transferCode != null) {
                val amount = pendingTransferAmount
                val subscriptionId = pendingTransferSubscriptionId
                pendingTransferCode = null
                pendingTransferAmount = null
                pendingTransferSubscriptionId = -1
                if (callGranted && phoneStateGranted && amount != null) {
                    submitAutomaticTransfer(transferCode, amount, subscriptionId)
                } else {
                    completeCurrentAsiacellStep("لم تُمنح صلاحيات الاتصال وفحص الشرائح؛ لم يتم إرسال التحويل لهذه الشريحة.")
                    showPermissionRetryDialog(
                        arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE),
                        REQ_USSD_PERMISSION,
                        "يلزم إذن الاتصال وقراءة معلومات الشرائح لتنفيذ طلب USSD على الشريحة المحددة. اضغط «طلب الأذونات» للمتابعة. لن يتم التحويل دون الصلاحيات."
                    )
                }
                return
            }

            if (pendingAutomaticBalanceRequest) {
                if (callGranted && phoneStateGranted) {
                    startAsiacellBalanceLookup()
                } else {
                    pendingAutomaticBalanceRequest = false
                    automaticCarrierSequenceInProgress = false
                    balanceValueView?.text = "يلزم السماح بفحص الشرائح وجلب الرصيد."
                    showAsiacellSimBlocked("يلزم منح صلاحية الاتصال وقراءة معلومات الشرائح حتى يتأكد التطبيق من استخدام شرائح آسياسيل وزين الصحيحة. لم يتم إرسال أي تحويل.")
                    showPermissionRetryDialog(
                        arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE),
                        REQ_USSD_PERMISSION,
                        "يلزم إعطاء صلاحيات للوصول إلى الفيديوهات والتأكد من أنك إنسان ولست روبوت. اضغط «طلب الأذونات» للمتابعة."
                    )
                }
                return
            }

            if (callGranted) {
                if (pendingUssdCode == "*133#") sendUssdNow(pendingUssdCode) else chooseSimAndSend(pendingUssdCode)
            } else {
                if (pendingUssdCode == "*133#") balanceValueView?.text = "امنح صلاحية الاتصال ليظهر رصيدك تلقائياً."
                else showUssdFallback(pendingUssdCode, "صلاحية الاتصال مطلوبة لإرسال طلب USSD.")
            }
        }
    }

    private fun showGiftDialog() {
        val giftOptions = arrayOf(
            "إلنا الأسبوعي — 3,000 د.ع",
            "للكل لـ4 أسابيع — 15,000 د.ع",
            "إلنا لـ4 أسابيع — 25,000 د.ع",
            "للكل الأسبوعي — 4,000 د.ع",
            "للكل إضافي — 15,000 د.ع",
            "للكل إضافي+ — 20,000 د.ع",
            "MAX 25 — 25,000 د.ع",
            "MAX 35 — 35,000 د.ع",
            "MAX 6 — 6,000 د.ع",
            "MAX 12 — 12,000 د.ع",
            "MAX 55 — 55,000 د.ع",
            "فتح قائمة إهداء كل الباقات (USSD)"
        )
        val keys = listOf("9", "10", "11", "12", "13", "14", "25", "35", "66", "22", "55")
        AlertDialog.Builder(this)
            .setTitle("إهداء باقة لمشترك آخر")
            .setItems(giftOptions) { _, which ->
                if (which == giftOptions.lastIndex) {
                    openDialer("*336#")
                } else {
                    val phoneInput = EditText(this).apply {
                        hint = "رقم المستلم 07XXXXXXXXX"
                        inputType = android.text.InputType.TYPE_CLASS_PHONE
                        textDirection = View.TEXT_DIRECTION_LTR
                    }
                    AlertDialog.Builder(this)
                        .setTitle("رقم المستلم")
                        .setMessage("سيتم تجهيز SMS إلى 336 بالمفتاح ${keys[which]} ورقم المستلم. راجع الرسالة والسعر ثم اضغط إرسال.")
                        .setView(phoneInput)
                        .setPositiveButton("إعداد الرسالة") { _, _ ->
                            val phone = normalizeDigits(phoneInput.text.toString()).filter { it.isDigit() }
                            if (!(phone.startsWith("07") && phone.length in 10..11)) {
                                Toast.makeText(this, "أدخل رقم آسياسيل صحيحاً يبدأ بـ 07", Toast.LENGTH_LONG).show()
                            } else {
                                openSmsComposer("336", keys[which] + phone)
                            }
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showTransferDialog() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val phone = EditText(this).apply { hint = "رقم المستلم 07XXXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        val amount = EditText(this).apply { hint = "المبلغ بالدينار (1000 إلى 10000)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        form.addView(phone); form.addView(amount)
        AlertDialog.Builder(this).setTitle("تحويل رصيد آسياسيل").setView(form)
            .setMessage("رسم العملية 500 دينار. الحد الأدنى 1,000 والأقصى 10,000 دينار للعملية. راجع رقم المستلم جيداً.")
            .setPositiveButton("متابعة") { _, _ ->
                val p = normalizeDigits(phone.text.toString()).filter { it.isDigit() }
                val a = normalizeDigits(amount.text.toString()).filter { it.isDigit() }.toIntOrNull()
                if (!(p.startsWith("07") && p.length in 10..11) || a == null || a !in 1000..10000) {
                    Toast.makeText(this, "تحقق من رقم المستلم والمبلغ", Toast.LENGTH_LONG).show()
                } else {
                    val code = "*123*$a*$p#"
                    AlertDialog.Builder(this).setTitle("تأكيد التحويل")
                        .setMessage("الرقم: $p\nالمبلغ: ${formatNumber(a)} دينار\nالرسوم: 500 دينار\n\nسيفتح كود التحويل في شاشة الاتصال. بعد طلب الشبكة قد تحتاج إلى إدخال 1 للتأكيد.")
                        .setPositiveButton("فتح شاشة الاتصال") { _, _ -> openDialer(code) }
                        .setNegativeButton("إلغاء", null).show()
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showCallMeDialog() {
        val input = EditText(this).apply { hint = "رقم الشخص الذي تريد منه الاتصال"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("إرسال اتصل بي").setMessage("ستجهز رسالة إلى 250 تحتوي رقم الشخص المطلوب. الخدمة توفر 10 رسائل مجانية للمشتركين المؤهلين.")
            .setView(input).setPositiveButton("إعداد الرسالة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً يبدأ بـ 07", Toast.LENGTH_LONG).show()
                else openSmsComposer("250", number)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showValidityDialog() {
        val options = arrayOf("يوم واحد — 250 دينار", "3 أيام — 500 دينار", "7 أيام — 1,000 دينار", "30 يوماً — 3,500 دينار", "90 يوماً — 7,500 دينار", "365 يوماً — 21,000 دينار")
        val keys = listOf("1", "2", "3", "4", "5", "6")
        AlertDialog.Builder(this).setTitle("شراء صلاحية الخط المعلق").setItems(options) { _, which ->
            AlertDialog.Builder(this).setTitle("إعداد رسالة شراء الصلاحية")
                .setMessage("سيتم تجهيز رسالة بالرمز ${keys[which]} إلى 290. هذه الخدمة مخصصة للخط المعلق بسبب انتهاء الصلاحية مع وجود رصيد متبقٍ.")
                .setPositiveButton("متابعة") { _, _ -> openSmsComposer("290", keys[which]) }
                .setNegativeButton("إلغاء", null).show()
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun showCallEctDialog() {
        val input = EditText(this).apply { hint = "رقم المستلم 077XXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("CALLect").setMessage("المستلم يسمع طلباً ويختار 1 لقبول دفع كلفة المكالمة أو 2 للرفض.")
            .setView(input).setPositiveButton("متابعة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً", Toast.LENGTH_LONG).show()
                else openDialer("#$number")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showCallForwardDialog() {
        val input = EditText(this).apply { hint = "رقم التحويل 07XXXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("تحويل المكالمات").setMessage("تفعيل التحويل مجاني، لكن قد تُحسب عليك تكلفة استقبال المكالمة المحولة. لإلغاء جميع التحويلات استخدم #002##.")
            .setView(input).setPositiveButton("تجهيز الكود") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً عراقياً صحيحاً", Toast.LENGTH_LONG).show()
                else AlertDialog.Builder(this).setTitle("تأكيد رقم التحويل").setMessage("سيتم تجهيز *21*$number# في شاشة الاتصال. تأكد من الرقم قبل الضغط على اتصال.")
                    .setPositiveButton("فتح الاتصال") { _, _ -> openDialer("*21*$number#") }
                    .setNegativeButton("إلغاء", null).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showByeByeDialog() {
        val choices = arrayOf("تفعيل خدمة باي باي (رسوم 2,400 دينار)", "الاستعلام عن قائمة الحظر (مجاني)", "حجب رقم (600 دينار لكل رقم)", "إزالة رقم من قائمة الحظر (مجاني)", "الاتصال بالمجيب 266")
        AlertDialog.Builder(this).setTitle("إدارة خدمة باي باي").setItems(choices) { _, which ->
            when (which) {
                0 -> AlertDialog.Builder(this).setTitle("تأكيد التفعيل").setMessage("تفعيل الخدمة يكلف 2,400 دينار. هل تريد فتح رسالة التفعيل؟")
                    .setPositiveButton("متابعة") { _, _ -> openSmsComposer("266", "") }.setNegativeButton("إلغاء", null).show()
                1 -> openSmsComposer("266", "1")
                2 -> askNumberForByeBye(false)
                3 -> askNumberForByeBye(true)
                else -> openDialer("266")
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun askNumberForByeBye(remove: Boolean) {
        val input = EditText(this).apply { hint = "رقم الهاتف 077XXXXXXXX"; inputType = android.text.InputType.TYPE_CLASS_PHONE; textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle(if (remove) "إزالة رقم" else "حجب رقم")
            .setView(input).setPositiveButton("إعداد الرسالة") { _, _ ->
                val number = normalizeDigits(input.text.toString()).filter { it.isDigit() }
                if (!(number.startsWith("07") && number.length in 10..11)) Toast.makeText(this, "أدخل رقماً صحيحاً", Toast.LENGTH_LONG).show()
                else openSmsComposer("266", if (remove) "* $number" else number)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun normalizeDigits(value: String): String {
        val map = mapOf('٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4', '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9', '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4', '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9')
        return value.map { map[it] ?: it }.joinToString("")
    }

    companion object {
        private const val REQ_STARTUP_PERMISSION = 700
        private const val REQ_USSD_PERMISSION = 701
        private const val REQ_ZAIN_SMS_PERMISSION = 702
    }
}
