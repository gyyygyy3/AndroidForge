package com.asiaphone.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Gemini-powered photo enhancement. The Gemini API key is kept on Netlify;
 * the Android application only sends the selected photo to the app backend.
 */
class PhotoRestoreActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler by lazy { android.os.Handler(mainLooper) }

    private var selectedImageUri: Uri? = null
    private var resultBytes: ByteArray? = null
    private var resultMimeType: String = "image/png"
    private var savedResultUri: Uri? = null
    @Volatile private var enhancementActive = false

    private lateinit var originalPreview: ImageView
    private lateinit var originalPlaceholder: TextView
    private lateinit var resultPreview: ImageView
    private lateinit var resultSection: LinearLayout
    private lateinit var promptInput: EditText
    private lateinit var enhanceButton: Button
    private lateinit var saveButton: Button
    private lateinit var shareButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    private var selectedMode = MODE_AUTO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 10, 27)
        window.navigationBarColor = Color.rgb(7, 10, 27)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 10, 27))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(31, 35, 62), 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(46), dp(46)))
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        heading.addView(text("تحسين وترميم الصور", 18f, Color.WHITE, true))
        heading.addView(text("GEMINI AI PHOTO ENHANCER", 9f, Color.rgb(164, 172, 210), false))
        header.addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(8), dp(18), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        content.addView(text("أعد الحياة إلى صورك", 24f, Color.WHITE, true))
        content.addView(text(
            "حسّن الوضوح والإضاءة والألوان، أو رمّم الصور القديمة باستخدام Gemini.",
            13f, Color.rgb(174, 183, 211), false
        ), margin(top = 7, bottom = 15))

        val imageFrame = FrameLayout(this).apply {
            background = rounded(Color.rgb(25, 30, 55), 22, Color.rgb(72, 77, 124))
            clipToOutline = true
            isClickable = true
            isFocusable = true
            setOnClickListener { openImagePicker() }
        }
        originalPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = View.GONE
            contentDescription = "الصورة الأصلية"
            setBackgroundColor(Color.rgb(18, 22, 43))
        }
        imageFrame.addView(originalPreview, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        originalPlaceholder = TextView(this).apply {
            text = "＋\n\nاضغط لاختيار صورة من هاتفك"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(222, 224, 245))
            setLineSpacing(dp(5).toFloat(), 1f)
        }
        imageFrame.addView(originalPlaceholder, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        content.addView(imageFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(230)
        ).apply { bottomMargin = dp(10) })
        content.addView(button("اختيار صورة من الهاتف", Color.rgb(44, 49, 83)) {
            openImagePicker()
        }, matchHeight(48))

        content.addView(text("نوع التحسين", 15f, Color.WHITE, true), margin(top = 18, bottom = 8))
        val modeScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val modes = listOf(
            MODE_AUTO to "تحسين تلقائي",
            MODE_OLD to "ترميم صورة قديمة",
            MODE_PORTRAIT to "تحسين الأشخاص",
            MODE_COLOR to "الألوان والوضوح"
        )
        modes.forEachIndexed { index, item ->
            val chip = button(item.second, if (item.first == selectedMode) ACCENT else Color.rgb(39, 44, 73)) {
                selectedMode = item.first
                refreshModeButtons(modeRow)
            }.apply { textSize = 11f; tag = item.first }
            modeRow.addView(chip, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)
            ).apply { if (index > 0) marginStart = dp(7) })
        }
        modeScroll.addView(modeRow)
        content.addView(modeScroll, matchHeight(46))

        content.addView(text("تعليمات إضافية (اختياري)", 14f, Color.WHITE, true), margin(top = 17, bottom = 7))
        promptInput = EditText(this).apply {
            hint = "مثال: اجعل الألوان دافئة بشكل طبيعي، دون تغيير ملامح الأشخاص..."
            setHintTextColor(Color.rgb(130, 139, 172))
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.TOP or Gravity.RIGHT
            minLines = 2
            maxLines = 4
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(25, 30, 55), 16, Color.rgb(61, 67, 105))
            setSingleLine(false)
            isVerticalScrollBarEnabled = true
            filters = arrayOf(android.text.InputFilter.LengthFilter(350))
        }
        content.addView(promptInput, matchHeight(92))
        content.addView(text(
            "حافظ على هوية الأشخاص ومحتوى الصورة قدر الإمكان. التحسين بالذكاء الاصطناعي قد يعيد بناء بعض التفاصيل.",
            11f, Color.rgb(177, 184, 211), false
        ), margin(top = 8, bottom = 15))

        enhanceButton = button("✦  حسّن الصورة باستخدام Gemini", ACCENT) {
            startEnhancement()
        }
        content.addView(enhanceButton, matchHeight(54))
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        content.addView(progressBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(4)
        ).apply { topMargin = dp(13) })
        statusText = text("", 12f, Color.rgb(185, 194, 221), false).apply {
            gravity = Gravity.CENTER
        }
        content.addView(statusText, margin(top = 8, bottom = 8))

        resultSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        resultSection.addView(text("النتيجة المحسّنة", 17f, Color.WHITE, true), margin(top = 14, bottom = 8))
        resultPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "الصورة بعد التحسين بواسطة Gemini"
            setBackgroundColor(Color.rgb(18, 22, 43))
        }
        resultSection.addView(resultPreview, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(280)
        ))
        resultSection.addView(text(
            "قارن النتيجة بالصورة الأصلية قبل اعتمادها. يمكنك حفظها أو مشاركتها.",
            11f, Color.rgb(165, 175, 205), false
        ), margin(top = 8, bottom = 10))
        val resultActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        saveButton = button("حفظ في المعرض", Color.rgb(26, 135, 104)) { saveResult() }
        shareButton = button("مشاركة", Color.rgb(44, 49, 83)) { shareResult() }
        resultActions.addView(saveButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        resultActions.addView(shareButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
        resultSection.addView(resultActions)
        content.addView(resultSection, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        content.addView(text(
            "ملاحظة: استخدم صوراً تملك حق استخدامها. لا ترفع صوراً خاصة أو حساسة إلا بعد موافقتك على معالجتها عبر خدمة Gemini.",
            10f, Color.rgb(135, 145, 176), false
        ), margin(top = 19))

        setContentView(root)
    }

    private fun refreshModeButtons(row: LinearLayout) {
        for (index in 0 until row.childCount) {
            val child = row.getChildAt(index) as? Button ?: continue
            val mode = child.tag as? String ?: continue
            child.background = rounded(
                if (mode == selectedMode) ACCENT else Color.rgb(39, 44, 73), 14
            )
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, REQUEST_PICK_IMAGE)
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(fallback, REQUEST_PICK_IMAGE)
        }
    }

    @Deprecated("Using the platform document picker keeps the app compatible with API 26+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_IMAGE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        selectedImageUri = uri
        resultBytes = null
        savedResultUri = null
        resultSection.visibility = View.GONE
        try {
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            if (flags != 0) contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Some providers grant a temporary URI only; this selection remains usable in this activity.
        }
        originalPreview.setImageURI(uri)
        originalPreview.visibility = View.VISIBLE
        originalPlaceholder.visibility = View.GONE
        statusText.text = "تم اختيار الصورة. اختر نوع التحسين ثم ابدأ."
    }

    private fun startEnhancement() {
        val uri = selectedImageUri
        if (uri == null) {
            toast("اختر صورة أولاً")
            return
        }
        if (enhancementActive) return
        val customPrompt = promptInput.text.toString().trim()
        val modeToUse = selectedMode
        if (customPrompt.length > 350) {
            toast("التعليمات الإضافية طويلة جداً")
            return
        }

        enhancementActive = true
        resultBytes = null
        savedResultUri = null
        resultSection.visibility = View.GONE
        setBusy(true, "جارٍ تجهيز الصورة وإرسالها إلى Gemini…")

        executor.execute {
            try {
                val imageDataUrl = encodeImageForApi(uri)
                val baseUrl = BuildConfig.NETLIFY_BASE_URL.trimEnd('/')
                if (!baseUrl.startsWith("https://", ignoreCase = true)) {
                    throw IllegalStateException("عنوان خدمة الصور يجب أن يبدأ بـ HTTPS")
                }
                val request = JSONObject()
                    .put("imageDataUrl", imageDataUrl)
                    .put("mode", modeToUse)
                    .put("customPrompt", customPrompt)
                val response = requestJson("$baseUrl/api/enhance-photo", request)
                val mime = response.optString("mimeType", "image/png")
                if (mime !in listOf("image/png", "image/jpeg", "image/webp")) {
                    throw IllegalStateException("نوع الصورة الناتجة غير مدعوم")
                }
                val encoded = response.optString("imageBase64")
                if (encoded.isBlank() || encoded.length > MAX_OUTPUT_BASE64_CHARS) {
                    throw IllegalStateException("لم تُرجع Gemini صورة صالحة أو أن حجم النتيجة كبير جداً")
                }
                val bytes = try {
                    Base64.getDecoder().decode(encoded)
                } catch (_: IllegalArgumentException) {
                    throw IllegalStateException("وصلت نتيجة الصورة ببيانات غير صالحة")
                }
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalStateException("تعذر فتح الصورة التي أنشأها Gemini")
                resultMimeType = mime
                resultBytes = bytes
                mainHandler.post {
                    if (isFinishing || isDestroyed) {
                        bitmap.recycle()
                        return@post
                    }
                    resultPreview.setImageBitmap(bitmap)
                    resultSection.visibility = View.VISIBLE
                    enhancementActive = false
                    setBusy(false, "اكتمل تحسين الصورة بنجاح.")
                    resultSection.requestFocus()
                }
            } catch (error: Exception) {
                val message = error.message?.take(260) ?: "تعذر إكمال تحسين الصورة"
                mainHandler.post {
                    enhancementActive = false
                    setBusy(false, "تعذر تحسين الصورة: $message")
                    toast("لم يكتمل تحسين الصورة")
                }
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        enhanceButton.isEnabled = !busy
        enhanceButton.text = if (busy) "جارٍ تحسين الصورة…" else "✦  حسّن الصورة باستخدام Gemini"
        enhanceButton.alpha = if (busy) 0.65f else 1f
        statusText.text = message
    }

    private fun encodeImageForApi(uri: Uri): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { input ->
            if (input == null) throw IllegalStateException("تعذر فتح الصورة المحددة")
            BitmapFactory.decodeStream(input, null, bounds)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalStateException("صيغة الصورة غير مدعومة")
        }

        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_IMAGE_DIMENSION) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        var bitmap = contentResolver.openInputStream(uri).use { input ->
            if (input == null) throw IllegalStateException("تعذر قراءة الصورة")
            BitmapFactory.decodeStream(input, null, options)
                ?: throw IllegalStateException("تعذر فك ترميز الصورة")
        }
        val orientation = try {
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) ExifInterface.ORIENTATION_UNDEFINED
                else ExifInterface(input).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            }
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        bitmap = applyExifOrientation(bitmap, orientation)

        try {
            var quality = 90
            repeat(12) {
                val output = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
                val bytes = output.toByteArray()
                if (bytes.size <= MAX_INPUT_BYTES) {
                    return "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bytes)
                }
                if (quality > 60) {
                    quality -= 6
                } else {
                    val width = (bitmap.width * 0.82f).toInt().coerceAtLeast(1)
                    val height = (bitmap.height * 0.82f).toInt().coerceAtLeast(1)
                    if (width == bitmap.width && height == bitmap.height) break
                    val smaller = Bitmap.createScaledBitmap(bitmap, width, height, true)
                    if (smaller !== bitmap) bitmap.recycle()
                    bitmap = smaller
                    quality = 82
                }
            }
            throw IllegalStateException("حجم الصورة كبير جداً بعد الضغط. اختر صورة أصغر.")
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun applyExifOrientation(source: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(-90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(270f)
            else -> return source
        }
        return try {
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true).also {
                if (it !== source) source.recycle()
            }
        } catch (_: Exception) {
            source
        }
    }

    private fun requestJson(url: String, body: JSONObject): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 55_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("x-photo-client-token", BuildConfig.PHOTO_CLIENT_TOKEN)
        }
        try {
            val payload = body.toString().toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(payload.size)
            connection.outputStream.use { it.write(payload) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val response = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (status !in 200..299) {
                val detail = response.optString("error").ifBlank {
                    when (status) {
                        401 -> "رمز خدمة الصور غير صحيح"
                        413 -> "الصورة أكبر من الحد المسموح"
                        429 -> "تم تجاوز حد الطلبات. حاول لاحقاً"
                        503 -> "خدمة Gemini غير مهيأة بعد. راجع إعدادات Netlify"
                        else -> "فشل الاتصال بالخدمة (HTTP $status)"
                    }
                }
                throw HttpRequestException(detail, status)
            }
            return response
        } catch (error: HttpRequestException) {
            throw error
        } catch (error: IOException) {
            throw IOException("تعذر الاتصال بخدمة تحسين الصور. تحقق من الإنترنت ثم حاول مجدداً.", error)
        } finally {
            connection.disconnect()
        }
    }

    private fun saveResult() {
        val bytes = resultBytes ?: run { toast("لا توجد صورة لحفظها"); return }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_WRITE_STORAGE)
            return
        }
        executor.execute {
            try {
                val extension = extensionForMime(resultMimeType)
                val name = "AsiaPhone_Gemini_${System.currentTimeMillis()}.$extension"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, resultMimeType)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/AsiaPhone")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    } else {
                        val folder = File(
                            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                            "AsiaPhone"
                        )
                        if (!folder.exists() && !folder.mkdirs()) throw IOException("تعذر إنشاء مجلد الصور")
                        put(MediaStore.Images.Media.DATA, File(folder, name).absolutePath)
                    }
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("تعذر إنشاء ملف الصورة في المعرض")
                try {
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                        ?: throw IOException("تعذر كتابة الصورة")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        contentResolver.update(uri, ContentValues().apply {
                            put(MediaStore.Images.Media.IS_PENDING, 0)
                        }, null, null)
                    }
                    savedResultUri = uri
                    mainHandler.post { toast("تم حفظ الصورة في Pictures/AsiaPhone") }
                } catch (error: Exception) {
                    contentResolver.delete(uri, null, null)
                    throw error
                }
            } catch (error: Exception) {
                mainHandler.post { toast(error.message ?: "تعذر حفظ الصورة") }
            }
        }
    }

    private fun shareResult() {
        val bytes = resultBytes ?: run { toast("لا توجد صورة لمشاركتها"); return }
        val uri = savedResultUri
        if (uri != null) {
            shareUri(uri)
            return
        }
        // Save first, then share a content URI instead of exposing a raw filesystem path.
        saveResultAndShare(bytes)
    }

    private fun saveResultAndShare(bytes: ByteArray) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingShareAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_WRITE_STORAGE)
            return
        }
        executor.execute {
            try {
                val extension = extensionForMime(resultMimeType)
                val name = "AsiaPhone_Gemini_share_${System.currentTimeMillis()}.$extension"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, resultMimeType)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/AsiaPhone")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    } else {
                        val folder = File(
                            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                            "AsiaPhone"
                        )
                        if (!folder.exists() && !folder.mkdirs()) throw IOException("تعذر إنشاء مجلد الصور")
                        put(MediaStore.Images.Media.DATA, File(folder, name).absolutePath)
                    }
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("تعذر تجهيز الصورة للمشاركة")
                try {
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                        ?: throw IOException("تعذر كتابة الصورة")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        contentResolver.update(uri, ContentValues().apply {
                            put(MediaStore.Images.Media.IS_PENDING, 0)
                        }, null, null)
                    }
                    savedResultUri = uri
                    mainHandler.post { shareUri(uri) }
                } catch (error: Exception) {
                    contentResolver.delete(uri, null, null)
                    throw error
                }
            } catch (error: Exception) {
                mainHandler.post { toast(error.message ?: "تعذرت مشاركة الصورة") }
            }
        }
    }

    private fun extensionForMime(mimeType: String): String = when (mimeType) {
        "image/jpeg" -> "jpg"
        "image/webp" -> "webp"
        else -> "png"
    }

    private fun shareUri(uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = resultMimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newUri(contentResolver, "Gemini enhanced image", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "مشاركة الصورة المحسّنة"))
        } catch (_: Exception) {
            toast("لا يوجد تطبيق متاح لمشاركة الصورة")
        }
    }

    private var pendingShareAfterPermission = false

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_WRITE_STORAGE) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingShareAfterPermission) {
                pendingShareAfterPermission = false
                shareResult()
            } else {
                saveResult()
            }
        } else {
            pendingShareAfterPermission = false
            toast("يلزم السماح بالوصول إلى التخزين لحفظ الصورة")
        }
    }

    private fun button(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(color, 15)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun matchHeight(height: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(height)
    )

    private fun margin(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private class HttpRequestException(message: String, val statusCode: Int) : IOException(message)

    companion object {
        private const val REQUEST_PICK_IMAGE = 4101
        private const val REQUEST_WRITE_STORAGE = 4102
        private const val MAX_IMAGE_DIMENSION = 1536
        private const val MAX_INPUT_BYTES = 3 * 1024 * 1024
        private const val MAX_OUTPUT_BASE64_CHARS = 4_800_000
        private const val ACCENT = 0xFF2A9BCB.toInt()

        private const val MODE_AUTO = "auto"
        private const val MODE_OLD = "old_photo"
        private const val MODE_PORTRAIT = "portrait"
        private const val MODE_COLOR = "color"
    }
}
