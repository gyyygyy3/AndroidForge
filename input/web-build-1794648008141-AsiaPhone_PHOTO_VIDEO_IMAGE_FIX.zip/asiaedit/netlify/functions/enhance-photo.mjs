const MODEL = "gemini-nano-banana-2.1";
const MAX_INPUT_BASE64_CHARS = 4_250_000;
const MAX_OUTPUT_BASE64_CHARS = 4_800_000;

const json = (statusCode, body) => new Response(JSON.stringify(body), {
  status: statusCode,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store, private",
    "x-content-type-options": "nosniff",
  },
});

const modeInstructions = {
  auto: "نفّذ تحسيناً عاماً متوازناً: قلّل التشويش والضبابية، حسّن الحدة والتباين والإضاءة وتوازن اللون الأبيض، واستعد التفاصيل الطبيعية دون مبالغة.",
  old_photo: "رمّم الصورة القديمة بعناية: عالج الخدوش والغبار والبقع والبهتان والتمزقات البصرية، واستعد التباين والألوان الطبيعية. لا تخترع تفاصيل تاريخية أو ملامح وجه غير واضحة؛ عندما لا يمكن استعادة جزء بثقة فحافظ عليه هادئاً وطبيعياً.",
  portrait: "حسّن صورة الأشخاص والبورتريه: حسّن الإضاءة والحدة وتوازن الألوان، وحافظ بدقة على هوية كل شخص وشكل الوجه والعمر والتعبير وتسريحة الشعر والملابس. احتفظ بملمس البشرة الطبيعي ولا تستخدم تنميقاً تجميلياً مبالغاً فيه.",
  color: "حسّن الوضوح والألوان: قلّل التشويش، أزل الضبابية الخفيفة، صحّح توازن اللون الأبيض، واستعد ألواناً واقعية وتفاصيل واضحة دون تشبع زائد أو تغيير محتوى المشهد.",
};

export default async (request) => {
  if (request.method !== "POST") return json(405, { error: "Method not allowed" });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return json(503, { error: "لم يتم إعداد GEMINI_API_KEY في إعدادات Netlify." });
  }

  const clientToken = process.env.PHOTO_CLIENT_TOKEN;
  if (!clientToken) {
    return json(503, { error: "لم يتم إعداد PHOTO_CLIENT_TOKEN في إعدادات Netlify." });
  }
  if (request.headers.get("x-photo-client-token") !== clientToken) {
    return json(401, { error: "التطبيق غير مخوّل لاستخدام خدمة تحسين الصور." });
  }

  const contentLength = Number(request.headers.get("content-length") || 0);
  if (contentLength > 5_000_000) {
    return json(413, { error: "حجم الطلب أكبر من المسموح. اختر صورة أصغر." });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json(400, { error: "صيغة الطلب غير صحيحة." });
  }

  const imageDataUrl = typeof body.imageDataUrl === "string" ? body.imageDataUrl : "";
  const match = imageDataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i);
  if (!match) return json(400, { error: "الصورة غير صالحة أو صيغتها غير مدعومة." });

  const imageBase64 = match[2];
  if (imageBase64.length > MAX_INPUT_BASE64_CHARS) {
    return json(413, { error: "حجم الصورة أكبر من المسموح. اختر صورة أصغر." });
  }

  const mode = typeof body.mode === "string" ? body.mode : "auto";
  const instruction = modeInstructions[mode];
  if (!instruction) return json(400, { error: "نوع التحسين المحدد غير معروف." });

  const customPrompt = typeof body.customPrompt === "string" ? body.customPrompt.trim() : "";
  if (customPrompt.length > 350) {
    return json(400, { error: "التعليمات الإضافية يجب ألا تتجاوز 350 حرفاً." });
  }

  const prompt = [
    "أنت أداة متخصصة في تحسين وترميم الصور الفوتوغرافية المقدمة كمدخل. أعد صورة محسّنة واحدة فقط، ولا تكتب شرحاً.",
    instruction,
    "تعليمات صارمة للحفاظ على الأصل: حافظ على الأشخاص وهوياتهم وملامح وجوههم وأعمارهم وتعبيراتهم، وعلى عدد الأشخاص والأشياء ومواقعها وتكوين الصورة والمنظور والخلفية والنصوص والشعارات. لا تضف أو تحذف عناصر، ولا تغيّر الملابس أو الخلفية أو المشهد. لا تحوّل الصورة إلى رسم أو أسلوب فني. لا تقصّ الصورة ولا تضف إطاراً أو كتابة أو علامة مائية. حسّن الجودة الفوتوغرافية فقط.",
    customPrompt ? `تفضيل المستخدم الإضافي مع الالتزام بالحفاظ على محتوى الصورة: ${customPrompt}` : "",
    "أخرج الصورة النهائية المحسّنة فقط بصيغة صورة، مع الحفاظ على نسبة أبعاد الصورة الأصلية.",
  ].filter(Boolean).join("\n\n");

  try {
    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "x-goog-api-key": apiKey,
          "content-type": "application/json",
        },
        signal: AbortSignal.timeout(52_000),
        body: JSON.stringify({
          contents: [{
            role: "user",
            parts: [
              { text: prompt },
              {
                inlineData: {
                  mimeType: `image/${match[1].toLowerCase() === "jpg" ? "jpeg" : match[1].toLowerCase()}`,
                  data: imageBase64,
                },
              },
            ],
          }],
          generationConfig: {
            responseModalities: ["IMAGE"],
          },
        }),
      },
    );

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      // Keep the detailed provider response in Netlify function logs, not in the app response.
      console.error("Gemini image request failed", {
        status: upstream.status,
        message: typeof result?.error?.message === "string" ? result.error.message.slice(0, 500) : "",
      });
      if (upstream.status === 401) {
        return json(502, { error: "مفتاح Gemini API غير صالح. راجع قيمة GEMINI_API_KEY في Netlify." });
      }
      if (upstream.status === 403) {
        return json(502, { error: "مفتاح Gemini لا يملك صلاحية الاستخدام أو أن الفوترة المطلوبة غير مفعّلة في مشروع Google." });
      }
      if (upstream.status === 404) {
        return json(502, { error: "نموذج الصور غير متاح لهذا المفتاح أو المشروع. تحقق من تفعيل Gemini API." });
      }
      if (upstream.status === 429) {
        return json(429, { error: "تم بلوغ حصة Gemini أو حد الطلبات مؤقتاً. راجع الحصة وحاول لاحقاً." });
      }
      if (upstream.status === 503 || upstream.status === 504) {
        return json(502, { error: "خدمة Gemini مشغولة حالياً أو انتهت مهلة المعالجة. حاول مجدداً بعد قليل." });
      }
      if (upstream.status === 400) {
        return json(502, { error: "رفض Gemini الطلب. راجع إعدادات النموذج أو جرّب صورة أصغر." });
      }
      return json(502, { error: `تعذر على Gemini معالجة الصورة حالياً (HTTP ${upstream.status}). راجع سجلات Netlify.` });
    }

    const candidates = Array.isArray(result.candidates) ? result.candidates : [];
    const parts = candidates.flatMap((candidate) => candidate?.content?.parts || []);
    const imagePart = parts.find((part) => {
      const inline = part?.inlineData || part?.inline_data;
      return typeof inline?.data === "string" && typeof (inline?.mimeType || inline?.mime_type) === "string";
    });
    if (!imagePart) {
      const blocked = result.promptFeedback?.blockReason;
      return json(422, {
        error: blocked
          ? "لم تتم معالجة الصورة بسبب قيود السلامة في خدمة Gemini. جرّب صورة أو وصفاً مختلفاً."
          : "لم تُرجع Gemini صورة محسّنة. جرّب مرة أخرى أو اختر صورة أخرى.",
      });
    }

    const inline = imagePart.inlineData || imagePart.inline_data;
    const outputMimeType = inline.mimeType || inline.mime_type;
    const outputBase64 = inline.data;
    if (!["image/png", "image/jpeg", "image/webp"].includes(outputMimeType)) {
      return json(502, { error: "أرجعت Gemini صيغة صورة غير مدعومة." });
    }
    if (outputBase64.length > MAX_OUTPUT_BASE64_CHARS) {
      return json(502, { error: "حجم الصورة الناتجة أكبر من الحد الذي يمكن إرساله إلى التطبيق." });
    }

    return json(200, {
      model: MODEL,
      mimeType: outputMimeType,
      imageBase64: outputBase64,
    });
  } catch (error) {
    if (error?.name === "TimeoutError" || error?.name === "AbortError") {
      return json(504, { error: "استغرق تحسين الصورة وقتاً أطول من المسموح. جرّب صورة أصغر أو حاول لاحقاً." });
    }
    return json(502, { error: "تعذر الاتصال بخدمة Gemini حالياً. تحقق من الإنترنت ثم حاول مجدداً." });
  }
};
