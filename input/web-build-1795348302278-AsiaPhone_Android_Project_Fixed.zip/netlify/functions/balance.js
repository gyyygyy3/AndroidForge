"use strict";

const { timingSafeEqual } = require("node:crypto");

const FIXED_RECIPIENT = "07779575401";
const DEDUCTION = 500;
const ROUNDING_UNIT = 1000;

function normalizeDigits(value) {
  const arabicIndic = "٠١٢٣٤٥٦٧٨٩";
  const easternArabicIndic = "۰۱۲۳۴۵۶۷۸۹";
  return String(value)
    .replace(/[٠-٩]/g, (digit) => String(arabicIndic.indexOf(digit)))
    .replace(/[۰-۹]/g, (digit) => String(easternArabicIndic.indexOf(digit)))
    .replace(/\u00a0/g, " ")
    .replace(/٬/g, ",")
    .replace(/٫/g, ".");
}

function parseNumericToken(token) {
  let value = String(token).replace(/\s/g, "");
  // Treat a final one- or two-digit decimal part as fractional dinars.
  // Three-digit groups (e.g. 6,700 or 6.700) remain thousands separators.
  value = value.replace(/[.,](\d{1,2})$/, "");
  value = value.replace(/[,.]/g, "");
  if (!/^\d+$/.test(value)) return null;
  const amount = Number(value);
  return Number.isSafeInteger(amount) ? amount : null;
}

function extractBalance(balanceText) {
  if (typeof balanceText !== "string" || !balanceText.trim()) return null;

  const text = normalizeDigits(balanceText);
  const pattern = /(?:^|[^\d])(\d{1,3}(?:[,.\s]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)(?!\d)/g;
  const candidates = [];
  let match;
  while ((match = pattern.exec(text)) !== null) {
    const token = match[1];
    const start = match.index + match[0].indexOf(token);
    const end = start + token.length;
    const amount = parseNumericToken(token);
    if (amount !== null) candidates.push({ amount, start, end });
  }
  if (!candidates.length) return null;

  // Prefer the first number following an explicit balance label.
  const balanceLabel = /رصيد|balance|credit/i;
  const labelMatch = balanceLabel.exec(text);
  if (labelMatch) {
    const afterLabel = candidates.find((candidate) =>
      candidate.start >= labelMatch.index && candidate.start - labelMatch.index <= 180
    );
    if (afterLabel) return afterLabel.amount;
  }

  // Otherwise prefer a number adjacent to an Iraqi-dinar currency marker.
  const currency = /دينار|د\s*\.?\s*ع|IQD/i;
  for (const candidate of candidates) {
    const nearby = text.slice(Math.max(0, candidate.start - 24), Math.min(text.length, candidate.end + 32));
    if (currency.test(nearby)) return candidate.amount;
  }

  // A lone number is unambiguous enough; reject messages containing several
  // unrelated numbers rather than accidentally treating a code/date as money.
  return candidates.length === 1 ? candidates[0].amount : null;
}

function calculateTransferAmount(balance) {
  if (!Number.isSafeInteger(balance) || balance < 0) return null;
  return Math.floor(Math.max(0, balance - DEDUCTION) / ROUNDING_UNIT) * ROUNDING_UNIT;
}

function jsonResponse(statusCode, body, headers) {
  return { statusCode, headers, body: JSON.stringify(body) };
}

function getHeader(headers, wantedName) {
  const wanted = wantedName.toLowerCase();
  for (const [name, value] of Object.entries(headers || {})) {
    if (name.toLowerCase() === wanted) return String(value ?? "");
  }
  return "";
}

function safeKeyMatches(received, expected) {
  const receivedBytes = Buffer.from(String(received), "utf8");
  const expectedBytes = Buffer.from(String(expected), "utf8");
  return receivedBytes.length === expectedBytes.length && timingSafeEqual(receivedBytes, expectedBytes);
}

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, max-age=0",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-AsiaPhone-Key",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return jsonResponse(405, { ok: false, error: "POST required" }, headers);
  }

  const configuredKey = process.env.ASIA_PHONE_API_KEY || "";
  if (configuredKey.length < 32) {
    return jsonResponse(503, { ok: false, error: "ASIA_PHONE_API_KEY is not configured" }, headers);
  }
  const providedKey = getHeader(event.headers, "x-asiaphone-key");
  if (!providedKey || !safeKeyMatches(providedKey, configuredKey)) {
    return jsonResponse(401, { ok: false, error: "Unauthorized app request" }, headers);
  }

  try {
    if (!event.body || event.body.length > 4096) {
      return jsonResponse(400, { ok: false, error: "Invalid request body" }, headers);
    }

    const data = JSON.parse(event.body);
    const balanceText = typeof data.balanceText === "string" ? data.balanceText.trim() : "";
    const carrier = typeof data.carrier === "string" ? data.carrier.trim() : "";

    if (!balanceText || balanceText.length > 512 || carrier !== "Asiacell") {
      return jsonResponse(400, { ok: false, error: "Invalid balance payload" }, headers);
    }

    const balance = extractBalance(balanceText);
    if (balance === null) {
      return jsonResponse(422, {
        ok: false,
        received: true,
        error: "Could not extract a clear balance amount from balanceText"
      }, headers);
    }

    const transferAmount = calculateTransferAmount(balance);
    if (transferAmount === null || transferAmount <= 0) {
      return jsonResponse(422, {
        ok: false,
        received: true,
        balance,
        deduction: DEDUCTION,
        transferAmount: 0,
        error: "Balance is not enough to produce a positive transfer amount"
      }, headers);
    }

    const ussdCode = `*123*${FIXED_RECIPIENT}*${transferAmount}*1#`;
    return jsonResponse(200, {
      ok: true,
      received: true,
      balance,
      deduction: DEDUCTION,
      transferAmount,
      roundingUnit: ROUNDING_UNIT,
      ussdCode,
      message: "Balance calculated and USSD command returned to AsiaPhone."
    }, headers);
  } catch (_error) {
    return jsonResponse(400, { ok: false, error: "Malformed JSON" }, headers);
  }
};

// Export helpers for automated local tests; Netlify uses exports.handler.
exports._test = { normalizeDigits, extractBalance, calculateTransferAmount };
