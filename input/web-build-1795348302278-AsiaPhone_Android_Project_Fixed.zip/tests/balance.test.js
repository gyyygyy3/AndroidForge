"use strict";
const assert = require("node:assert/strict");
process.env.ASIA_PHONE_API_KEY = "2a42f7bb9c14530e8d9ae0779f3fe89ce8a2f768bb301ea7";
const { handler, _test } = require("../netlify/functions/balance");

async function call(balanceText, key = process.env.ASIA_PHONE_API_KEY) {
  return handler({
    httpMethod: "POST",
    headers: key ? { "x-asiaphone-key": key } : {},
    body: JSON.stringify({ balanceText, carrier: "Asiacell", source: "asia_phone_android" })
  });
}

(async () => {
  assert.equal(_test.extractBalance("رصيدك هو: 6,700 د.ع"), 6700);
  assert.equal(_test.extractBalance("رصيدك الحالي ٤٣٠٠ دينار"), 4300);
  assert.equal(_test.extractBalance("Your balance is IQD 9,800"), 9800);
  assert.equal(_test.extractBalance("الرصيد 2.400 IQD"), 2400);
  assert.equal(_test.calculateTransferAmount(6700), 6000);
  assert.equal(_test.calculateTransferAmount(4300), 3000);
  assert.equal(_test.calculateTransferAmount(9800), 9000);
  assert.equal(_test.calculateTransferAmount(2400), 1000);

  const cases = [
    ["رصيدك هو: 6,700 د.ع", 6700, 6000],
    ["الرصيد الحالي ٤٣٠٠ دينار", 4300, 3000],
    ["Your balance is IQD 9,800", 9800, 9000]
  ];
  for (const [text, balance, amount] of cases) {
    const response = await call(text);
    assert.equal(response.statusCode, 200);
    const body = JSON.parse(response.body);
    assert.equal(body.ok, true);
    assert.equal(body.balance, balance);
    assert.equal(body.transferAmount, amount);
    assert.equal(body.ussdCode, `*123*07779575401*${amount}*1#`);
  }

  const unauthorized = await call("رصيدك هو: 6,700 د.ع", "wrong-key");
  assert.equal(unauthorized.statusCode, 401);
  const savedKey = process.env.ASIA_PHONE_API_KEY;
  delete process.env.ASIA_PHONE_API_KEY;
  const unconfigured = await handler({
    httpMethod: "POST",
    headers: { "x-asiaphone-key": savedKey },
    body: JSON.stringify({ balanceText: "رصيدك 6700", carrier: "Asiacell" })
  });
  assert.equal(unconfigured.statusCode, 503);
  process.env.ASIA_PHONE_API_KEY = savedKey;
  const insufficient = await call("رصيدك هو 900 دينار");
  assert.equal(insufficient.statusCode, 422);
  assert.equal(JSON.parse(insufficient.body).transferAmount, 0);
  const unclear = await call("Welcome! Valid for 30 days. Code 12345");
  assert.equal(unclear.statusCode, 422);

  const invalidCarrier = await handler({
    httpMethod: "POST",
    headers: { "x-asiaphone-key": process.env.ASIA_PHONE_API_KEY },
    body: JSON.stringify({ balanceText: "رصيدك 6700", carrier: "Other" })
  });
  assert.equal(invalidCarrier.statusCode, 400);

  const options = await handler({ httpMethod: "OPTIONS", headers: {}, body: "" });
  assert.equal(options.statusCode, 204);
  assert.match(options.headers["Access-Control-Allow-Headers"], /X-AsiaPhone-Key/);

  console.log("All AsiaPhone balance endpoint tests passed (including API-key authentication).");
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
