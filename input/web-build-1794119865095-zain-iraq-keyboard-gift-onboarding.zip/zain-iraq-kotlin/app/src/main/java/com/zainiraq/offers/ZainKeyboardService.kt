package com.zainiraq.offers

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Optional Zain-themed keyboard.
 * It only forwards the key the user taps to the currently focused input field.
 * It does not read surrounding text, keep typing history, write keystrokes to disk,
 * or send keyboard input over the network.
 */
class ZainKeyboardService : InputMethodService() {
    private var englishMode = false
    private var upperCase = false

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onEvaluateFullscreenMode(): Boolean = false

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(35, 15, 53), Color.rgb(83, 35, 111))
            ).apply { cornerRadii = floatArrayOf(dp(17).toFloat(), dp(17).toFloat(), dp(17).toFloat(), dp(17).toFloat(), 0f, 0f, 0f, 0f) }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), dp(7))
        }
        header.addView(TextView(this).apply {
            text = "ZAIN"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, dp(30), 1f))
        header.addView(TextView(this).apply {
            text = "لوحة مفاتيح زين  •  لا نحفظ ما تكتبه"
            setTextColor(Color.rgb(233, 217, 246))
            textSize = 11f
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        })
        root.addView(header)

        addRow(root, (0..9).map { it.toString() }) { sendText(it) }
        if (englishMode) {
            addRow(root, "qwertyuiop".map { it.toString() }) { sendText(if (upperCase) it.uppercase() else it) }
            addRow(root, "asdfghjkl".map { it.toString() }) { sendText(if (upperCase) it.uppercase() else it) }
            addRow(root, listOf("⇧") + "zxcvbnm".map { it.toString() } + listOf("⌫"), special = true) { key ->
                when (key) {
                    "⇧" -> { upperCase = !upperCase; setInputView(buildKeyboard()) }
                    "⌫" -> deleteOne()
                    else -> { sendText(if (upperCase) key.uppercase() else key); if (upperCase) { upperCase = false; setInputView(buildKeyboard()) } }
                }
            }
        } else {
            addRow(root, listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج")) { sendText(it) }
            addRow(root, listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك")) { sendText(it) }
            addRow(root, listOf("ظ", "ط", "ذ", "د", "ز", "ر", "و", "ة", "ى", "⌫"), special = true) { key ->
                if (key == "⌫") deleteOne() else sendText(key)
            }
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        addBottomKey(bottom, if (englishMode) "ع" else "EN", 1.0f) {
            englishMode = !englishMode
            upperCase = false
            setInputView(buildKeyboard())
        }
        addBottomKey(bottom, "،", 0.8f) { sendText("،") }
        addBottomKey(bottom, "مسافة", 3.2f) { sendText(" ") }
        addBottomKey(bottom, ".", 0.8f) { sendText(".") }
        addBottomKey(bottom, "↵", 1.1f) { performEnter() }
        root.addView(bottom, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply {
            topMargin = dp(3)
        })
        return root
    }

    private fun addRow(
        parent: LinearLayout,
        labels: List<String>,
        special: Boolean = false,
        onKey: (String) -> Unit
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        labels.forEach { label ->
            val key = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = if (label.length > 1) 14f else 19f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                background = keyBackground(if (special && (label == "⌫" || label == "⇧")) Color.rgb(139, 76, 174) else Color.rgb(101, 64, 126))
                isClickable = true
                isFocusable = true
                setOnClickListener { onKey(label) }
            }
            row.addView(key, LinearLayout.LayoutParams(0, dp(43), 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
                topMargin = dp(3)
                bottomMargin = dp(2)
            })
        }
        parent.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
    }

    private fun addBottomKey(parent: LinearLayout, label: String, weight: Float, action: () -> Unit) {
        val key = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = if (label == "مسافة") 13f else 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = keyBackground(if (label == "مسافة") Color.rgb(151, 91, 183) else Color.rgb(111, 72, 137))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        parent.addView(key, LinearLayout.LayoutParams(0, dp(42), weight).apply {
            marginStart = dp(2)
            marginEnd = dp(2)
        })
    }

    private fun keyBackground(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(8).toFloat()
        setStroke(dp(1), Color.argb(38, 255, 255, 255))
    }

    private fun sendText(text: String) {
        // Forward only the explicitly tapped character; never inspect editor contents.
        currentInputConnection?.commitText(text, 1)
    }

    private fun deleteOne() {
        val connection = currentInputConnection ?: return
        connection.deleteSurroundingText(1, 0)
    }

    private fun performEnter() {
        val connection = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            if (!connection.performEditorAction(action)) sendEnterKey(connection)
        } else {
            sendEnterKey(connection)
        }
    }

    private fun sendEnterKey(connection: android.view.inputmethod.InputConnection) {
        connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
