#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v apktool >/dev/null || { echo "APKTool is required. Install it from https://apktool.org/" >&2; exit 2; }
apktool d -f "$ROOT/original/original.apk" -o "$ROOT/decompiled/apktool"
echo "APKTool output: $ROOT/decompiled/apktool"
