#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v jadx >/dev/null || { echo "JADX is required. Install it from https://github.com/skylot/jadx/releases" >&2; exit 2; }
mkdir -p "$ROOT/decompiled/jadx"
jadx --show-bad-code -d "$ROOT/decompiled/jadx" "$ROOT/original/original.apk"
echo "JADX output: $ROOT/decompiled/jadx"
