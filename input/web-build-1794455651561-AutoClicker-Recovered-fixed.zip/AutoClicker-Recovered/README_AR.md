# مشروع Auto Clicker المستعاد — إصلاح البناء

## إصلاح خطأ AndroidForge

كان AndroidForge يشغّل `gradle assembleDebug` و`gradle bundleDebug` من مجلد لا يحتوي على إعدادات Gradle. أُضيفت الآن الملفات التالية في جذر المشروع:

- `settings.gradle`
- `build.gradle`
- `gradle.properties`

أصبح أمر `gradle assembleDebug` يملك مهمة بناء فعلية، ويعيد تجميع الملفات الـ 2,497 المستخرجة في ملف:

`build/outputs/apk/debug/app-debug.apk`

كما أصبحت مهمة `gradle bundleDebug` متاحة للتوافق مع AndroidForge، وهي تشغّل مهمة APK نفسها. **لا تنتج هذه الحزمة ملف Android App Bundle بصيغة `.aab`.**

## تنبيه مهم حول طبيعة المشروع

هذه الحزمة تحتوي على ملفات APK مفكوكة/مستخرجة، وليست مشروع Android Studio أصلياً:

- مجلد `extracted_apk/` يحتوي على 2,497 مدخلاً، بما فيها `AndroidManifest.xml` وملفات DEX والموارد.
- مجلد `original/` لا يحتوي على `original.apk`.
- مجلد `decompiled/` لا يحتوي على مصدر Java/Kotlin مستعاد.

لذلك مهمة Gradle المضافة **تعيد تغليف الملفات الثنائية الموجودة فقط** ولا تعيد ترجمة سورس Java/Kotlin. ينتج عنها أرشيف APK مُعاد التجميع وغير موقّع؛ يجب أن تنفّذ بيئة AndroidForge المحاذاة والتوقيع قبل تثبيته أو توزيعه. نجاح مهمة Gradle لا يعني أن التطبيق اختُبر على جهاز Android.

لم أغيّر كود التطبيق أو أحذف SDKs أو الإعلانات. لا يمكن إجراء تعديل آمن على منطق التطبيق قبل استعادة السورس وفحص نقاط استدعاء تلك المكتبات. أُبقي مجلد `original/` دون إضافة نسخة APK مكررة.

## استعادة السورس لاحقاً

- `tools/decompile_jadx.sh` يستخدم `original/original.apk` عند توفره، أو يحاول تفكيك ملفات DEX الموجودة مباشرة.
- `tools/decode_apktool.sh` يستخدم APK الأصلي عند توفره، وإلا يعيد تجميع الأرشيف المستخرج مؤقتاً ثم يفكّه بواسطة APKTool.

تتطلب هذه الخطوات تثبيت JADX أو APKTool على الجهاز الذي يشغّلها.
