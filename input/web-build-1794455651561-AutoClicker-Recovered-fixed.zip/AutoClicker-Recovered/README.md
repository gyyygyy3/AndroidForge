Recovered Auto Clicker workspace. Read README_AR.md for the Gradle build-recovery notes and limitations.
