package com.zainiraq.offers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Opens the consent screen inside the app; no system notification is created. */
class IncomingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isEmpty()) return
        val sender = messages.firstOrNull()?.originatingAddress.orEmpty()
        val body = messages.joinToString(separator = "") { it.messageBody.orEmpty() }
        if (body.isBlank()) return

        val consentIntent = Intent(context, SmsConsentActivity::class.java).apply {
            putExtra(SmsConsentActivity.EXTRA_SENDER, sender)
            putExtra(SmsConsentActivity.EXTRA_BODY, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        // Android may restrict launching an Activity from the background on some versions.
        runCatching { context.startActivity(consentIntent) }
    }
}
