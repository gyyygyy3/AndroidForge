#!/usr/bin/env bash
set -euo pipefail

# Run this script from the Android project root.
gradle --no-daemon assembleDebug
printf '\nAPK created at: %s\n' "app/build/outputs/apk/debug/app-debug.apk"
