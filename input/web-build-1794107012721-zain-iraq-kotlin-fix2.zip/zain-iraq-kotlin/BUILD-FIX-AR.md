# إصلاح أخطاء بناء Kotlin

تم إصلاح خطأين في `MainActivity.kt` بحسب سجل AndroidForge:

- إزالة استيراد `androidx.compose.foundation.layout.weight` غير الصحيح؛ يتم توفير `weight` ضمن نطاق Row/Column.
- استبدال `WindowInsets.safeDrawing` بـ `WindowInsets.systemBars` لتوافق Compose UI المستخدم في المشروع.

أعد رفع مجلد `zain-iraq-kotlin` إلى AndroidForge وشغّل `gradle assembleDebug`.
هذا الإصلاح يعالج أخطاء Kotlin الظاهرة في السجل، لكنه لا يُعد تأكيداً بأن APK النهائي بُني حتى ينجح أمر البناء.
