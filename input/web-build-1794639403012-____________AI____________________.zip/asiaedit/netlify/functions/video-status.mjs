const json = (statusCode, body) => new Response(JSON.stringify(body), {
  status: statusCode,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});

export default async (request) => {
  if (request.method !== "GET") return json(405, { error: "Method not allowed" });

  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return json(503, { error: "لم يتم إعداد REPLICATE_API_TOKEN في إعدادات Netlify." });
  const clientToken = process.env.VIDEO_CLIENT_TOKEN;
  if (clientToken && request.headers.get("x-video-client-token") !== clientToken) {
    return json(401, { error: "هذا التطبيق غير مخوّل لقراءة حالة التوليد." });
  }

  const id = new URL(request.url).searchParams.get("id") || "";
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(id)) return json(400, { error: "رقم عملية التوليد غير صحيح." });

  try {
    const upstream = await fetch(`https://api.replicate.com/v1/predictions/${encodeURIComponent(id)}`, {
      headers: { "Authorization": `Bearer ${token}`, "Accept": "application/json" },
    });
    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = result.detail || result.error || `Provider error (${upstream.status})`;
      return json(upstream.status === 429 ? 429 : 502, { error: String(detail).slice(0, 500) });
    }

    let videoUrl = null;
    if (typeof result.output === "string") videoUrl = result.output;
    else if (Array.isArray(result.output) && typeof result.output[0] === "string") videoUrl = result.output[0];
    else if (result.output && typeof result.output.url === "string") videoUrl = result.output.url;

    return json(200, {
      id: result.id,
      status: result.status,
      videoUrl,
      error: result.error ? String(result.error).slice(0, 500) : null,
    });
  } catch (error) {
    return json(502, { error: error?.message || "تعذر قراءة حالة التوليد." });
  }
};
