const json = (statusCode, body) => new Response(JSON.stringify(body), {
  status: statusCode,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});

export default async (request) => {
  if (request.method !== "POST") return json(405, { error: "Method not allowed" });

  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return json(503, { error: "لم يتم إعداد REPLICATE_API_TOKEN في إعدادات Netlify." });
  const clientToken = process.env.VIDEO_CLIENT_TOKEN;
  if (clientToken && request.headers.get("x-video-client-token") !== clientToken) {
    return json(401, { error: "هذا التطبيق غير مخوّل لاستخدام خدمة الفيديو." });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json(400, { error: "صيغة الطلب غير صحيحة." });
  }

  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const imageDataUrl = typeof body.imageDataUrl === "string" ? body.imageDataUrl : "";

  if (prompt.length < 5 || prompt.length > 500) {
    return json(400, { error: "وصف الحركة يجب أن يكون بين 5 و500 حرف." });
  }
  if (!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(imageDataUrl)) {
    return json(400, { error: "الصورة يجب أن تكون JPEG مضغوطة من داخل التطبيق." });
  }
  // The app compresses images to <=180 KB. Keep a strict cap so request payloads stay small.
  if (imageDataUrl.length > 260_000) {
    return json(413, { error: "حجم الصورة أكبر من المسموح. اختر صورة أصغر." });
  }

  try {
    const upstream = await fetch(
      "https://api.replicate.com/v1/models/wan-video/wan-2.2-i2v-fast/predictions",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
          "Prefer": "wait=1",
        },
        body: JSON.stringify({
          input: {
            image: imageDataUrl,
            prompt,
            go_fast: true,
            num_frames: 81,
            resolution: "480p",
            sample_shift: 12,
            frames_per_second: 16,
            interpolate_output: false,
          },
        }),
      },
    );

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = result.detail || result.error || `Provider error (${upstream.status})`;
      return json(upstream.status === 429 ? 429 : 502, { error: String(detail).slice(0, 500) });
    }
    if (!result.id) return json(502, { error: "خدمة التوليد لم تُرجع رقم العملية." });

    let videoUrl = null;
    if (typeof result.output === "string") videoUrl = result.output;
    else if (Array.isArray(result.output) && typeof result.output[0] === "string") videoUrl = result.output[0];
    else if (result.output && typeof result.output.url === "string") videoUrl = result.output.url;

    return json(200, {
      id: result.id,
      status: result.status || "starting",
      videoUrl,
    });
  } catch (error) {
    return json(502, { error: error?.message || "تعذر الاتصال بخدمة توليد الفيديو." });
  }
};
