plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Set this to the URL of your deployed Netlify site if it differs.
val netlifyBaseUrl = (project.findProperty("NETLIFY_BASE_URL") as String?)
    ?: "https://ashley2005.netlify.app"
val videoClientToken = (project.findProperty("VIDEO_CLIENT_TOKEN") as String?) ?: ""

android {
    namespace = "com.asiaphone.app"
    // Pin to API 34, which is preinstalled in AndroidForge's build image.
    compileSdk = 34
    buildToolsVersion = "34.0.0"

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        buildConfigField("String", "NETLIFY_BASE_URL", "\"$netlifyBaseUrl\"")
        buildConfigField("String", "VIDEO_CLIENT_TOKEN", "\"$videoClientToken\"")
        applicationId = "com.kiloo.subwaysurf"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
