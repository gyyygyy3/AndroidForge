package com.asiaphone.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.MediaController
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Image-to-video screen. The Android app talks only to the Netlify helper;
 * the Replicate token stays in Netlify environment variables.
 */
class VideoGeneratorActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler by lazy { android.os.Handler(mainLooper) }

    private var selectedImageUri: Uri? = null
    private var generatedVideoUrl: String? = null

    private lateinit var imagePreview: ImageView
    private lateinit var imagePlaceholder: TextView
    private lateinit var promptInput: EditText
    private lateinit var generateButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var videoView: VideoView
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 10, 27)
        window.navigationBarColor = Color.rgb(7, 10, 27)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildScreen()
    }

    private fun buildScreen() {
        val pageBackground = Color.rgb(7, 10, 27)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pageBackground)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(15), dp(18), dp(12))
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(31, 35, 62), 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(46), dp(46)))
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        heading.addView(text("تحويل صورة إلى فيديو", 18f, Color.WHITE, true))
        heading.addView(text("AI IMAGE TO VIDEO", 9f, Color.rgb(164, 172, 210), false))
        header.addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(8), dp(18), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        content.addView(text("حوّل صورتك إلى مشهد متحرك", 23f, Color.WHITE, true))
        content.addView(text(
            "اختر صورة، صف الحركة التي تريدها، وسينشئ الذكاء الاصطناعي فيديو واحداً.",
            13f, Color.rgb(174, 183, 211), false
        ), margin(top = 7, bottom = 17))

        val imageFrame = FrameLayout(this).apply {
            background = rounded(Color.rgb(25, 30, 55), 22, Color.rgb(72, 77, 124))
            clipToOutline = true
            isClickable = true
            isFocusable = true
            setOnClickListener { openImagePicker() }
        }
        imagePreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            contentDescription = "الصورة المختارة لتوليد الفيديو"
        }
        imageFrame.addView(imagePreview, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        imagePlaceholder = TextView(this).apply {
            text = "＋\n\nاضغط لاختيار صورة من هاتفك"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(222, 224, 245))
            setLineSpacing(dp(5).toFloat(), 1f)
        }
        imageFrame.addView(imagePlaceholder, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        content.addView(imageFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
        ).apply { bottomMargin = dp(10) })

        val pickButton = button("اختيار صورة من الهاتف", Color.rgb(44, 49, 83)) {
            openImagePicker()
        }
        content.addView(pickButton, matchHeight(48))

        content.addView(text("وصف الحركة", 15f, Color.WHITE, true), margin(top = 19, bottom = 8))
        promptInput = EditText(this).apply {
            hint = "مثال: اجعل الشخص يبتسم ويلتفت نحو الكاميرا، مع حركة كاميرا سينمائية بطيئة..."
            setHintTextColor(Color.rgb(130, 139, 172))
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.TOP or Gravity.RIGHT
            minLines = 4
            maxLines = 7
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(Color.rgb(25, 30, 55), 16, Color.rgb(61, 67, 105))
            setSingleLine(false)
            isVerticalScrollBarEnabled = true
        }
        content.addView(promptInput, matchHeight(126))
        content.addView(text(
            "اكتب وصفاً واضحاً للحركة. يفضّل أن يكون الوصف من 5 إلى 500 حرف.",
            11f, Color.rgb(145, 154, 186), false
        ), margin(top = 7, bottom = 15))

        generateButton = button("✦  أنشئ فيديو واحداً", Color.rgb(130, 83, 231)) {
            startGeneration()
        }
        content.addView(generateButton, matchHeight(54))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        content.addView(progressBar, margin(top = 15, bottom = 5))
        statusText = text("", 12f, Color.rgb(191, 199, 225), false).apply {
            gravity = Gravity.CENTER
        }
        content.addView(statusText, matchHeight(32))

        videoView = VideoView(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
        }
        content.addView(videoView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(225)
        ).apply { topMargin = dp(14) })

        saveButton = button("حفظ الفيديو في الهاتف", Color.rgb(32, 145, 116)) {
            requestSaveVideo()
        }
        saveButton.visibility = View.GONE
        content.addView(saveButton, margin(top = 10))

        setContentView(root)
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_PICK_IMAGE)
    }

    @Deprecated("Using startActivityForResult for compatibility with the existing Activity-based app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQUEST_PICK_IMAGE -> {
                val uri = data.data ?: return
                selectedImageUri = uri
                imagePreview.setImageURI(uri)
                imagePreview.visibility = View.VISIBLE
                imagePlaceholder.visibility = View.GONE
                generatedVideoUrl = null
                videoView.stopPlayback()
                videoView.visibility = View.GONE
                saveButton.visibility = View.GONE
                statusText.text = "تم اختيار الصورة. اكتب وصف الحركة ثم ابدأ التوليد."
            }
            REQUEST_SAVE_VIDEO -> {
                val destination = data.data ?: return
                val source = generatedVideoUrl ?: return
                saveVideoTo(destination, source)
            }
        }
    }

    private fun startGeneration() {
        val imageUri = selectedImageUri
        val prompt = promptInput.text.toString().trim()
        if (imageUri == null) {
            toast("اختر صورة أولاً")
            return
        }
        if (prompt.length < 5) {
            promptInput.error = "اكتب وصفاً أطول للحركة"
            return
        }
        if (prompt.length > 500) {
            promptInput.error = "اختصر الوصف إلى 500 حرف"
            return
        }
        val baseUrl = BuildConfig.NETLIFY_BASE_URL.trim().trimEnd('/')
        if (baseUrl.contains("YOUR-SITE", ignoreCase = true) || !baseUrl.startsWith("https://")) {
            statusText.text = "أضف رابط موقع Netlify في إعدادات البناء أولاً. راجع VIDEO_SETUP_AR.md."
            toast("رابط Netlify غير مضبوط بعد")
            return
        }

        setBusy(true, "جارٍ تجهيز الصورة وإرسال طلب التوليد...")
        generatedVideoUrl = null
        videoView.visibility = View.GONE
        saveButton.visibility = View.GONE

        executor.execute {
            try {
                val imageDataUrl = encodeImageForApi(imageUri)
                val createBody = JSONObject()
                    .put("prompt", prompt)
                    .put("imageDataUrl", imageDataUrl)
                val created = requestJson("$baseUrl/api/create-video", "POST", createBody)
                val predictionId = created.optString("id")
                if (predictionId.isBlank()) throw IllegalStateException("لم يرجع الخادم رقم عملية التوليد")
                mainHandler.post { statusText.text = "تم إرسال الطلب. يجري الآن توليد الفيديو..." }

                var resultUrl: String? = created.optString("videoUrl").takeIf { it.startsWith("https://") }
                var terminalError: String? = null
                for (attempt in 0 until (if (resultUrl == null) MAX_POLL_ATTEMPTS else 0)) {
                    Thread.sleep(POLL_INTERVAL_MS)
                    val status = requestJson(
                        "$baseUrl/api/video-status?id=${Uri.encode(predictionId)}", "GET", null
                    )
                    when (status.optString("status").lowercase()) {
                        "succeeded", "successful", "completed" -> {
                            resultUrl = status.optString("videoUrl").takeIf { it.startsWith("https://") }
                            if (resultUrl == null) terminalError = "اكتمل التوليد لكن رابط الفيديو غير متوفر"
                            break
                        }
                        "failed", "canceled", "cancelled" -> {
                            terminalError = status.optString("error").ifBlank { "فشل توليد الفيديو" }
                            break
                        }
                        else -> {
                            val percent = ((attempt + 1) * 100 / MAX_POLL_ATTEMPTS).coerceAtMost(95)
                            mainHandler.post { statusText.text = "جارٍ توليد الفيديو... قد يستغرق ذلك دقيقة أو أكثر ($percent%)" }
                        }
                    }
                }
                if (resultUrl == null) {
                    throw IllegalStateException(terminalError ?: "انتهت مهلة الانتظار. تحقق من حالة الطلب وحاول مجدداً.")
                }
                mainHandler.post { showGeneratedVideo(resultUrl!!) }
            } catch (error: Exception) {
                val message = error.message?.take(240) ?: "حدث خطأ غير متوقع"
                mainHandler.post {
                    setBusy(false, "تعذر إنشاء الفيديو: $message")
                    toast("تعذر إكمال التوليد")
                }
            }
        }
    }

    /** Compress to a compact JPEG data URL. Replicate recommends data URLs for files <=256 KB. */
    private fun encodeImageForApi(uri: Uri): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { input ->
            if (input == null) throw IllegalStateException("تعذر فتح الصورة المحددة")
            BitmapFactory.decodeStream(input, null, bounds)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("صيغة الصورة غير مدعومة")

        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 1200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        var bitmap = contentResolver.openInputStream(uri).use { input ->
            if (input == null) throw IllegalStateException("تعذر قراءة الصورة")
            BitmapFactory.decodeStream(input, null, options)
                ?: throw IllegalStateException("تعذر فك ترميز الصورة")
        }

        try {
            var quality = 86
            repeat(10) { attempt ->
                val output = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
                val bytes = output.toByteArray()
                // Keep encoded source <= 180 KB so the Replicate data URI stays small.
                if (bytes.size <= MAX_IMAGE_BYTES) {
                    return "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bytes)
                }
                if (quality > 58) {
                    quality -= 7
                } else {
                    val newWidth = (bitmap.width * 0.82f).toInt().coerceAtLeast(1)
                    val newHeight = (bitmap.height * 0.82f).toInt().coerceAtLeast(1)
                    if (newWidth == bitmap.width && newHeight == bitmap.height) {
                        throw IllegalStateException("الصورة كبيرة جداً، اختر صورة أصغر")
                    }
                    val smaller = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
                    if (smaller !== bitmap) bitmap.recycle()
                    bitmap = smaller
                    quality = 78
                }
            }
            throw IllegalStateException("تعذر ضغط الصورة إلى الحجم المناسب")
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun requestJson(url: String, method: String, body: JSONObject?): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 25_000
            readTimeout = 45_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("x-video-client-token", BuildConfig.VIDEO_CLIENT_TOKEN)
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) connection.outputStream.use { stream ->
                stream.write(body.toString().toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            val stream: InputStream? = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val response = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299) {
                val message = response.optString("error").ifBlank {
                    response.optString("message").ifBlank { "خطأ من الخادم (HTTP $code)" }
                }
                throw IllegalStateException(message)
            }
            return response
        } finally {
            connection.disconnect()
        }
    }

    private fun showGeneratedVideo(url: String) {
        generatedVideoUrl = url
        setBusy(false, "اكتمل الفيديو! يمكنك تشغيله أو حفظه في هاتفك.")
        videoView.visibility = View.VISIBLE
        val controller = MediaController(this)
        controller.setAnchorView(videoView)
        videoView.setMediaController(controller)
        videoView.setVideoURI(Uri.parse(url))
        videoView.setOnPreparedListener { player ->
            player.isLooping = true
            videoView.start()
        }
        videoView.setOnErrorListener { _, _, _ ->
            toast("تعذر تشغيل المعاينة. جرّب حفظ الفيديو ثم فتحه من الهاتف.")
            true
        }
        saveButton.visibility = View.VISIBLE
    }

    private fun requestSaveVideo() {
        if (generatedVideoUrl.isNullOrBlank()) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/mp4"
            putExtra(Intent.EXTRA_TITLE, "AI-Video.mp4")
        }
        startActivityForResult(intent, REQUEST_SAVE_VIDEO)
    }

    private fun saveVideoTo(destination: Uri, source: String) {
        saveButton.isEnabled = false
        statusText.text = "جارٍ حفظ الفيديو في الهاتف..."
        executor.execute {
            try {
                val connection = (URL(source).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 25_000
                    readTimeout = 60_000
                }
                try {
                    connection.inputStream.use { input ->
                        contentResolver.openOutputStream(destination, "w").use { output ->
                            if (output == null) throw IllegalStateException("تعذر فتح مكان الحفظ")
                            val buffer = ByteArray(32 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                            output.flush()
                        }
                    }
                } finally {
                    connection.disconnect()
                }
                mainHandler.post {
                    saveButton.isEnabled = true
                    statusText.text = "تم حفظ الفيديو بنجاح."
                    toast("تم حفظ الفيديو")
                }
            } catch (error: Exception) {
                mainHandler.post {
                    saveButton.isEnabled = true
                    statusText.text = "تعذر حفظ الفيديو: ${error.message ?: "خطأ غير معروف"}"
                }
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        generateButton.isEnabled = !busy
        generateButton.alpha = if (busy) 0.55f else 1f
        progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        statusText.text = message
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
    }

    private fun button(value: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = value
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(color, 15)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchHeight(height: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(height)
    )

    private fun margin(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    companion object {
        private const val REQUEST_PICK_IMAGE = 811
        private const val REQUEST_SAVE_VIDEO = 812
        private const val MAX_IMAGE_BYTES = 180 * 1024
        private const val MAX_POLL_ATTEMPTS = 120
        private const val POLL_INTERVAL_MS = 5_000L
    }
}
